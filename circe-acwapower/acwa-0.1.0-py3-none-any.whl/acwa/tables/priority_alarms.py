"""
acwa.tables.priority_alarms

Validation schema for priority_alarms table
"""

from datetime import datetime

import pandera as pa
from pandera.typing import Series

class PriorityAlarmsSchema(pa.DataFrameModel):
    """Schema for table priority_alarms (in the intermediate schema)"""

    id_wf: Series[int] = pa.Field() # Wind Farm id
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    code: Series[int] = pa.Field() # Code
    description: Series[str] = pa.Field() # Description of the alarm
    component: Series[str] = pa.Field() # Affected component
    start_datetime: Series[datetime] = pa.Field() # Start of the event
    end_datetime: Series[datetime] = pa.Field() # End of the event
    duration: Series[int] = pa.Field() # Duration of the alarm (in seconds?)

    time_since_previous_alarm: Series[int] = pa.Field(nullable=True) # Time in seconds until next alarm
    time_since_previous_same_alarm: Series[int] = pa.Field(nullable=True) # Time in seconds until next alarm of the same code

    serial_number: Series[int] = pa.Field()
    event_type: Series[str] = pa.Field()
    severity: Series[int] = pa.Field()
    remark: Series[str] = pa.Field()

    severity_scale: Series[int] = pa.Field(ge=1, le=5)
    legacy_type: Series[str] = pa.Field()
    manufacturer_availability: Series[str] = pa.Field()
    operational_availability: Series[str] = pa.Field()
