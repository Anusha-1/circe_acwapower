"""
acwa.tables.pitch

Validation schema for pitch table
"""

import pandas as pd
import pandera as pa
from pandera.typing import Series

class PitchSchema(pa.DataFrameModel):
    """Schema for table pitch"""

    id_wf: Series[int] = pa.Field() # Wind Farm
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    timestamp: Series[pd.Timestamp] = pa.Field() # Timestamp
    statistic: Series[str] = pa.Field()
    blade: Series[str] = pa.Field()
    pitch_angle: Series[float] = pa.Field(nullable=True) # Pitch angle
    limited: Series[bool] = pa.Field() # True if pitch angle was change to its limit

    # Add more ?...