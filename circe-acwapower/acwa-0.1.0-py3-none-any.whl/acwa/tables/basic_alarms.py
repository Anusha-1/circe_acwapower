"""
acwa.tables.basic_alarms

Validation schema for basic_alarms table
"""

from datetime import datetime

import pandera as pa
from pandera.typing import Series

class BasicAlarmsSchema(pa.DataFrameModel):
    """Schema for table basic_alarms"""

    id_wf: Series[int] = pa.Field() # Wind Farm id
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    code: Series[int] = pa.Field() # Code
    description: Series[str] = pa.Field() # Description of the alarm
    component: Series[str] = pa.Field() # Affected component
    start_datetime: Series[datetime] = pa.Field() # Start of the event
    end_datetime: Series[datetime] = pa.Field() # End of the event
   
    serial_number: Series[int] = pa.Field(nullable=True)
    event_type: Series[str] = pa.Field(nullable=True)
    severity: Series[int] = pa.Field(nullable=True)
    remark: Series[str] = pa.Field(nullable=True)

    severity_scale: Series[int] = pa.Field(ge=1, le=6)
    legacy_type: Series[str] = pa.Field()
    classification: Series[str] = pa.Field()
    manufacturer_availability: Series[str] = pa.Field(nullable=True)
    priority: Series[int] = pa.Field(ge=1, le=12)

    duration: Series[int] = pa.Field() # Duration of the alarm (in seconds?)
    ongoing: Series[bool] = pa.Field() # If the alarm is currently active

    ## Clasificaciones de alarmas

    # Add more ...
