"""
acwa.tables.aggregation

Collection of schemas for aggregated tables
"""

from .tower_acceleration import TowerAcceleration1DaySchema

__all__ = [TowerAcceleration1DaySchema]
