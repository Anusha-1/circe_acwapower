"""
acwa.tables.power_curves

Collection of table schemas related with power curves
"""

from .pc_metadata import PCMetadataSchema
from .power_curves import PowerCurvesSchema

__all__ = [PowerCurvesSchema, PCMetadataSchema]