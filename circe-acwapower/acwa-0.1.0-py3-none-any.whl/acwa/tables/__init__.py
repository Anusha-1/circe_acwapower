"""
acwa.tables

Module to keep validation schemas for the tables
"""

from .metadata import (
    AlarmsMetadataSchema,
    DensitiesSchema,
    SectorsSchema,
    WfConfigSchema,
    WtgConfigSchema,

    ReliabilityModelsSchema
)

from .power_curves import (
    PowerCurvesSchema,
    PCMetadataSchema
)

from .aggregation import (
    TowerAcceleration1DaySchema
)

from .basic_10min_with_alarms import Basic10minSchema
from .basic_input_10min import BasicInput10minSchema
from .basic_input_1min import BasicInput1minSchema
from .basic_input_alarms import BasicInputAlarmsSchema
from .manufacturer_availabilities_1day import ManufacturerAvailabilities1DaySchema
from .general_metadata import MetadataSchema
from .oper_10min import Oper10minSchema
from .oper_1h import Oper1hSchema
from .oper_1day import Oper1DaySchema
from .priority_alarms import PriorityAlarmsSchema
from .status import StatusSchema
from .treated_events import TreatedEventsSchema
from .treated_events_1day import TreatedEvents1DaySchema
from .AEP_config import AEPSchema
from .interpol_PC_config import interpolPCConfigSchema
from .basic_alarms import BasicAlarmsSchema
from .alarms_with_losses import AlarmsLossesSchema
from .wind_speed_corrections import WindSpeedCorrectionsSchema
from .component_availabilities_1day import ComponentAvailabilities1DaySchema
from .performance_ratio import PerformanceRatioSchema
from .oper_1min import Oper1minSchema
from .dynamic_yaw import DynamicYawSchema
from .max_power_misallignment import MaxPowerMisallignmentSchema
from .lapm_analysis import LapmAnalysisSchema
from .pitch import PitchSchema
from .met_mast import MetMastSchema
from .status_met_mast import StatusMetMastSchema
from .tower_acceleration import TowerAccelerationSchema

__all__ = [
    ## Metadata Tables
    AlarmsMetadataSchema,
    DensitiesSchema,
    SectorsSchema,
    WfConfigSchema,
    WtgConfigSchema,
    ReliabilityModelsSchema,

    ## Power Curves Tables
    PowerCurvesSchema,
    PCMetadataSchema,

    ## Aggregation Tables
    TowerAcceleration1DaySchema,
    
    Basic10minSchema,
    BasicInputAlarmsSchema,
    BasicInput10minSchema,
    ManufacturerAvailabilities1DaySchema,
    MetadataSchema,
    Oper10minSchema,
    Oper1hSchema,
    Oper1DaySchema,
    PriorityAlarmsSchema,
    StatusSchema,
    TreatedEventsSchema,
    TreatedEvents1DaySchema,    
    AEPSchema,
    interpolPCConfigSchema,
    BasicAlarmsSchema,
    AlarmsLossesSchema,
    WindSpeedCorrectionsSchema,
    ComponentAvailabilities1DaySchema,
    PerformanceRatioSchema,
    ComponentAvailabilities1DaySchema,
    BasicInput1minSchema,
    Oper1minSchema,
    DynamicYawSchema,
    MaxPowerMisallignmentSchema,
    LapmAnalysisSchema,
    PitchSchema,
    MetMastSchema,
    StatusMetMastSchema,
    TowerAccelerationSchema
]
