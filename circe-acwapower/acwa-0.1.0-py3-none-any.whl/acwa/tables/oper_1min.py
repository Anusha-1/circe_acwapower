"""
acwa.tables.oper_1min

Validation schema for oper_1min table
"""

from datetime import datetime

import pandera as pa
from pandera.typing import Series

class Oper1minSchema(pa.DataFrameModel):
    """Schema for table oper_1min"""

    id_wf: Series[int] = pa.Field() # Wind Farm
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    timestamp: Series[datetime] = pa.Field() # Timestamp
    wind_speed: Series[float] = pa.Field(nullable=True) # Wind Speed
    power: Series[float] = pa.Field(nullable=True) # Power
    temperature: Series[float] = pa.Field(nullable=True) # Temperature
    wind_direction: Series[float] = pa.Field(nullable=True) # Wind direction
    nacelle_direction: Series[float] = pa.Field(nullable=True) # Nacelle direction
    rotor_rpm: Series[float] =pa.Field(nullable=True) # Rotor RPM
    sector_name: Series[str] = pa.Field(nullable=True)

    density: Series[float] = pa.Field(gt=0, nullable= True)
    wind_speed_corrected: Series[float] = pa.Field(nullable=True)
    cp: Series[float] = pa.Field(nullable=True,ge=0) # Cp Power/0.5*ro*A*V**3

    code: Series[int] = pa.Field() # Alarm code

    ## Yaw
    angle_deviation: Series[float] = pa.Field(nullable=True, le=180, gt=-180)
    angle_deviation_sector: Series[str] = pa.Field(nullable=True)
    angle_deviation_sign: Series[int] = pa.Field(nullable=True, isin=[-1,1])

    ## Temperature
    controller_temperature: Series[float] = pa.Field(nullable=True)
    gear_temperature: Series[float] = pa.Field(nullable=True)
    generator_temperature: Series[float] = pa.Field(nullable=True)
    grid_temperature: Series[float] = pa.Field(nullable=True)
    hvtrafo_temperature: Series[float] = pa.Field(nullable=True)
    hydraulic_temperature: Series[float] = pa.Field(nullable=True)
    nacelle_temperature: Series[float] = pa.Field(nullable=True)
    spinner_temperature: Series[float] = pa.Field(nullable=True)

    # Add more ...