"""
acwa.tables.basic_input_10min

Validation schema for input_10min table
"""

from datetime import datetime

import pandera as pa
from pandera.typing import Series

class BasicInput10minSchema(pa.DataFrameModel):
    """Schema for table input_10min"""

    id_wf: Series[int] = pa.Field() # Wind Farm
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    timestamp: Series[datetime] = pa.Field() # Timestamp
    wind_speed: Series[float] = pa.Field(nullable=True) # Wind Speed
    power: Series[float] = pa.Field(nullable=True) # Power
    temperature: Series[float] = pa.Field(nullable=True) # Temperature
    wind_direction: Series[float] = pa.Field(nullable=True) # Wind direction
    nacelle_direction: Series[float] = pa.Field(nullable=True) # Nacelle direction
    rotor_rpm: Series[float] =pa.Field(nullable=True) # Rotor RPM
    generator_rpm: Series[float] = pa.Field(nullable=True) # Generator RPM

    controller_temperature: Series[float] = pa.Field(nullable=True)
    gear_temperature: Series[float] = pa.Field(nullable=True)
    generator_temperature: Series[float] = pa.Field(nullable=True)
    grid_temperature: Series[float] = pa.Field(nullable=True)
    hvtrafo_temperature: Series[float] = pa.Field(nullable=True)
    hydraulic_temperature: Series[float] = pa.Field(nullable=True)
    nacelle_temperature: Series[float] = pa.Field(nullable=True)
    spinner_temperature: Series[float] = pa.Field(nullable=True)

    # Add more ?...