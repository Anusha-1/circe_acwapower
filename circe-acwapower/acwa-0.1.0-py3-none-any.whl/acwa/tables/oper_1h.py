"""
acwa.tables.oper_1h

Validation schema for oper_1h table
"""

from datetime import date

import pandera as pa
from pandera.typing import Series

class Oper1hSchema(pa.DataFrameModel):
    """Schema for table oper_1h"""

    id_wf: Series[str] = pa.Field() # Wind Farm
    id_wtg: Series[int] = pa.Field() # Turbine id
    id_wtg_complete: Series[str] = pa.Field() # Complete turbine id 

    hour: Series[date] = pa.Field() # Datetime until hour
    energy: Series[float] = pa.Field() # Energy produced (MWh)
    losses: Series[float] = pa.Field() # Energy lost (MWh)
    cp: Series[float] = pa.Field() # Cp average
    efficiency: Series[float] = pa.Field(le=1) # Power/(Power + Losses)
    performance: Series[float] = pa.Field() # Power / Power according manufacturer

    # Yaw deviations
    yaw_deviations_0_5: Series[int] = pa.Field(ge=0, le=60)
    yaw_deviations_0_neg5: Series[int] = pa.Field(ge=0, le=60)
    yaw_deviations_5_10: Series[int] = pa.Field(ge=0, le=60)
    yaw_deviations_neg5_neg10: Series[int] = pa.Field(ge=0, le=60)
    # Which segments to consider?

    # Direction changes
    nacelle_direction_changes: Series[int] = pa.Field(ge=0, le=60) # Count nacelle changes (above a threshold)
    wind_direction_changes: Series[int] = pa.Field(ge=0, le=60)

    # Add more ...
    