"""
acwa.config.temp_signals

Configuration of temperature signals to consider
"""

LST_TEMP_SIGNALS = [
    "controller_temperature",
    "gear_temperature",
    "generator_temperature",
    "grid_temperature",
    "hvtrafo_temperature",
    "hydraulic_temperature",
    "nacelle_temperature",
    "spinner_temperature",
]

QUANTILES = {
    'max': 0.975, 
    'min': 0.025,
    'median': 0.5
}

FEATURES = [
    'power', 
    'ambient_temperature', 
    'component_temperature_deriv'
]