"""
acwa.yaw.dynamic.reference

Compute direction of nacelle groups
"""

import math

import pandas as pd
from scipy.stats import circmean

def custom_circular_mean(angles: pd.Series) -> float:
    """
    Custom aggregation function for circular mean, using scipy function
    https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.circmean.html#scipy.stats.circmean

    Args:
        angles (pd.Series): Series of angles to average

    Returns:
        float: Average in degrees (from 0 to 360)
    """

    rad = [math.radians(x) for x in angles]
    mean_rad = circmean(rad, nan_policy='omit')    
    return math.degrees(mean_rad)

def calculate_nacelle_group_direction(
        df_1min: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate mean nacelle direction per group and timestamp

    Args:
        df_1min (pd.DataFrame): Dataframe with 1min data. Needs the columns:
            "timestamp", "id_group_complete" and "nacelle_direction"

    Returns:
        pd.DataFrame: Dataframe with nacelle average direction per group and
            timestamps
    """
    
    df_ref = df_1min\
        .groupby(['timestamp', 'id_group_complete'])\
        .agg({'nacelle_direction': custom_circular_mean})\
        .reset_index()

    return df_ref
