"""
acwa.error

Custom error classes
"""

from .database import DatabaseError

__all__ = [DatabaseError]
