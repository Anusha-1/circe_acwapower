"""
acwa.scripts.operational

Module to analyze data in real-time
"""

from .basic import main as update_operational_data_basic
from .min_1 import main as update_operational_1min_data

__all__ = [
    update_operational_1min_data,
    update_operational_data_basic
]