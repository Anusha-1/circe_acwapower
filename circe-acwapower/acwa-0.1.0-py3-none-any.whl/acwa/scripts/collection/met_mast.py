"""
acwa.scripts.collection.met_mast

Script to collect the met mast data
"""

import logging

import acwa.data as data

from acwa.config import read_config
from acwa.db import read_table_as_df, check_table, run_query
from acwa.log import format_basic_logging


def main(incremental=True):
    """
    Compilate and standarize met_masts data

    Args:
        incremental (bool, optional): If True, loads only new data. If False,
            loads all. Defaults to True.
    """

    config = read_config()
    format_basic_logging(config["log"])

    logging.info("----------- START SCRIPT: collection.met_mast --------------")

    output_table_name = "oper_met_mast"
    output_schema = "vis"

    logging.info("Load groups Configuration")
    df_wtg_config = read_table_as_df("wtg_config", config["db"], "vis")
    df_wf_config = read_table_as_df("wf_config", config["db"], "vis")
    df_wtg_config = df_wtg_config.merge(
        df_wf_config[["id_wf", "tz_alarms"]], how="left", on="id_wf"
    )
    lst_met_mast = list(set(df_wtg_config["met_mast_id"]))

    logging.info("Initializing loop for each group")
    for met_mast_id in lst_met_mast:
        wf = df_wtg_config[df_wtg_config["met_mast_id"] == met_mast_id].iloc[0][
            "wf_name"
        ]
        # try:
        logging.info(f"Collecting data from {met_mast_id} met mast")

        logging.info(f"Checking if table {output_table_name} exists")
        check = check_table(output_table_name, config["db"], output_schema)

        if check and incremental:
            logging.info(
                "Table exists. Checking if it contains data from this met mast"
            )
            df_existing_ids = run_query(
                "select_distinct_met_mast", config["db"], returns="Dataframe"
            )
            check_wind_farm = met_mast_id in list(df_existing_ids["met_mast_id"])

            if check_wind_farm:
                logging.info(f"Met mast {met_mast_id} exists.")

                timezone = df_wtg_config[
                    df_wtg_config["met_mast_id"] == met_mast_id
                ].iloc[0]["tz_alarms"]
                data.update_input_met_mast(
                    config["db"],
                    met_mast_id,
                    wf,
                    timezone,
                    output_table_name,
                    output_schema,
                )

            else:
                logging.info("Group does not exist. Reading the whole data set")
                data.append_input_met_mast(
                    config["db"], met_mast_id, wf, output_table_name, output_schema
                )

        else:
            logging.info("Table doesn't exist. Reading the whole data set")
            data.append_input_met_mast(
                config["db"],
                met_mast_id,
                wf,
                output_table_name,
                output_schema,
                if_exists="replace",
            )

            incremental = True  # After creating the new table, we change the flag
            # At next iterations, it will detect that the
            # new wind farms don't exist in table.

        # except Exception as error:
        #     logging.error(f"Unable to collect data for {met_mast_id}: {error}")


if __name__ == "__main__":
    main(incremental=True)
