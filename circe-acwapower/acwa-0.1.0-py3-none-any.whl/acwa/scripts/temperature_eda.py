"""
acwa.scripts.eda

Script to perform a fast EDA over temperature signals
"""

import logging
import pathlib

import pandas as pd

import acwa.db as db
from acwa.config import read_config
from acwa.log import format_basic_logging

from acwa.visualization import (
    plot_all_turbines,
    plot_temp_time_series,
    plot_temp_distributions,
    plot_temp_vs_power
)

def main():

    config = read_config()
    format_basic_logging(config)
    output_folder = "data/output/reliability"

    logging.info("Reading data")
    df = db.read_table_as_df(
        "static_input_1min_Khalladi", 
        config['db'], 
        'raw', 
        chunksize=100000,
        verbose=True)
    
    logging.info("Format")
    df['datetime'] = pd.to_datetime(df['ttimestamp'])
    lst_temp_cols = list(filter(
        lambda x: 'temperature' in x, df.columns))
    lst_temp_groups = list(set([x.split('_')[0] for x in lst_temp_cols]))
    lst_temp_groups.sort()

    logging.info("Plot timeseries")
    for temp in lst_temp_cols:
        logging.info(f" --> {temp}")
        fig = plot_all_turbines(
            df,
            plot_temp_time_series,
            turbine_id_col='turbine_id',
            temp_col=temp
        )

        output_path = pathlib.Path(output_folder, f"timeseries_{temp}.html")
        fig.write_html(output_path, full_html=False, include_plotlyjs='cdn')

    logging.info("Plot distibutions")
    for group in lst_temp_groups:
        logging.info(f" --> {group}")
        fig = plot_all_turbines(
            df,
            plot_temp_distributions,
            turbine_id_col='turbine_id',
            lst_temp_cols = lst_temp_cols,
            group = group
        )

        output_path = pathlib.Path(output_folder, f"distribution_{group}.html")
        fig.write_html(output_path, full_html=False, include_plotlyjs='cdn')

    logging.info("Plot scatter")
    for group in lst_temp_groups:
        logging.info(f" --> {group}")
        fig = plot_all_turbines(
            df,
            plot_temp_vs_power,
            turbine_id_col='turbine_id',
            lst_temp_cols = lst_temp_cols,
            group = group,
            samples = 2000
        )

        output_path = pathlib.Path(output_folder, f"scatter_{group}.html")
        fig.write_html(output_path, full_html=False, include_plotlyjs='cdn')

if __name__ == "__main__":
    main()
