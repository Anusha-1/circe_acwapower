"""
acwa.scripts

Module with scripts to be place as azure functions
"""

from .metadata import (
    upload_alarms_metadata,
    upload_wind_farms,
    upload_groups,
    upload_turbines,
    upload_densities,
    upload_variables,
    upload_sectors,
    
    upload_all_metadata
)

from .power_curves import (
    upload_manufacturer_power_curves,
    generate_power_curves,
    interpolate_power_curves,
)

from .static_load import(
    load_1_min_static_data,
    load_10_min_static_data,
    load_alarms_static_data,
    load_met_mast_static_data,
    load_pitch_static_data,
    load_tower_acceleration_static_data
)

from .dynamic_load import (
    load_1_min_dynamic_data,
    load_10_min_dynamic_data,
    load_alarms_dynamic_data,
    load_met_mast_dynamic_data,
    load_pitch_dynamic_data,
    load_tower_acceleration_data
)

from .collection import (
    collect_alarms,
    collect_1_min,
    collect_10_min,
    collect_pitch,
    collect_met_mast,
    collect_tower_acceleration
)

from .operational import (
    update_operational_1min_data,
    update_operational_data_basic
)

from .status import (
    update_status_turbine,
    update_status_met_mast
)

from .reliability import (
    fit_quantiles,
    predict_quantiles
)



from .operational_losses import main as update_operational_data_losses
from .operational_stats import main as update_operational_data_stats
from .availabilities import main as update_availabilities
from .max_power_misallignment import main as obtain_max_power_misallignments
from .lapm_analysis import main as analyze_lapm
from .dynamic_yaw import main as calculate_dynamic_yaw

from .performance_ratio import main as calculate_performance_ratio

from .allocation import main as allocate_time_and_losses

__all__ = [

    ## Metadata scripts
    upload_alarms_metadata,
    upload_wind_farms,
    upload_groups,
    upload_turbines,
    upload_densities,
    upload_variables,
    upload_sectors,
    upload_all_metadata,

    ## Power Curve scripts
    upload_manufacturer_power_curves,
    generate_power_curves,
    interpolate_power_curves,

    ## Static Load scripts
    load_1_min_static_data,
    load_10_min_static_data,
    load_alarms_static_data,
    load_met_mast_static_data,
    load_pitch_static_data,
    load_tower_acceleration_static_data,

    ## Dynamic Load scripts
    load_1_min_dynamic_data,
    load_10_min_dynamic_data,
    load_alarms_dynamic_data,
    load_met_mast_dynamic_data,
    load_pitch_dynamic_data,
    load_tower_acceleration_data,

    ## Collection
    collect_alarms,
    collect_1_min,
    collect_10_min,
    collect_pitch,
    collect_met_mast,
    collect_tower_acceleration,

    ## Operational
    update_operational_1min_data,
    update_operational_data_basic,   

    ## Status
    update_status_turbine,
    update_status_met_mast,

    ## Reliability
    fit_quantiles,
    predict_quantiles,

     
    update_operational_data_losses,
    update_operational_data_stats,
    update_availabilities,    
    obtain_max_power_misallignments,
    calculate_performance_ratio,
    analyze_lapm,
    calculate_dynamic_yaw,
    allocate_time_and_losses
]
