"""
acwa.scripts.metadata.variables

Script to upload the metadata table with oper_10min variables
"""

import logging

import pandas as pd

from acwa.config import read_config, LST_TEMP_SIGNALS
from acwa.log import format_basic_logging
from acwa.data import write_variables_table
from acwa.db import write_df_as_table

def main():


    config = read_config()
    format_basic_logging(config['log'])

    logging.info("------------- START SCRIPT: metadata.variables -------------")

    logging.info("Table variables")
    write_variables_table(config['db'])

    logging.info("Temp signals")
    df = pd.DataFrame()
    df['variable'] = LST_TEMP_SIGNALS
    write_df_as_table(
        df, config['db'], 'vis', 'temperature_signals', 
        index=False, if_exists='replace')

    logging.info("----------------------- FINISH -----------------------------")

if __name__ == "__main__":
    main()
