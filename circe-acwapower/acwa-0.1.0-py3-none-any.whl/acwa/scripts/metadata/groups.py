"""
acwa.scripts.metadata.groups

Script to upload groups metadata
"""

from datetime import datetime
import logging
import pathlib

import pandas as pd

from acwa.config import read_config
from acwa.db import write_df_as_table
from acwa.files import read_file
from acwa.log import format_basic_logging


def main():

    # NOTE: Make sure you have these files inside your file_storage.root_path
    # (Check your configuration at config/main.yml)
  
    # Configuration and logger
    config = read_config()
    format_basic_logging(config['log'])

    logging.info("--------------- START SCRIPT: metadata.groups --------------")

    logging.info("Read file")
    input_path = pathlib.Path(
        "input", 
        "metadata",
        "groups.csv")    
    
    df = pd.read_csv(
        read_file(input_path, config['file_storage'], container='data')
    )

    # logging.info("Format")
    # df['contractual_date'] = df['contractual_date'].apply(
    #     lambda x: datetime.strptime(x, "%Y-%m-%d").date()
    # )

    logging.info("Write")
    write_df_as_table(
        df, 
        config['db'], 
        "vis", 
        "groups", 
        if_exists="replace",
        chunksize=10000,
        index=False)


if __name__ == "__main__":
    main()
