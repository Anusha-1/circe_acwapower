"""
acwa.scripts.metadata

Collection of sctipts to upload metadata information
"""

from .alarms import main as upload_alarms_metadata
from .densities import main as upload_densities
from .groups import main as upload_groups
from .sectors import main as upload_sectors
from .turbines import main as upload_turbines
from .variables import main as upload_variables
from .wind_farms import main as upload_wind_farms

def upload_all_metadata():
    """Runs all the script to upload metadata"""
    upload_alarms_metadata()
    upload_wind_farms()
    upload_groups()
    upload_turbines()
    upload_densities()
    upload_variables()
    upload_sectors()
    
__all__ = [
    upload_alarms_metadata,
    upload_wind_farms,
    upload_groups,
    upload_turbines,
    upload_densities,
    upload_variables,
    upload_sectors,    

    upload_all_metadata
]