
import logging
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd

# from datetime import datetime

# import acwa.performance_ratio as perf_r

from acwa.config import read_config
from acwa.db import read_table_as_df, write_df_as_table 
from acwa.log import format_basic_logging

from acwa.tables import PerformanceRatioSchema



def generate_time_limits_with_timestamps(contractual_date):
    # Initialize the dictionary to store time limits
    time_limits = {}

    # Convert the input contractual_date (string format 'YYYY-MM-DD') to a datetime object
    start_date = contractual_date   #datetime.strptime(contractual_date, '%Y-%m-%d %H:%M:%S')

    # Get the current date and time
    today = datetime.today()

    # Initialize a counter to keep track of the year periods
    year_count = 1

    # Loop to create dictionary entries for each year from the contractual date till today
    while start_date < today:
        # Calculate the end date of the current year period (365 days later)
        end_date = start_date + relativedelta(years=1)

        # Add the current year period to the dictionary with the format 'yyyy.mm-dd hh:mm:ss'
        time_limits[f'Year {year_count}'] = {
            'start_date': start_date.strftime('%Y-%m-%d %H:%M:%S'),
            'end_date': end_date.strftime('%Y-%m-%d %H:%M:%S')
        }

        # Increment the year count and update the start date for the next iteration
        year_count += 1
        start_date = end_date

    return time_limits

def main(mode: str = 'incremental'):

    config = read_config()
    format_basic_logging(config['log'])

    logging.info("Starting script: performance ratio")

    logging.info("Load data")
    wtg_config = read_table_as_df("wtg_config", config['db'], "vis")   
    # alarms_metadata= read_table_as_df("alarms_metadata", config['db'], "vis")
    treated_events = read_table_as_df('treated_events',config['db'],'vis')

    wtg_lst = wtg_config['id_wtg_complete']
    wtg_config = wtg_config.set_index('id_wtg_complete')
    wtg_config['maintenance_hours'] = 80 ## i think this shall be settled into wtg_config table or wf or group_config idk
      
    # lst_of_alarms = alarms_metadata[alarms_metadata['classification'] == 'Maintenance']
    # lst_of_alarms = alarms_metadata[alarms_metadata['priority'] == 7]
    maint_dict = {}
    for turbine in wtg_lst:
        
        contractual_date=wtg_config.loc[turbine, 'contractual_date']
        time_limits = generate_time_limits_with_timestamps(contractual_date)
        maint_dict[turbine] = {}
        for year, dates in time_limits.items():
            aux_df = treated_events.copy()
            aux_df = aux_df[
                (aux_df['id_wtg_complete']== turbine) & 
                (aux_df['classification']== 'Maintenance') &
                (aux_df['end_datetime'] >= dates['start_date']) &
                (aux_df['start_datetime'] <= dates['end_date'])]
            maint_hours = aux_df['duration'].sum()/3600
            maint_dict[turbine][year] = maint_hours
    
    data = [(turbine, year, value) for turbine, years in maint_dict.items() for year, value in years.items()]



    print(maint_dict)

if __name__ == "__main__":
    main()


