"""
acwa.scripts.static_load.met_mast

Script to create raw static table with met mast data
"""

import logging
import pathlib

from acwa.config import read_config
from acwa.db import write_df_as_table, read_table_as_df
from acwa.files import read_excel
from acwa.log import format_basic_logging

def main():

    # NOTE: Make sure you have these files inside your file_storage.root_path
    # (Check your configuration at config/main.yml)

    # Configuration and logger
    config = read_config()
    format_basic_logging(config['log'])
    
    logging.info("------------ START SCRIPT: static_load.met_mast ------------")

    
    logging.info("Loading met mast metadata")
    met_mast_lst = ['Kh_1','Az_1']
    mast_dict = {
        'Kh_1': 'MET MAST DATA OF 2023.xlsx', 
        'Az_1': 'MET MAST DATA OF 2023.xlsx'
        }
    
    for mast in met_mast_lst:
        logging.info(f"Loading {mast} met mast data")
        input_path = pathlib.Path(
            "input", 
            "Historical data", 
            mast_dict[mast])
        df = read_excel(input_path, config['file_storage'], container='data')
        
        logging.info("Writting mast met mast data")
        write_df_as_table(
                df, 
                config['db'], 
                "raw", 
                f'static_met_mast_{mast}', 
                if_exists='replace',
                index=False,
                chunksize=10000)

if __name__ == "__main__":
    main()
