"""
acwa.scripts.status

Module with scripts to obtain most updated status
"""

from .met_mast import main as update_status_met_mast
from .turbine import main as update_status_turbine

__all__ = [
    update_status_met_mast,
    update_status_turbine
]
