"""
acwa.scripts.reliability.fit_models

Script to fit Quantile Regression models to each temperature signals
"""

from datetime import timedelta
import logging

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import QuantileRegressor
from sklearn.pipeline import make_pipeline

import acwa.data as data
import acwa.db as db
import acwa.reliability as rel

from acwa.config import read_config
from acwa.log import format_basic_logging


def main(
        n_samples: int = 100000, 
        lst_signals: list[str] | None = None,
        period: timedelta = timedelta(days=60)):
    """
    Fit Reliability QuantileRegression models

    Args:
        n_samples (int, optional): Max number of total samples to consider for 
            fitting. Defaults to 100000.
        lst_signals (list[str] | None, optional): List of temperature signals to
             fit. If None, fit all. Defaults to None.
        period (timedelta, optional): Period of data to consider. 
            Defaults to timedelta(days=60).
    """

    config = read_config()
    format_basic_logging(config["log"])

    logging.info("-------- START SCRIPT: reliability.fit_models --------------")

    logging.info("Read data")
    df_data = data.obtain_reliability_input(
        config['db'], period = period)
    update_timestamp = df_data['timestamp'].max()

    logging.info("Obtain combinations of signal, group and quantile to fit")
    df_wtg_config = db.read_table_as_df("wtg_config", config['db'], "vis")
    df_full_index = rel.obtain_full_index_of_reliability_models(
        df_wtg_config, lst_signals = lst_signals)
    df_full_index = rel.establish_priority(df_full_index, config['db'])
    
    for i, row in df_full_index.iterrows():

        signal = row['signal']
        group = row['group']
        oper_stat = row['oper_stat']
        quantile = row['quantile']

        logging.info(f"Fitting model: {signal} | {group} | {oper_stat}")

        df_aux = data.format_features_for_reliability(
            df_data, signal
        )
        X, y = data.split_Xy_for_reliability(df_aux, group, samples=n_samples)
        qr = make_pipeline(
            StandardScaler(), 
            QuantileRegressor(quantile=quantile, alpha=0))
        qr.fit(X, y)

        logging.info(f"Saving model to pickle file for {signal} | {group} | {oper_stat}")
        rel.save_reliability_model_as_pickle(
            signal, group, oper_stat, qr, config['file_storage']
        )
        logging.info(f"Model {signal} | {group} | {oper_stat} fitted")

        logging.info("Updating model table")
        df_full_index.at[i, "last_update"] = update_timestamp
        db.write_df_as_table(
            df_full_index, config['db'], 'intermediate', 'reliability_models',
            index=False, if_exists = 'replace')
        # Note: I am assuming the table is going to be small, so we can replace
        # the entire table at each iteration, even if it is only to change one
        # row

if __name__ == "__main__":
    main()
