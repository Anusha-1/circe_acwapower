"""
acwa.scripts.reliability.predict

Predict temperature operative ranges
"""

import logging

import numpy as np
import pandas as pd

import acwa.data as data
import acwa.reliability as rel

from acwa.config import read_config, LST_TEMP_SIGNALS, QUANTILES, FEATURES
from acwa.db import check_table
from acwa.log import format_basic_logging


def main(incremental=True):
    config = read_config()
    format_basic_logging(config["log"])

    logging.info("----------- START SCRIPT: reliability.predict --------------")

    if not check_table("reliability_ts", config["db"], "intermediate"):
        incremental = False

    logging.info("Loading data to predict")
    df_data = data.obtain_reliability_input(
        config["db"], incremental=incremental)
    
    if len(df_data) == 0:
        logging.warning("No new data to predict")
        return None    

    lst_groups = list(set(df_data["id_group_complete"]))
    lst_groups.sort()
    df_final_results = df_data[
        ["id_wtg_complete", "timestamp", "wind_speed", "power", "temperature"]
    ]

    for signal in LST_TEMP_SIGNALS:
        df_aux = data.format_features_for_reliability(
            df_data, signal, extra_cols=["timestamp", "id_wtg_complete"]
        )

        lst_df_groups = []
        for group in lst_groups:
            df_extra = df_aux[
                ["timestamp", "id_wtg_complete", "component_temperature"]
            ].copy()[df_aux["id_group_complete"] == group]
            X, _ = data.split_Xy_for_reliability(
                df_aux, group, clean_data_for_fitting=False
            )

            X_complete = pd.concat([df_extra, X], axis=1)
            X_complete = X_complete.replace([np.inf, -np.inf], np.nan)
            X_complete = X_complete.dropna(subset=FEATURES, how="any")
            df_results = X_complete.copy()
            for quant in QUANTILES.keys():
                logging.info(
                    f"Predicting with model for {signal} | {group} | {quant} "
                )
                df_results[f"{signal}_{quant}"] = rel.predict_reliability(
                    X_complete[FEATURES],
                    signal,
                    group,
                    quant,
                    config["file_storage"],
                )

            df_results = df_extra.merge(
                df_results[
                    [
                        "id_wtg_complete",
                        "timestamp",
                        f"{signal}_max",
                        f"{signal}_min",
                        f"{signal}_median",
                    ]
                ],
                how="left",
                on=["id_wtg_complete", "timestamp"],
            )
            df_results = df_results.rename(
                columns={"component_temperature": signal}
            )
            df_results[f"{signal}_over"] = (
                df_results[signal] > df_results[f"{signal}_max"]
            )
            lst_df_groups.append(df_results)

        df_final_results = df_final_results.merge(
            pd.concat(lst_df_groups),
            on=["id_wtg_complete", "timestamp"],
            how="left",
        )

    logging.info("Add power group")
    df_final_results = rel.add_power_group(
        df_final_results, config['db']
    )

    logging.info("Writing predictions")
    data.write_reliability_ts(df_final_results, incremental, config["db"])

if __name__ == "__main__":
    main(incremental=False)
