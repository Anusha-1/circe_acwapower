"""
acwa.scripts.aggregation

Module with scripts to aggregate results
"""

