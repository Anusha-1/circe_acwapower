
from datetime import datetime, timedelta
import pytz

def define_time_limits(now: datetime) -> list[dict]:
    """
    Define the time limits for the calculation of power curves

    Args:
        now (datetime): Datetime to consider as the current moment

    Returns:
        list[dict]: List of dictionaries, each one defining the needed arguments
            to generate a power curve: start, end, name and short
    """

    utc = pytz.timezone('UTC')
    current_year = now.year
    current_month = now.month

    time_limits = [
        {
            "start": now - timedelta(days=180),
            "end": now - timedelta(days=0),
            "concept": "Historical",
            "period": "6 months",
            "short": "H6",
        },  # Historical
        {
            "start": now - timedelta(days=360),
            "end": now - timedelta(days=0),
            "concept": "Historical",
            "period": "12 months",
            "short": "H12",
        },  # Historical
        {
            "start": now - timedelta(days=60),
            "end": now,
            "concept": "Recent",
            "period": "60 days",
            "short": "R60",
        },  # Recent
        {
            "start": datetime(current_year, 1, 1, 0, 0, 0, tzinfo=utc),
            "end": now,
            "concept": "Recent",
            "period": "YTD",
            "short": "RY"
        },  # YTD
        {
            "start": datetime(current_year, current_month, 1, 0, 0, 0, tzinfo=utc),
            "end": now,
            "concept": "Recent",
            "period": "MTD",
            "short": "RM"
        },  # MTD
    ]

    return time_limits
