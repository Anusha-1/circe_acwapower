"""
acwa.power_curves.time_limits

Module to define the time periods for the calculated power curves
"""

from datetime import datetime, timedelta
import pytz

def define_time_limits(now: datetime) -> list[dict]:
    """
    Define the time limits for the calculation of power curves

    Args:
        now (datetime): Datetime to consider as the current moment

    Returns:
        list[dict]: List of dictionaries, each one defining the needed arguments
            to generate a power curve: start, end, name and short
    """

    current_year = now.year
    current_month = now.month
    utc = pytz.timezone('UTC')

    time_limits = [
        {
            "start": now - timedelta(days=240),
            "end": now - timedelta(days=60),
            "concept": "Historical",
            "period": "6 months",
            "short": "H6",
        },  # Historical
        {
            "start": now - timedelta(days=420),
            "end": now - timedelta(days=60),
            "concept": "Historical",
            "period": "12 months",
            "short": "H12",
        },  # Historical
        {
            "start": datetime(current_year - 1, 1, 1, tzinfo=utc),
            "end": datetime(current_year, 1, 1, tzinfo=utc),
            "concept": "Historical",
            "period": "previous year",
            "short": "HPY",
        },  # Historical
        {
            "start": now - timedelta(days=60),
            "end": None,
            "concept": "Rolling",
            "period": "60 days",
            "short": "R60",
        },  # Rolling
        {
            "start": now - timedelta(days=30),
            "end": None,
            "concept": "Rolling",
            "period": "30 days",
            "short": "R30",
        },  # Rolling
        {
            "start": now - timedelta(days=15),
            "end": None,
            "concept": "Rolling",
            "period": "15 days",
            "short": "R15",
        },  # Rolling
    ]

    # Add months
    for i in range(current_month):
        month = i + 1
        month_start_date = datetime(current_year, month, 1, tzinfo=utc)
        time_limits.append(
            {
                "start": month_start_date,
                "end": datetime(current_year, month + 1, 1, tzinfo=utc),
                "concept": "Monthly",
                "period": month_start_date.strftime("%B"),
                "short": month_start_date.strftime("%b"),
            }
        )

    return time_limits
