"""
acwa.alarms.join.min_1

Module to do the merge with 1 min data
"""

from .all import join_alarms_and_1min_data

__all__ = [join_alarms_and_1min_data]
