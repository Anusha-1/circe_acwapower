"""
acwa.alarms.join.min_10

Organize the join of 10min data and alarms
"""

from .all import join_alarms_and_10min_data

__all__ = [join_alarms_and_10min_data]
