"""
acwa.mockup.dynamic_alarms_table

Module with function to create a dynamic raw  alarms stable by using the data 
from the static raw table
"""

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging
import pytz

import pandas as pd
from sqlalchemy import CursorResult

from acwa.db import (
    check_table,
    run_query,
    run_query_in_transaction,
    write_df_as_table
)
from acwa.mockup import correct_alarm_times

def write_dynamic_alarms_table(
    wf_name: str,
    output_table_name: str,
    config: dict | None = None,
    timezone: str = 'UTC',
    now: datetime | None = None
) -> None:
    """
    Creates/Updates the realtime alarms table for a given wind farm

    Args:
        wf_name (str): Name of the wind farm
        output_table_name (str): Name of the output table
        config (dict | None, optional): Configuration options. Defaults to None.
        timezone (str, optional): Timezone of the alarms data. Defaults to 'UTC'.
        now (datetime | None, optional): Temporal limit to consider. 
            If None, obtain present moment from system. Defaults to None
    """
    
    logging.info("Obtaining times")
    tz = pytz.timezone(timezone)
    now = now if now is not None else datetime.now()
    end_time = now.astimezone(tz) - relativedelta(year=2023)

    logging.info(f"Checking if table {output_table_name} exists")
    check = check_table(output_table_name, config["db"], "raw")

    if check:
        logging.info(f"Table {output_table_name} already exists")

        logging.warning("Delete of old entries not implemented")
        ## Persistance of this table?

        logging.info("Extracting last datetimes")
        df_last_times: pd.DataFrame = run_query(
            f"max_time_alerts_{wf_name}", config["db"], returns="Dataframe"
        )

        logging.info("Delete ongoing alarms")
        result: CursorResult = run_query_in_transaction(
            f"delete_ongoing_alarms_{wf_name}", config["db"], returns="Cursor"
        )
        logging.info(f"Rows deleted: {result.rowcount}")

        logging.info("Retrieve new data")
        if config["db"]["type"] == "SQLite":
            start_det = (
                datetime.strptime(
                    df_last_times["start_time"].iloc[0], "%Y-%m-%d %H:%M:%S.%f"
                )
                + timedelta(seconds=1)
            )
            end_det = (
                datetime.strptime(
                    df_last_times["end_time"].iloc[0], "%Y-%m-%d %H:%M:%S.%f"
                )
                + timedelta(seconds=1)
            )
        elif config["db"]["type"] == "Azure":
            start_det = (
                df_last_times["start_time"].iloc[0].to_pydatetime()
                + timedelta(seconds=1)
            )
            end_det = (
                df_last_times["end_time"].iloc[0].to_pydatetime()
                + timedelta(seconds=1)
            )

        df = run_query(
            f"read_new_alarms_{wf_name}",
            config["db"],
            params={
                "end": end_time.strftime("%Y-%m-%d %H:%M:%S"),
                "start_det": start_det.strftime("%Y-%m-%d %H:%M:%S"),
                "end_det": end_det.strftime("%Y-%m-%d %H:%M:%S"),
            },
            returns="Dataframe",
        )

        df = correct_alarm_times(df, 2023, end_time, tz)

        logging.info("Writing table")
        write_df_as_table(
            df,
            config["db"],
            "raw",
            output_table_name,
            index=False,
            if_exists="append",
        )
        
    else:

        logging.info(f"Table {output_table_name} does not exist")

        df: pd.DataFrame = run_query(
            f"read_alarms_{wf_name}",
            config["db"],
            params={"end": end_time.strftime("%Y-%m-%d %H:%M:%S")},
            returns="Dataframe",
        )

        df = correct_alarm_times(df, 2023, end_time, tz)

        logging.info("Writing table")
        write_df_as_table(
            df,
            config["db"],
            "raw",
            output_table_name,
            index=False,
            if_exists="replace",
        )
