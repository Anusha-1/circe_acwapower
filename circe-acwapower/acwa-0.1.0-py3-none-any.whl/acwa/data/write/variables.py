"""
acwa.data.write.variables

Write variables name in an independent table
"""

import pandas as pd

from acwa.db import write_df_as_table

def write_variables_table(config_db: dict):
    """
    Write variables table

    (ONLY FOR oper_10min, FOR THE MOMENT)

    Args:
        config_db (dict): Database configuration
    """

    lst_variables = [
        'wind_speed',
        'power',
        'temperature',
        'wind_direction',
        'nacelle_direction',
        'rotor_rpm',
        'generator_rpm',
        'lambda_parameter',
        'density',
        'loss',
        'cp',
        'production_ratio',
        'energy_availability',
        'manufacturer_producible',
        'historical_producible',
        'angle_deviation',
        'pitch_angle_average'
    ]


    df = pd.DataFrame()
    df['variable'] = lst_variables
    df['schema'] = 'vis'
    df['table'] = 'oper_10min'

    write_df_as_table(
        df[['schema', 'table', 'variable']], 
        config_db, "vis", "variables", if_exists="replace", index=False
    )
