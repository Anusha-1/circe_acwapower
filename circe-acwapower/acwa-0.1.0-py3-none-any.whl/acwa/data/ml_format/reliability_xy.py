"""
acwa.data.ml_format.reliability_xy

X/y split for reliability
"""

import numpy as np
import pandas as pd

from acwa.config import FEATURES

def split_Xy_for_reliability(
        df_data: pd.DataFrame,
        group: str,
        samples: int | None = None,
        clean_data_for_fitting: bool = True
) -> tuple[pd.DataFrame,pd.Series]:
    """
    Splits X/y for reliability models

    Args:
        df_data (pd.DataFrame): Data
        group (str): Id group complete
        samples (int | None): Number of samples to consider. If None, we 
            consider all the data

    Returns:
        - pd.DataFrame: Feature matrix
        - pd.Series: Ground truth
    """
    
    # Isolate data for particular group (models are group-wise)
    df = df_data[df_data['id_group_complete']==group].copy()
    
    # Clean data for fitting (remove infinite, NaN, ...)
    if clean_data_for_fitting:
        df = df.replace([np.inf, -np.inf], np.nan)
        df = df.dropna(subset=FEATURES + ['component_temperature'], how='any')

    # X and y split
    df = df[FEATURES + ['component_temperature']]
    if samples is not None and samples < len(df):
        df = df.sample(samples)
    X = df[FEATURES]
    X= X.rename(str, axis="columns")
    y = df['component_temperature']

    return X, y
