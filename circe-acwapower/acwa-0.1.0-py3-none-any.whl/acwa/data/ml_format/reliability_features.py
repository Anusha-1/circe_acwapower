"""
acwa.data.ml_format.reliability_features

Feature engineering for reliability Quantile Regression
"""

import pandas as pd

from acwa.config import FEATURES


def format_features_for_reliability(
    df_data: pd.DataFrame, signal: str, extra_cols: list[str] | None = None
) -> pd.DataFrame:
    """
    Prepare dataframe for reliability QR models

    Args:
            df_data (pd.DataFrame): Full data
            signal (str): Signal to evaluate
            extra_cols (list[str] | None, optional): List of extra columns to add,
                    beyond features. Defaults to None

    Returns:
            pd.DataFrame: Formatted dataframe
    """

    # Rename the "main" temperature as "ambient_temperature"
    # and add the signal to study as "component_temperature"
    df_aux = df_data.rename(
        columns={
            "temperature": "ambient_temperature",
            signal: "component_temperature",
        }
    )

    # Feature engineering, add the derivative of the component_temperature
    df_aux = df_aux.sort_values(by="timestamp")
    df_aux["component_temperature_deriv"] = (
        df_aux["component_temperature"]
        - df_aux.groupby("id_wtg_complete")["component_temperature"].shift(1)
    ) / 600

    # Return only the necessary columns
    cols_to_keep = ["id_group_complete"] + FEATURES + ["component_temperature"]
    if extra_cols is not None:
        cols_to_keep += extra_cols

    return df_aux[cols_to_keep].copy()
