"""
acwa.data.aggregate.pitch

Module to average blade pitch
"""

import pandas as pd

def average_blade_pitch(df: pd.DataFrame) -> pd.DataFrame:
    """
    Average the average pitch angle across all three blades

    Args:
        df (pd.DataFrame): Pitch angle data

    Returns:
        pd.DataFrame: Dataframe with 'id_wtg_complete', 'timestamp' and 
            'pitch_angle' (averaged)
    """


    df = df[df['statistic']=='avg']
    df_ave = df.groupby(['id_wtg_complete', 'timestamp']).agg(
        pitch_angle_average = ('pitch_angle', 'mean')
    ).reset_index()

    return df_ave
