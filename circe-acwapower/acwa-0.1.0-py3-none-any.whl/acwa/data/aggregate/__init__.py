"""
acwa.data.aggregate

Module to perform data aggregation (in days, months, etc)
"""

from .daily import aggregate_values_daily, add_daily_budget
from .pitch import average_blade_pitch

__all__ = [aggregate_values_daily,
           add_daily_budget,
           average_blade_pitch]
