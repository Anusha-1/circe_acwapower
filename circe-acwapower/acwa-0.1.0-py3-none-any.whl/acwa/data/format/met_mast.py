"""
acwa.data.format.pitch

Format met mast data
"""

import pandas as pd
import numpy as np

from acwa.tables import MetMastSchema

def format_met_mast_Kh_1(
        df: pd.DataFrame,
        met_mast_name: str,
        wf: str ) -> pd.DataFrame:
    """
    Format input met mast data from Khalladi.

    Args:
        df (pd.DataFrame): Input dataframe
        met_mast_name (str): Name of the Met Mast

    Returns:
        pd.DataFrame: Output dataframe
    """

    # Initial rename of columns (for simplicity)
    # df = df.rename(columns=rename_columns)

    # Pivot in turbines
    df_melted = pd.melt(
        df, id_vars=["datetime"], var_name="variable", value_name="value")  
    
    # Usar una expresión regular para separar la columna 'variable' en 'variable' y 'type'
    df_melted['type'] = df_melted['variable'].str.extract(r'(MinValue|MaxValue|AvgValue|Samples)$')
    df_melted['variable'] = df_melted['variable'].str.replace(r'_(MinValue|MaxValue|AvgValue|Samples)$', '', regex=True)
   
    # Usar pivot para volver a formar el DataFrame en formato ancho
    df = df_melted.pivot(index=['datetime','type'], columns=['variable'], values='value').reset_index()
    df = df[['datetime', 'type', 'MET1_AirDensity1', 'MET1_AirPressure1', 'MET1_Battery', 'MET1_RH1', 'MET1_RainDet', 'MET1_Temp1', 'MET1_WindDir1', 'MET1_WindSpeed1']]
    dict_df = {
        'datetime':'timestamp', 
        'MET1_AirDensity1':'air_density',
        'MET1_AirPressure1': 'pressure',
        'MET1_Battery': 'battery', 
        'MET1_RH1': 'relative_humidity',
        'MET1_RainDet': 'rain',
        'MET1_Temp1': 'temperature',
        'MET1_WindDir1': 'wind_direction',
        'MET1_WindSpeed1':'wind_speed'
        }
    df = df.rename(columns=dict_df)

    df['met_mast_id'] = met_mast_name
    df['wf_name'] = wf
    df_aux = df[df['type']== 'Samples']

    df = df[df['type'] != 'Samples']

    dict_limits = {
        'air_density': {'min': 0, 'max': 3},
        'pressure': {'min': 600, 'max': 1200},
        'relative_humidity': {'min': 0, 'max': 120},
        'rain': {'min': -5000, 'max': 7000},
        'battery': {'min': 0, 'max': 20},
        'temperature': {'min': -60, 'max': 100},
        'wind_direction': {'min': 0, 'max': 365},
        'wind_speed': {'min': 0, 'max': 60}
    }
    for var,lim in dict_limits.items():

        min_value = lim['min']
        max_value =lim['max']
        df[var] = df[var].apply(lambda x: (x if(x >= min_value) & (x <= max_value) else np.nan) if x is not None else np.nan)   

    
    df = df[MetMastSchema.to_schema().columns.keys()]
    MetMastSchema.validate(df)
    
    df =  pd.concat([df,df_aux],ignore_index=True)
    df = df.sort_values(by=['timestamp','type']).reset_index()
    df = df.drop(columns=['index'])
    
    return df
