"""
acwa.data.format.input_10min

Format raw input 10 min data 
"""

import pandas as pd

from acwa.tables import BasicInput10minSchema

def format_10min_Khalladi(df: pd.DataFrame, id_wf: int) -> pd.DataFrame:
    """
    Format input data from Khalladi (i.e. rename and select columns)

    Args:
        df (pd.DataFrame): Input dataframe
        id_wf (int): Id of wind farm

    Returns:
        pd.DataFrame: Output dataframe
    """

    dict_old_to_new = {
        "datetime" : "timestamp",
        "ambient_windspeed" : "wind_speed",
        "ambient_winddir":"wind_direction",
        "grid_power":"power",
        "controller_hubtemperature":"temperature", ## There is no ambient_temperature in 10min data
        "turbine_id" :"id_wtg",
        'rotorsystem_rotorrpm':'rotor_rpm',
        'nacelle_direction': 'nacelle_direction',
        'generator_rpm': 'generator_rpm',
        'controller_toptemperature': 'controller_temperature',
        'gear_bearinghollowshaftgeneratortemperature': 'gear_temperature',
        'generator_phase1temperature': 'generator_temperature',
        'grid_inverterphase1temperature': 'grid_temperature',
        'hvtrafo_phase1temperature': 'hvtrafo_temperature',
        'hydraulic_oiltemperature': 'hydraulic_temperature',
        'nacelle_temperature': 'nacelle_temperature',
        'spinner_temperature': 'spinner_temperature'
        }

    df = df[dict_old_to_new.keys()]
    df = df.rename(columns=dict_old_to_new)
    df['id_wf'] = id_wf
    df['id_wtg_complete'] = df.apply(
        lambda row: f"{row['id_wf']}-{row['id_wtg']}",
        axis=1
    )

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df[BasicInput10minSchema.to_schema().columns.keys()]

    return df
