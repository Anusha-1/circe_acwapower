"""
acwa.data.format.pitch

Format pitch data
"""

import re

import pandas as pd

from acwa.tables import PitchSchema

def format_pitch_Khalladi(
        df: pd.DataFrame, 
        id_wf: int,
        pitch_limit: int) -> pd.DataFrame:
    """
    Format input pitch data from Khalladi.

    Args:
        df (pd.DataFrame): Input dataframe
        id_wf (int): Id of wind farm
        pitch_limit(int): Limit for pitch

    Returns:
        pd.DataFrame: Output dataframe
    """

    # Initial rename of columns (for simplicity)
    df = df.rename(columns=rename_columns)

    # Pivot in turbines and statistic
    df = pd.melt(df, id_vars=["timestamp"], var_name="variable", value_name="value")
    df["id_wtg"] = df["variable"].str.extract(r"(WTG\d{2})")[0]
    df["statistic"] = df["variable"].str.extract(r"_(min|max|avg|stddev)")[0]
    df = df.drop(columns=['variable'])
    
    # Add blade (in this case we don't have several blades)
    df['blade'] = 'all'

    # Reformat and rename
    df["id_wtg"] = df["id_wtg"].apply(lambda x: int(x[3:]))
    df['id_wf'] = id_wf
    df['id_wtg_complete'] = df.apply(
        lambda row: f"{row['id_wf']}-{row['id_wtg']}",
        axis=1
    )
    df = df.rename(columns={'value': 'pitch_angle'})    
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    ## Limit to pitch threshold
    df['value_limited'] = df['pitch_angle'].apply(lambda x: min(x, pitch_limit))
    df['limited'] = df['pitch_angle'] != df['value_limited']
    df['pitch_angle'] = df['value_limited']
    df = df.drop(columns=['value_limited'])

    ## Triplicate blades (Remove eventually)
    lst = []
    for blade in ['1','2','3']:
        df_aux = df.copy(True)
        df_aux['blade'] = blade 
        lst.append(df_aux)
    df = pd.concat(lst)    
    df = df.sort_values(by='timestamp')

    df = df[PitchSchema.to_schema().columns.keys()]

    return df

def rename_columns(col: str) -> str:
    """
    Auxiliary function to rename columns

    Args:
        col (str): Column name

    Returns:
        (str): New column name
    """

    if col == "PCTimeStamp":
        return "timestamp"
    
    # Regular expression
    match = re.match(r"(WTG\d{2})_.* (Min\.|Max\.|Avg\.|StdDev) \(\d+\)", col)
    if match:
        wtg, min_max = match.groups()
        return f"{wtg}_{min_max.lower().rstrip('.')}"
    
    # If pattern is not matched, return original name
    return col

