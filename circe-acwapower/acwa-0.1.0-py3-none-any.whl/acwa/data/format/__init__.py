

from .alarms import format_alarms_Khalladi
from .input_10min import format_10min_Khalladi 
from .input_1min import format_1min_Khalladi
from .pitch import format_pitch_Khalladi
from .met_mast import format_met_mast_Kh_1
from .tower_acceleration import format_tower_acceleration_Khalladi



dict_format_10min = {
    'Khalladi': format_10min_Khalladi,
    'Azerbaijan': format_10min_Khalladi
}

dict_format_1min = {
    'Khalladi': format_1min_Khalladi,
    'Azerbaijan': format_1min_Khalladi
}

dict_format_alarms = {
    'Khalladi': format_alarms_Khalladi,
    'Azerbaijan': format_alarms_Khalladi
}

dict_format_pitch = {
    'Khalladi': format_pitch_Khalladi,
    'Azerbaijan': format_pitch_Khalladi
}

dict_format_met_mast= {
    'Kh_1': format_met_mast_Kh_1,
    'Az_1': format_met_mast_Kh_1
}


dict_format_tower_acceleration= {
    'Khalladi': format_tower_acceleration_Khalladi,
    'Azerbaijan': format_tower_acceleration_Khalladi
}