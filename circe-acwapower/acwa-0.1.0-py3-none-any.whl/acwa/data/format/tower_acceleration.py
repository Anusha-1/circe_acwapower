"""
acwa.data.format.pitch

Format pitch data
"""

import re

import pandas as pd

from acwa.tables import TowerAccelerationSchema

def format_tower_acceleration_Khalladi(
        df: pd.DataFrame, 
        id_wf: int) -> pd.DataFrame:
    """
    Format input tower acceleration data from Khalladi.

    Args:
        df (pd.DataFrame): Input dataframe
        id_wf (int): Id of wind farm

    Returns:
        pd.DataFrame: Output dataframe
    """

    # Initial rename of columns (for simplicity)
    df = df.rename(columns=rename_columns)

    # Pivot in turbines and statistic
    df = pd.melt(df, id_vars=["timestamp"], var_name="variable", value_name="value")
    df["id_wtg"] = df["variable"].str.extract(r"(WTG\d{2})")[0]
    df['direction'] = df["variable"].str.extract(r"(TowerAcc (X_direction|Y_direction))")[0]
    df["statistic"] = df["variable"].str.extract(r"_(min|max|avg|std)")[0]
    df = df.drop(columns=['variable'])
    
    # Reformat and rename
    df["id_wtg"] = df["id_wtg"].apply(lambda x: int(x[3:]))
    df['id_wf'] = id_wf
    df['id_wtg_complete'] = df.apply(
        lambda row: f"{row['id_wf']}-{row['id_wtg']}",
        axis=1
    )
    # df = df.rename(columns={'value': 'pitch_angle'})    
    df['timestamp'] = pd.to_datetime(df['timestamp'])


    # df['limited'] = df['pitch_angle'] != df['value_limited']
    # df['pitch_angle'] = df['value_limited']
    # df = df.drop(columns=['value_limited'])


    df = df[TowerAccelerationSchema.to_schema().columns.keys()]

    return df

def rename_columns(col: str) -> str:
    """
    Auxiliary function to rename columns

    Args:
        col (str): Column name

    Returns:
        (str): New column name
    """

    if col == "PCTimeStamp":
        return "timestamp"
    
    # Regular expression
    match = re.match(r"(WTG\d{2})_(TowerAcc (X_direction|Y_direction)) (Min|Max|Avg|Std).*", col)
    if match:
        wtg, full_direction, direction, min_max = match.groups() 
        return f"{wtg}_{full_direction}_{min_max.lower().rstrip('.')}"
    
    # If pattern is not matched, return original name
    return col

