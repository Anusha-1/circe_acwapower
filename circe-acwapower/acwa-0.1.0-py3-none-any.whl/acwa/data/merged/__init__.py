"""
acwa.data.merged

Module to pre-build some merge of information
"""

from .reliability_input import obtain_reliability_input
from .turbine_contractual_dates import obtain_turbine_contractual_dates

__all__ = [
    obtain_reliability_input,
    obtain_turbine_contractual_dates]
