"""
acwa.data.merged.turbine_contractual_dates

Obtain contractual dates per turbine
"""

import pandas as pd

import acwa.db as db

def obtain_turbine_contractual_dates(config_db: dict) -> pd.DataFrame:
    """
    Obtain the contractual date for each turbine by merging the tables 
    wtg_config and groups

    (DEPRECATED: Contractual dates are now defined directly at wtg_config)

    Args:
        config_db (dict): Database configuration

    Returns:
        pd.DataFrame: Dataframe with columns: 'id_wtg_complete', 
            'contractual_date'
    """

    df_wtg_config = db.read_table_as_df(
        "wtg_config",
        config_db,
        "vis"
    )

    df_groups = db.read_table_as_df(
        "groups",
        config_db,
        "vis"
    )

    df_final = df_wtg_config.merge(
        df_groups,
        on="id_group_complete"
    )

    return df_final[['id_wtg_complete', 'contractual_date']]