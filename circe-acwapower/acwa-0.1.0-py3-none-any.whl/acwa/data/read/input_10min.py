"""
acwa.data.read_input_10min

Module to read input 10min data
"""

import pandas as pd

from acwa.data import transform_to_datetime
from acwa.db import run_query, read_table_as_df


def read_input_10min_data(incremental: bool, config_db: dict) -> pd.DataFrame:
    """
    Read input 10 min data

    Args:
        incremental (bool): If True, only reads data that has not been processed
            in oper_10min
        config_db (dict): Database configuration

    Returns:
        pd.DataFrame: Dataframe with 10-min data
    """

    if incremental:
        df: pd.DataFrame = run_query(
            "select_incremental_10min",
            config_db,
            returns="Dataframe"
        )
    else:
        df = read_table_as_df(
            "input_10min",
            config_db,
            "intermediate"
        )

    if config_db['type'] == 'SQLite':
        df = transform_to_datetime(
            df, "timestamp", "%Y-%m-%d %H:%M:%S.%f", "timestamp", drop_original_col=False)

    return df
