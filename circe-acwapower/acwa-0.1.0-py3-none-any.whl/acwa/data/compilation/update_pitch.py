"""
acwa.data.compilation.update_pitch

Module to update pitch data on a pre-existing table
"""

from datetime import datetime
import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_pitch
from acwa.db import run_query, write_df_as_table

def update_input_pitch(
        config_db: dict,
        id_wf: int,
        wf_name: str,
        timezone: str,
        pitch_limit: int
):
    """
    Update the table vis.pitch with new data on a specific wind 
    farm.

    Args:
        config_db (dict): Database configuration
        id_wf (int): Id of wind farm
        wf_name (str): Name of wind farm
        timezone (str): Timezone of the original data
        pitch_limit(int): Limit for pitch
    """

    output_table_name = "pitch"
    output_schema = 'intermediate'

    # Timezones
    utc = pytz.timezone('UTC')
    data_tz = pytz.timezone(timezone)

    logging.info("Extracting last datetime")
    max_datetime = run_query(
        "max_datetime_input_pitch",
        config_db,
        params={"wind_farm_id": id_wf},
        returns="Fetchall"
    )[0][0]
    if config_db["type"] == 'SQLite':
        max_datetime = utc.localize(
            datetime.strptime(max_datetime, "%Y-%m-%d %H:%M:%S.%f")) # Time in UTC
    else:
        max_datetime = utc.localize(max_datetime) # Time in UTC


    logging.info("Extracting recent data")
    df = run_query(
        f"read_dynamic_input_pitch_{wf_name}",
        config_db,
        params={"start": max_datetime.astimezone(data_tz)},
        returns='Dataframe'
    )       

    if len(df) > 0:
        logging.info("Format")
        df = dict_format_pitch[wf_name](df, id_wf, pitch_limit)
        
    
        logging.info("Transform timezone")
        df = transform_timezone(
            df, 
            "timestamp",
            data_tz,
            utc)   
        if config_db['type']=='Azure':
            df['timestamp'] = df['timestamp'].dt.tz_localize(None)
        
        # df = df[PitchSchema.to_schema().columns.keys()]
        # PitchSchema.validate(df)

        logging.info("Writting to table")
        write_df_as_table(
            df,                
            config_db,
            output_schema,
            output_table_name,
            index=False,
            chunksize=10000,
            if_exists = "append"
        )
