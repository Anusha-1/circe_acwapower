"""
acwa.data.compilation.append_new_10min

Module to append a new wind farm on input 10min
"""

import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_10min
from acwa.db import read_table_as_df, write_df_as_table

def append_new_input_10min(
        config_db: dict,
        id_wf: int,
        wf_name: str,
        timezone: str,
        if_exists: str = 'append'
):
    """
    Append a new wind farm on the table intermediate.input_10min.

    Args:
        config_db (dict): Database configuration
        id_wf (int): Id of wind farm
        wf_name (str): Name of wind farm
        timezone (str): Timezone of the original datas
        if_exists (str, optional): if_exists kwarg of write table. Defaults to
            "append" 
    """

    output_table_name = "input_10min"
    output_schema = 'intermediate'

    input_table_name = f"realtime_input_10min_{wf_name}"
    df = read_table_as_df(
        input_table_name,
        config_db,
        "raw",
    )

    logging.info("Format")
    df = dict_format_10min[wf_name](df, id_wf)

    logging.info("Transform timezone")
    df = transform_timezone(
        df, 
        "timestamp",
        pytz.timezone(timezone),
        pytz.timezone("UTC"))
    if config_db['type']=='Azure':
        df['timestamp'] = df['timestamp'].dt.tz_localize(None)

    logging.info("Writting to table")
    write_df_as_table(
        df,                
        config_db,
        output_schema,
        output_table_name,
        index=False,
        chunksize=10000,
        if_exists = if_exists
    )