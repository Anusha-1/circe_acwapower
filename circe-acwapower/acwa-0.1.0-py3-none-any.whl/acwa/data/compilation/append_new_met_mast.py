"""
acwa.data.compilation.append_pitch

Module to add pitch data
"""

import logging

from acwa.data.format import dict_format_met_mast
from acwa.db import read_table_as_df, write_df_as_table

def append_input_met_mast(
        config_db: dict,
        met_mast_name: str,
        wf: str,
        output_table_name: str,
        output_schema: str,
        if_exists: str= 'append'
):
    """
    Append met mast data for a wind farm on the table intermediate.met_mast

    Args:
        config_db (dict): Database configuration
        met_mast_name (str): Name of Met Mast
        if_exists (str, optional): if_exists kwarg of write table. Defaults to
            "append" 
    """

    input_table_name = f"realtime_met_mast_{met_mast_name}"
    df = read_table_as_df(
        input_table_name,
        config_db,
        "raw",
    )
    
    logging.info("Format")
    df = dict_format_met_mast[met_mast_name](df, met_mast_name,wf)

    logging.info("Writting to table")
    write_df_as_table(
        df,                
        config_db,
        output_schema,
        output_table_name,
        index=False,
        chunksize=10000,
        if_exists = if_exists
    )

