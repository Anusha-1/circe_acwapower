"""
acwa.data.compilation.update_met_mast.py

Module to update met mast input data on a pre-existing table
"""

from datetime import datetime
import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_met_mast
from acwa.db import run_query, write_df_as_table

def update_input_met_mast(
        config_db: dict,
        met_mast_id: str,
        group: str,
        timezone: str,
        output_table_name = str,
        output_schema = str
):
    """
    Update the table intermediate.input_met_mast with new data on a specific wind 
    farm.

    Args:
        config_db (dict): Database configuration
        met_mast_id (str): ID of the Met Mast to update
        timezone (str): Timezone of the original data
    """


    # Timezones
    utc = pytz.timezone('UTC')
    data_tz = pytz.timezone(timezone)

    logging.info("Extracting last datetime")
    max_datetime = run_query(
        "max_datetime_input_met_mast",
        config_db,
        params={"met_mast_id": met_mast_id},
        returns="Fetchall"
    )[0][0] 
    if config_db["type"] == 'SQLite':
        max_datetime = utc.localize(
            datetime.strptime(max_datetime, "%Y-%m-%d %H:%M:%S.%f")) # Time in UTC
    else:
        max_datetime = utc.localize(max_datetime) # Time in UTC

    logging.info(f"Extracting recent data {max_datetime}")
    df = run_query(
        f"read_dynamic_input_met_mast_{met_mast_id}",
        config_db,
        params={"start": max_datetime.astimezone(data_tz)}, ## Read in data tz
        returns='Dataframe'
    )    

    if len(df) >0:

        logging.info("Format")
        df = dict_format_met_mast[met_mast_id](df, met_mast_id, group)

        logging.info("Transform timezone")
        df = transform_timezone(
            df, 
            "timestamp",
            data_tz,
            utc)
        if config_db['type']=='Azure':
            df['timestamp'] = df['timestamp'].dt.tz_localize(None)

        logging.info("Writting to table")
        write_df_as_table(
            df,                
            config_db,
            output_schema,
            output_table_name,
            index=False,
            chunksize=10000,
            if_exists = "append"
        )
    else:
        logging.info(f'Table is updated for {met_mast_id}')
