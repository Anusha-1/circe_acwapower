"""
acwa.data.compilation.append_pitch

Module to add pitch data
"""

import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_tower_acceleration
from acwa.db import read_table_as_df, write_df_as_table

def append_input_tower_acceleration(
        config_db: dict,
        id_wf: int,
        wf_name: str,
        timezone: str,
        output_table_name:str,
        output_schema: str,
        if_exists: str = 'append'
):
    """
    Append pitch data for a wind farm on the table vis.pitch

    Args:
        config_db (dict): Database configuration
        id_wf (int): Id of wind farm
        wf_name (str): Name of wind farm
        timezone (str): Timezone of the original data
        pitch_limit(int): Limit for pitch
        if_exists (str, optional): if_exists kwarg of write table. Defaults to
            "append" 
    """


    # Timezones
    utc = pytz.timezone('UTC')
    data_tz = pytz.timezone(timezone)

    input_table_name = f"realtime_tower_acceleration_{wf_name}"
    df = read_table_as_df(
        input_table_name,
        config_db,
        "raw",
    )
    
    logging.info("Format")
    df = dict_format_tower_acceleration[wf_name](df, id_wf)

    logging.info("Transform timezone")
    df = transform_timezone(
        df, 
        "timestamp",
        data_tz,
        utc)   
    if config_db['type']=='Azure':
        df['timestamp'] = df['timestamp'].dt.tz_localize(None)

    # df = df[PitchSchema.to_schema().columns.keys()]
    # PitchSchema.validate(df)
    logging.info("Writting to table")
    write_df_as_table(
        df,                
        config_db,
        output_schema,
        output_table_name,
        index=False,
        chunksize=100000,
        if_exists = if_exists
    )
