"""
acwa.data.compilation.update_10min.py

Module to update 10 min input data on a pre-existing table
"""

from datetime import datetime
import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_10min
from acwa.db import run_query, write_df_as_table

def update_input_10min(
        config_db: dict,
        id_wf: int,
        wf_name: str,
        timezone: str
):
    """
    Update the table intermediate.input_10min with new data on a specific wind 
    farm.

    Args:
        config_db (dict): Database configuration
        id_wf (int): Id of wind farm
        wf_name (str): Name of wind farm
        timezone (str): Timezone of the original data
    """
    
    output_table_name = "input_10min"
    output_schema = 'intermediate'

    # Timezones
    utc = pytz.timezone('UTC')
    data_tz = pytz.timezone(timezone)

    logging.info("Extracting last datetime")
    max_datetime = run_query(
        "max_datetime_input_10min",
        config_db,
        params={"wind_farm_id": id_wf},
        returns="Fetchall"
    )[0][0] 
    if config_db["type"] == 'SQLite':
        max_datetime = utc.localize(
            datetime.strptime(max_datetime, "%Y-%m-%d %H:%M:%S.%f")) # Time in UTC
    else:
        max_datetime = utc.localize(max_datetime) # Time in UTC

    logging.info("Extracting recent data")
    df = run_query(
        f"read_dynamic_input_10min_{wf_name}",
        config_db,
        params={"start": max_datetime.astimezone(data_tz)}, ## Read in data tz
        returns='Dataframe'
    )           

    logging.info("Format")
    df = dict_format_10min[wf_name](df, id_wf)

    logging.info("Transform timezone")
    df = transform_timezone(
        df, 
        "timestamp",
        data_tz,
        utc)
    if config_db['type']=='Azure':
        df['timestamp'] = df['timestamp'].dt.tz_localize(None)

    logging.info("Writting to table")
    write_df_as_table(
        df,                
        config_db,
        output_schema,
        output_table_name,
        index=False,
        chunksize=10000,
        if_exists = "append"
    )
