"""
acwa.data.compilation.append_new_1min

Module to append a new wind farm on input 1min
"""

import logging
import pytz

from acwa.data import transform_timezone
from acwa.data.format import dict_format_1min
from acwa.db import read_table_as_df, write_df_as_table

def append_new_input_1min(
        config_db: dict,
        id_wf: int,
        wf_name: str,
        timezone: str,
        if_exists: str = 'append'
):
    """
    Append a new wind farm on the table intermediate.input_10min.

    Args:
        config_db (dict): Database configuration
        id_wf (int): Id of wind farm
        wf_name (str): Name of wind farm
        timezone (str): Timezone of the original data
        if_exists (str, optional): if_exists kwarg of write table. Defaults to
            "append" 
    """

    output_table_name = "input_1min"
    output_schema = 'intermediate'

    # Timezones
    utc = pytz.timezone('UTC')
    data_tz = pytz.timezone(timezone)

    lst_columns = [
        'datetime',
        'ambient_windspeed',
        'ambient_winddir',
        'grid_power',
        'ambient_temperature',
        'turbine_id',
        'rotorsystem_rotorrpm',
        'nacelle_direction',
        'controller_toptemperature',
        'gear_bearinghollowshaftgeneratortemperature',
        'generator_phase1temperature',
        'grid_inverterphase1temperature',
        'hvtrafo_phase1temperature',
        'hydraulic_oiltemperature',
        'nacelle_temperature',
        'spinner_temperature'
    ] # Columns to retrieve, make sure the list is complete
    # We need to place this in a non hard-coded location...

    input_table_name = f"realtime_input_1min_{wf_name}"
    df = read_table_as_df(
        input_table_name,
        config_db,
        "raw",
        chunksize=10000,
        columns = lst_columns
    )
    df = df.drop_duplicates()

    logging.info("Format")
    df = dict_format_1min[wf_name](df, id_wf)
    
    logging.info("Transform timezone")
    df = transform_timezone(
        df, 
        "timestamp",
        data_tz,
        utc)
    if config_db['type']=='Azure':
        df['timestamp'] = df['timestamp'].dt.tz_localize(None)

    logging.info("Writting to table")
    write_df_as_table(
        df,                
        config_db,
        output_schema,
        output_table_name,
        index=False,
        chunksize=10000,
        if_exists = if_exists
    )