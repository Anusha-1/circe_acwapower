"""
acwa.data.calc.oper_kpis

Different processes to calculate operational kpis
"""

import pandas as pd
import numpy as np

def calculate_cp_10min(
    df_10min: pd.DataFrame, wtg_config: pd.DataFrame
) -> pd.DataFrame:
    """
    Calculate cp using cp == power/(1/2*rho*section*(wind_speed)^3)

    Args:
        df_10min (pd.DataFrame): Dataframe with 10min data
        wtg_config (pd.DataFrame): Dataframe with turbine metadata. From here we
            get the rotor diameter to calculate rotor section

    Returns:
        pd.DataFrame: df_10min with added column of cp
    """

    wtg_config["section"] = np.pi * (wtg_config["rotor_diameter"] / 2)**2
    df_10min = pd.merge(
        df_10min, 
        wtg_config[["id_wtg_complete", "section"]], 
        on="id_wtg_complete"
    )
    df_10min["cp"] = (
        2
        * df_10min["power"] * 1000 #kw a w
        / (df_10min["density"] * df_10min["section"] * df_10min["wind_speed"] ** 3)
    )  # Cp Power/0.5*ro*A*V**3
    df_10min["cp"] = np.maximum(df_10min['cp'],0)
    df_10min.loc[df_10min["cp"] == float('-inf'), "cp"] = 0
    df_10min.loc[df_10min["cp"] == float('inf'), "cp"] = 0

    return df_10min


def calculate_production_ratio(df_10min: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate production ratio using formula pr == power/producible

    Args:
        df_10min (pd.DataFrame): Dataframe with 10min data

    Returns:
        pd.DataFrame: df_10min with an extra column 'production_ratio'
    """

    def __calculate_production_ratio(row):

        if pd.isna(row['producible']):
            return None
        if pd.isna(row['power']):
            return None
        if row['producible'] <= 0:
            return 1
        
        return max(0, row['power']/row['producible'])

    df_10min["production_ratio"] = df_10min.apply(
        __calculate_production_ratio,
        axis=1
    )
    
    return df_10min

def calculate_energy_availability(df_10min: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate energy availability using formula 
        ea = 1 - loss/(power + loss) = power / (power + loss)

    Args:
        df_10min (pd.DataFrame): Dataframe with 10min data

    Returns:
        pd.DataFrame: df_10min with an extra column 'energy_availability'
    """

    def __calculate_energy_availability(row):

        if pd.isna(row['loss']):
            return None
        if pd.isna(row['power']):
            return None
        if row['power'] + row['loss']  <= 0:
            return 1
        
        return max(0, row['power']/(row['power'] + row['loss']))

    df_10min["energy_availability"] = df_10min.apply(
        __calculate_energy_availability,
        axis=1
    )
    
    return df_10min


def calculate_lambda(df_10min: pd.DataFrame, wtg_config: pd.DataFrame):
    """_summary_

    Args:
        df_10min (pd.DataFrame): _description_
        wtg_config (pd.DataFrame): _description_

        return df_10min with lambda calcuated
    """
    wtg_config["radious"] = (wtg_config["rotor_diameter"] / 2)
    df_10min = pd.merge(
        df_10min, 
        wtg_config[["id_wtg_complete", "radious"]], 
        on="id_wtg_complete"
    )
    df_10min['lambda_parameter'] = df_10min['rotor_rpm']*(2*np.pi/60)* df_10min['radious']/df_10min['wind_speed']
    df_10min['lambda_parameter'] = np.maximum(0, df_10min['lambda_parameter'])
    df_10min['lambda_parameter'] = np.minimum(100, df_10min['lambda_parameter'])
    
    return df_10min