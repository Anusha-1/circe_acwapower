"""
acwa.data.calc.density

Calculations related to air density
"""

import numpy as np
import pandas as pd


def calculate_density_10min(
    df_10min: pd.DataFrame, wtg_config: pd.DataFrame
) -> pd.DataFrame:
    """
    Calculate air density using predeterminated pressure (p_atm-rho*g*h) and
    relative humidity 75% (representative for tanger)

    Args:
        df_10min (pd.DataFrame): Dataframe with 10min data
        wtg_config (pd.DataFrame): Dataframe with turbines metadata

    Returns:
        pd.DataFrame: df_10min with densities calculated
    """
    ### estimate air pressure for each wtg
    wtg_config["pressure"] = 101325 - 1.225 * 9.81 * (80 + wtg_config["elevation"])
    # in pascal for the formula, should inspect when using met mast data.
    # \\ this formula is P_wtg = p_atm -rho*gh

    df_10min = pd.merge(
        df_10min, wtg_config[["id_wtg_complete", "pressure"]], on="id_wtg_complete"
    )

    r_air = 287.05  # unidades == J/(kg*K)
    r_w = 461.5  # unidades == J/(kg*K)
    hr = 0.75  # humedad relativa media anual de tanger
    # t_k = 273.15 # 0ºC en
    p_w = 0.0000205 * np.exp(0.0631846 * (df_10min["temperature"] + 273.15))

    df_10min["density"] = (1 / (df_10min["temperature"] + 273.15)) * (
        (df_10min["pressure"] / r_air) - hr * p_w * (1 / r_air - 1 / r_w)
    )  # obtenido de norma UNE-EN 61400-12-1 apartado 9.1.5 formula 12

    df_10min["density"] = df_10min["density"].map(
        lambda x: np.nan if x < 0 else x)

    return df_10min


def correct_speed_with_density(
        df: pd.DataFrame,
        dens_ref: float = 1.225,
        new_col_name: str = 'wind_speed_corrected'
) -> pd.DataFrame:
    """
    Apply density correction to wind speed, with the following formula:
       new_speed = speed*(dens/dens_ref)**(1/3)
    as taken from IEC 61400-12

    Args:
        df (pd.DataFrame): Data to correct
        dens_ref (float, optional): Reference density. Defaults to 1.225.
        new_col_name (str, optional): Name of new column with corrected densities. 
            Defaults to 'wind_speed_corrected'.

    Returns:
        pd.DataFrame: Dataframe with extra column
    """
    
    df[new_col_name] = df.apply(
        lambda row: row['wind_speed'] * (row['density']/dens_ref) ** (1/3),
        axis = 1
    )

    return df

def correct_speed_with_density_auto(
        df: pd.DataFrame,
        dens_ref: list[float],
        new_col_name: str = 'wind_speed_corrected'
) -> pd.DataFrame:
    """
    Apply density correction to wind speed, with the following formula:
       new_speed = speed*(dens/dens_ref)**(1/3)
    as taken from IEC 61400-12

    Args:
        df (pd.DataFrame): Data to correct
        dens_ref (float): List of reference density.
        new_col_name (str, optional): Name of new column with corrected densities. 
            Defaults to 'wind_speed_corrected'.

    Returns:
        pd.DataFrame: Dataframe with extra column
    """

    def __correct_speed_auto(row):

        # List of distance to density
        distance = [abs(row['density'] - x) for x in dens_ref]
        zipped_list = zip(distance, dens_ref)
        min_pair = min(zipped_list, key=lambda x: x[0])
        density_for_correction = min_pair[1]

        return row['wind_speed'] * (row['density']/density_for_correction) ** (1/3)
    
    df[new_col_name] = df.apply(
        __correct_speed_auto,
        axis = 1
    )

    return df
