"""
src/wod_cli/data_wrangling/imputate_missing_data.py

Auxiliar function to imputate missing data
"""

from wod import WindFarm

def replace_data_with_mainwind(
        wf: WindFarm
) -> WindFarm:
    """
    Replaces speed and power data with mainwind information.
    If we have missing temperatures, we perform a ffill

    Args:
        wf (WindFarm): WindFarm object where we want to imputate missing data

    Returns:
        WindFarm: WindFarm object with replaced data
    """
    
    for turbine_name in wf.turbines.keys():
        wf.turbines[turbine_name].replace_power_with_mainwind()
        wf.turbines[turbine_name].replace_speed_with_mainwind()

        ## Imputate missing temperatures only if we have them
        if 'temperature' in wf.turbines[turbine_name].data.columns:
            wf.turbines[turbine_name].imputate_missing_data(
                'temperature', method='ffill')

    return wf
