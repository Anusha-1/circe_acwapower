"""
src/wod_cli/load/power_speed_data.py

Auxiliary function to load power speed data
"""

import os
import pathlib

from wod import WindFarm

def load_power_speed_data(
        wf: WindFarm,
        input_path: os.PathLike,
        load_mode: str,
        temperature_path: os.PathLike = None
) -> WindFarm:
    """
    Function to load power speed data into a WindFarm object

    Args:
        wf (WindFarm): WindFarm object to load the data into
        input_path (os.PathLike): Path to input data file or folder
        load_mode (str): Tag to specify the load mode. Options are:
            - 'MONTHLY': Loads data from a monthly folders
            - 'EXCEL': Loads data from Excel file
        temperature_path (os.PathLike): External folder with temperature data.
            Only if load_mode = 'MONTHLY'  

    Returns:
        WindFarm: WindFarm object with loaded data inside
    """

    input_path = pathlib.Path(input_path)
    if load_mode == 'MONTHLY':
        ## Load 10-min data of wind speed and power        
        wf.load_from_monthly_data(
            input_path, 
            data_validation=dict(min_speed=-9000, min_power=-9000))
        
        ## Load temperatures
        if temperature_path != 'None':
            wf.add_temperature_data(
                temperature_path, data_validation=dict(min_temperature=-9000))
            
    elif load_mode == 'EXCEL':
        ## Load simultaneously speed/power and temperature from a two sheet excel
        wf.load_from_two_sheets_excel(
            input_path,
            datetime_column = 'FECHA y HORA',
            speed_prefix = 'V',
            data_validation=dict(
                min_speed=-9000,
                min_power=-9000,
                min_temperature=-9000
            )
        )

    elif load_mode == 'VPT':
        ## Loads speed/power/temperature within the monthly folder
        wf.load_vpt_month_data(
            input_path,
            data_validation=dict(
                min_speed=-9000,
                min_power=-9000,
                min_temperature=-9000,
                error_threshold=101
            )
        )

    elif load_mode == 'Rio Ebro':

        ## Load 10-min data of wind speed and power        
        wf.load_from_monthly_data(
            input_path, 
            data_validation=dict(min_speed=-9000, min_power=-9000),
            speed_prefix = 'w',
            power_prefix = 'p',
            datetime_format = "%d/%m/%Y %H:%M")

    return wf
