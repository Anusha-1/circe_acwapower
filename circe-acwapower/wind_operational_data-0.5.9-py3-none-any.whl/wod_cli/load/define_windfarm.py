"""
src/wod_cli/load/define_windfarm.py

Auxiliary function to initialize a WindFarm object
"""

from datetime import datetime

from wod import WindFarm

def init_windfarm(
        name: str = None,
        start_date: str = None,
        end_date: str = None) -> WindFarm:
    """
    Initialize a wind farm object from string arguments

    Args:
        name (str, optional): Name for the wind farm. Defaults to None.
        start_date (str, optional): Start date for date. Defaults to None.
        end_date (str, optional): End date for data. Defaults to None.

    Returns:
        WindFarm: WindFarm object
    """
    
    if start_date:
        start_date = datetime.strptime(start_date, "%Y/%m/%d")
    if end_date:
        end_date = datetime.strptime(end_date, "%Y/%m/%d")

    return WindFarm(
        name=name,
        start_date=start_date,
        end_date=end_date
    )