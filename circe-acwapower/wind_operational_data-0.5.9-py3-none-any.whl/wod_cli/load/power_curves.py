"""
src/wod_cli/load/power_curves.py

Auxiliary function to load power curves
"""

import os
import pathlib

from wod import WindFarm
from wod.power_curve.factory import (
    load_temperature_power_curves_from_file,
    read_external_reference_curve,
)


def load_power_curves(
        wf: WindFarm, 
        power_curves_file: os.PathLike, 
        power_curve_mode: str) -> WindFarm:
    """Loads power curves into a WindFarm object

    Args:
        wf (WindFarm): WindFarm object to load power curves into
        power_curves_file (os.PathLike): Path to file with power curves
        power_curve_mode (str): Tag to specify the power curves mode. 
            Options are:
                - 'ONE': Unique power curve per turbine
                - 'TEMP': Temperature-specific power curves

    Returns:
        WindFarm: WindFarm object with PowerCurves
    """

    power_curves_file = pathlib.Path(power_curves_file)
    if power_curve_mode == 'ONE':
        dict_curves = read_external_reference_curve(
            power_curves_file,
            cols_names={
                'power': 'Avg. Power',
                'bin': 'Bin',
                'n_data': 'N Data',
                'deviation': 'Deviation',
                'power_max': 'Power Max',
                'power_min': 'Power Min',
                'factor': 'Factor'
            }
        )        
    elif power_curve_mode == 'TEMP':     
        dict_curves = load_temperature_power_curves_from_file(
            power_curves_file,
            temp_column = ('Tini', 'Tfin'),
            temp_extremes = (-99, 99),
            avg_prefix = 'Potencia',
            sd_prefix = 'SD'
        )
    wf.add_power_curves(dict_curves)

    return wf
