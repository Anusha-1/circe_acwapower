"""
wod_cli/get_losses.py

Auxiliary function for get losses command
"""

import os
import pathlib

from wod.alarms.load import load_alarms_from_monthly_data

from wod_cli.load import init_windfarm, load_power_speed_data, load_power_curves
from wod_cli.data_wrangling import replace_data_with_mainwind

def get_losses_aux(
        input_path: os.PathLike, 
        output_file: os.PathLike, 
        name: str,
        start_date: str, 
        end_date: str,
        load_mode: str,
        temperature_path: str,
        power_curves_file: os.PathLike,
        power_curve_mode: str,
        alarms_path: os.PathLike,
        mainwind_output_path: os.PathLike,
        derating: str,
        output_stats_file: os.PathLike):
    """
    Run the entire process to calculate losses for a Wind Farm. This include:
        1. Load data (power/speed, temperature)
        2. Load power curves
        3. Load alarms
        4. Calculate losses
        5. Write output with losses

    Args:
        input_path (os.PathLike): Path to main input data of power and speed
        output_file (os.PathLike): Path where output will be written
        name (str): Name of the wind farm
        start_date (str): First day to consider (format %Y/%m/%d)
        end_date (str): Last day to consider (format %Y/%m/%d)
        load_mode (str): Mode for main data load. 
            Options are: 'MONTHLY', 'EXCEL', 'VPT'
        temperature_path (str): Path to temperature data file. Only if 
            load_mode = 'MONTHLY' and power_curve_mode = 'TEMP'
        power_curves_file (os.PathLike): Path to power curves datafile
        power_curve_mode (str): Mode of power curves. Options are: 'ONE', 'TEMP'
        alarms_path (os.PathLike): Path to alarms data. If None is given, we 
            assume is the same as input path
        mainwind_output_path (os.PathLike): Path to mainwind data. If None is 
            given, we assume is the same as input path
        derating (str): Can be 'YES' or 'NO'. Whether to add derating losses or
            not
        output_stats_file (os.PathLike): File to save losses aggregated stats
    """

    print(f"\n Getting losses for {name} \n")

    ## 1. Define the Wind Farm object
    wf = init_windfarm(
        name=name,
        start_date=start_date,
        end_date=end_date
    )
    
    ## 2. Load 10-min data of wind speed, power and (optional) temperature
    print("\n Loading data \n")
    wf = load_power_speed_data(
        wf, input_path, load_mode, temperature_path=temperature_path)                  
    
    ## 3. Add power curves
    print("\n Loading power curves \n")
    wf = load_power_curves(wf, power_curves_file, power_curve_mode)

    ## 4. Add alarms
    print("\n Loading alarms \n")
    if alarms_path == "None":
        alarms_path = input_path
    alarms_path = pathlib.Path(alarms_path)
    dict_alarms = load_alarms_from_monthly_data(
        alarms_path, wf.start_date, wf.end_date
    )
    wf.add_alarms(dict_alarms)

    ## 5. Add mainwind output
    print("\n Loading mainwind output \n")
    if mainwind_output_path == "None":
        mainwind_output_path = alarms_path
    mainwind_output_path = pathlib.Path(mainwind_output_path)
    wf.load_mainwind_output(mainwind_output_path)

    ## 6. Imputate missing data
    print("\n Replacing data with mainwind \n")
    wf = replace_data_with_mainwind(wf)
    
    ## 7. Get losses
    print("\n Get losses \n")
    reference = 'one' if power_curve_mode == 'ONE' else 'temp'
    for turbine_name in wf.turbines.keys():
        wf.turbines[turbine_name].add_anomalous_power()
        wf.turbines[turbine_name].get_losses(
            reference=reference)
        
        if derating == 'YES':
            wf.turbines[turbine_name].add_derating_label()
            wf.turbines[turbine_name].get_derating_losses()
    
    ## 8. Write losses
    print("\n Write losses \n")
    output_file = pathlib.Path(output_file)
    wf.write_powerbi_output(
        output_file, 
        derating = derating == 'YES',
        reduced_file = True)

    ## 9. Print Stats
    if output_stats_file == 'None':
        output_stats_file = None
    else:
        output_stats_file = pathlib.Path(output_stats_file)
    wf.print_losses_stats(output_file=output_stats_file)
