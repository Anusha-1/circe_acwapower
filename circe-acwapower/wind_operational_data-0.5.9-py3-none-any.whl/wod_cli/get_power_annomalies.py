"""
wod_cli/get_power_anomalies.py

Auxiliary function for get power anomalies command
"""

import os
import pathlib

from wod_cli.load import init_windfarm, load_power_speed_data, load_power_curves
from wod_cli.data_wrangling import replace_data_with_mainwind

def get_power_anomalies_aux(
        input_path: os.PathLike, 
        output_file: os.PathLike, 
        start_date: str, 
        end_date: str,
        load_mode: str,
        temperature_path: str,
        power_curves_file: os.PathLike,
        power_curve_mode: str,
        mainwind_output_path: os.PathLike):
    """
    Run the entire process to obtain power anomalies. It includes these steps:
        1. Load data (power/speed, temperature)
        2. Load power curves
        3. Calculate power anomalies
        4. Write output

    Args:
        input_path (os.PathLike): Path to main input data of power and speed
        output_file (os.PathLike): Path where output will be written
        start_date (str): First day to consider (format %Y/%m/%d)
        end_date (str): Last day to consider (format %Y/%m/%d)
        load_mode (str): Mode for main data load. 
            Options are: 'MONTHLY', 'EXCEL'
        temperature_path (str): Path to temperature data file. Only if 
            load_mode = 'MONTHLY' and power_curve_mode = 'TEMP'
        power_curves_file (os.PathLike): Path to power curves datafile
        power_curve_mode (str): Mode of power curves. Options are: 'ONE', 'TEMP'
        mainwind_output_path (os.PathLike): Path to mainwind data. If None is 
            given, we assume is the same as input path
    """

    print("\n Getting anomalies \n")

    ## 1. Define the Wind Farm object
    wf = init_windfarm(
        start_date=start_date,
        end_date=end_date
    )

    ## 2. Load 10-min data of wind speed, power and (optional) temperature
    wf = load_power_speed_data(
        wf, input_path, load_mode, temperature_path=temperature_path)
    
    ## 3. Add power curves
    wf = load_power_curves(wf, power_curves_file, power_curve_mode)

    ## 4. Add mainwind output
    if mainwind_output_path == "None":
        mainwind_output_path = input_path
    mainwind_output_path = pathlib.Path(mainwind_output_path)
    wf.load_mainwind_output(mainwind_output_path)

    ## 5. Imputate missing data
    wf = replace_data_with_mainwind(wf)

    ## 6. Add power anomalies
    for turbine_name in wf.turbines.keys():
        wf.turbines[turbine_name].add_anomalous_power()

    ## 7. Write output
    output_file = pathlib.Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    wf.write_power_anomalies(output_file)
