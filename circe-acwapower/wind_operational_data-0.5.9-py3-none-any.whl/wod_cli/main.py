"""
wod_cli/main.py

Command-Line Interface
"""

from datetime import datetime
import warnings

import click

from wod_cli.get_losses import get_losses_aux
from wod_cli.get_power_annomalies import get_power_anomalies_aux

@click.group()
def main():
    warnings.simplefilter(action='ignore', category=FutureWarning)
    print("#"*50)
    print("#"*15,"Welcome to WOD CLI","#"*15)
    print("#"*50)


######################## COMMAND 1: GET LOSSES #################################
# This command calculate the losses of a wind farm
@main.command()
@click.argument('input_path')
@click.argument('output_file')
@click.option('name', '-n', default=None, 
              prompt='Name for the Wind Farm',
              help='Name for the Wind Farm')
@click.option('start_date', '--start', 
            default=datetime(datetime.now().year, 1, 1).strftime("%Y/%m/%d"),
            prompt="Start date in format %Y/%m/%d (example 2023/1/1)",
            help ="Start date in format %Y/%m/%d (example 2023/1/1)" )
@click.option('end_date', '--end', default=datetime.now().strftime("%Y/%m/%d"),
            prompt="End date in format %Y/%m/%d (example 2024/1/1)",
            help="End date in format %Y/%m/%d (example 2024/1/1)")
@click.option('load_mode', '--load_mode', 
              type=click.Choice(['MONTHLY', 'EXCEL', 'VPT', 'Rio Ebro'], case_sensitive=False),
              help='Introduce load mode',
              default='VPT')
@click.option('temperature_path', '-t', 
            help='Path to temperature data. If None is given it will not use temperatures',
            default='None')
@click.option('power_curves_file', '-p', 
              prompt="File with Power Curve(s)",
              help="File with Power Curve(s) to consider")
@click.option('power_curve_mode', '--pc_mode', 
              type=click.Choice(['ONE', 'TEMP'], case_sensitive=False),
              help='Introduce power curve mode',
              default='TEMP')
@click.option('alarms_path', '-a',
              help='Path to alarms data. If None, it will take the same as the input path',
              default="None")
@click.option('mainwind_output_path', '--mainwind_path',
              help='Path to MainWind output data. If None, it will take the same as the alarms path',
              default="None")
@click.option('derating', '--derating',
              type=click.Choice(['YES', 'NO'], case_sensitive=False),
              help='Add derating losses',
              default='YES')
@click.option('output_stats_file', '--output_stats_file',
              help='Path to file for output stats. If None, it will not print out stats to file',
              default="None")
def get_losses(**kwargs):
    get_losses_aux(**kwargs)


#################### COMMAND 2: GET POWER ANOMALIES ############################
# This command calculate the power anomalies alarms for a wind farm
@main.command()
@click.argument('input_path')
@click.argument('output_file')
@click.option('start_date', '--start', 
            default=datetime(datetime.now().year, 1, 1).strftime("%Y/%m/%d"),
            prompt="Start date in format %Y/%m/%d (example 2023/1/1)",
            help ="Start date in format %Y/%m/%d (example 2023/1/1)" )
@click.option('end_date', '--end', default=datetime.now().strftime("%Y/%m/%d"),
            prompt="End date in format %Y/%m/%d (example 2024/1/1)",
            help="End date in format %Y/%m/%d (example 2024/1/1)")
@click.option('load_mode', '--load_mode', 
              type=click.Choice(['MONTHLY', 'EXCEL', 'VPT'], case_sensitive=False),
              help='Introduce load mode',
              default='VPT')
@click.option('temperature_path', '-t', 
            help='Path to temperature data. If None is given it will not use temperatures',
            default='None')
@click.option('power_curves_file', '-p', 
              prompt="File with Power Curve(s)",
              help="File with Power Curve(s) to consider")
@click.option('power_curve_mode', '--pc_mode', 
              type=click.Choice(['ONE', 'TEMP'], case_sensitive=False),
              help='Introduce power curve mode',
              default='TEMP')
@click.option('mainwind_output_path', '--mainwind_path',
              help='Path to MainWind output data. If None, it will take the same as the alarms path',
              default="None")
def get_power_anomalies(**kwargs):
    get_power_anomalies_aux(**kwargs)

if __name__ == '__main__':
    main()
