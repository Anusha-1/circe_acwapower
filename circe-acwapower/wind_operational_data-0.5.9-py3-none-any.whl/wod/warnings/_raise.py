"""
wod/warnings/_raise.py

Module to raise messages as warning or errors
"""

import warnings

def raise_message(
        message: str, as_error: bool, ErrorClass: Exception = Exception):
    """
    Raise a message

    Args:
        message (str): Message to raise
        as_error (bool): If True raise as error, if False raise as warning
        ErrorClass (Exception, optional): ErrorClass to use. 
            Defaults to Exception

    Raises:
        Exception: Exception raised
    """

    if as_error:
        raise ErrorClass(message)
    else:
        warnings.warn(message, stacklevel=2)
