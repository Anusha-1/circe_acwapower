"""
wod/warnings/missing.py

Warnings about missing data
"""

import warnings

from wod.warnings._raise import raise_message 

def warn_missing_months(folders: list[str]):
    """    
    Raise warning about missing expected month folders in the data
    
    Args:
        folders (list[str]): List of expected month folders
    """

    message = "MISSING MONTH FOLDERS: "
    message += f"Couldn't find all expected months folders: {','.join(folders)}."
    message += "Trying to search for folders without leading zero"

    warnings.warn(message, stacklevel=2)

def warn_missing_columns(
        cols_to_check: list[str], 
        cols_in_df: list[str], 
        as_error: bool = False,
        df_name: str = 'Unknown'):
    """
    Raise warning (or error) when we have missing columns

    Args:
        cols_to_check (list[str]): List of columns we need to check
        cols_in_df (list[str]): List of columns in dataframe
        as_error (bool, optional): If True raise as error, if False as wanring. 
            Defaults to False.
        df_name (str, optional): Name to identify the dataframe.
            Defaults to 'Unknown'

    Raises:
        AssertionError: Error produced by missing columns
    """

    missing_columns = []
    for col in cols_to_check:
        if col not in cols_in_df:
            missing_columns.append(col)

    if len(missing_columns) > 0:

        message = "MISSING COLUMNS: "
        message += f"Missing columns in {df_name} dataframe: {', '.join(missing_columns)}"

        raise_message(message, as_error, ErrorClass=AssertionError)

def warn_missing_file(name: str, as_error: bool = False):
    """
    Raise warning or error about a missing file

    Args:
        name (str): Name or description of the file
        as_error (bool, optional): If True raise as error, if False as wanring. 
            Defaults to False.

    Raises:
        AssertionError: Error produced by missing file
    """

    message = f"MISSING FILE: Missing file {name}"

    raise_message(message, as_error, ErrorClass=AssertionError)

def warn_missing_temperature():
    """
    Raise a warning when temperature data is missing
    """

    message = "MISSING TEMPERATURE"
    warnings.warn(message, stacklevel=2)