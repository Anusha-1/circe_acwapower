"""
wod/warnings/mismatch.py

Warnings about mismatched data structures
"""

import warnings

from wod.warnings._raise import raise_message 

def warn_mismatch_turbines(
        current_turbines: list[str], proposed_turbines: list[str]):
    """
    Raise warning about mismatched turbine names

    Args:
        current_turbines (list[str]): Current list of turbines id
        proposed_turbines (list[str]): New list of turbines id
    """    

    message = "MISMATCHED TURBINE IDS: "
    message += f"Current turbine ids: {','.join(current_turbines)}; "
    message += f"do not match with turbine ids for additional data: {','.join(proposed_turbines)}."
    message += " Replacing turbine ids to introduce additional data."

    warnings.warn(message, stacklevel=2)
    
def warn_turbines_without_additional_data(
        diff_turbines: list[str], data_type: str):
    """
    Raises a warning when we try to add additional data to wind farm turbines, 
    but we are missing turbines in the new data structure

    Args:
        diff_turbines (list[str]): Set of turbines in the wind farm object that
            can't be found in the additional data
        data_type (str): Type of additional data
    """
    
    if len(diff_turbines) > 0:
        message = f"No {data_type} found for turbines: {', '.join([str(x) for x in diff_turbines])}"
        warnings.warn(message, stacklevel=2)

def warn_missing_original_turbines(
        diff_turbines: list[str], data_type: str, as_error: bool):
    """
    Raises a warning when, while trying to add new data, there are turbines that
    doesn't exist in original WindFarm object 

    Args:
        diff_turbines (list[str]): Set of turbines in new data structure that 
            can't be found in WindFarm object
        data_type (str): Type of additional data
    """

    if len(diff_turbines) > 0:
        message = f"Following turbines in {data_type} are missing: {', '.join([str(x) for x in diff_turbines])}"
        raise_message(message, as_error, ErrorClass=AssertionError)
