"""
wod/warnings/fit.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import warnings

from wod.warnings._format import format_power_curve_id

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

def warn_fit(pc: PowerCurve):
    """
    Raise a warning due to an incorrect dropout fit

    Args:
        pc (PowerCurve): Power Curve
    """

    message = "WRONG FIT: Could not fit dropout for "
    message += format_power_curve_id(pc)
    warnings.warn(message, stacklevel=2)