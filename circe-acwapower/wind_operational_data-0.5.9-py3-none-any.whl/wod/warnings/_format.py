"""
wod/warnings/_format.py

Additional formatting for warning message
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve
    from wod.wind_turbine import WindTurbine

def format_power_curve_id(
        pc: PowerCurve, first: float = None, last: float = None) -> str:
    """
    Formats a general power curve identification to be used in warning messages

    Args:
        pc (PowerCurve): PowerCurve object where the calculation is taking place
        first (float, optional): First bin in the identified dangerous range.
            Defaults to None
        last (float, optional): Last bin in the identified dangerous range
            Defaults to None
            
    Returns:
        (str): Message
    """

    message = f"wind farm {pc.metadata.get('wind_farm', 'unknown')},"
    message += f" turbine {pc.metadata.get('turbine', 'unknown')} "
    if pc.metadata["type"] == 'temperature':
        message += f" and temperature range {pc.metadata['min_temperature']} - {pc.metadata['max_temperature']}"
    elif pc.metadata["type"] == 'global':
        message += " (all temperatures aggregated)"
    if first is not None and last is not None:
        message += f" between bins {first} and {last}"

    return message

def format_turbine_id(turbine: WindTurbine) -> str:
    """
    Formats a turbine identifcation

    Args:
        turbine (WindTurbine): Wind turbine object

    Returns:
        str: Message with turbine id
    """

    message = f"wind farm {turbine.wind_farm_name}, turbine {turbine.name} "
    return message
