"""
wod/warnings/jump.py

Warnings related to jump correction
"""

from __future__ import annotations

from typing import TYPE_CHECKING
import warnings

from wod.warnings._format import format_power_curve_id

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

def warn_shape_jump(pc: PowerCurve, first: float, last: float):
    """
    Raise a warning about a shape jump correction

    Args:
        pc (PowerCurve): PowerCurve object where the calculation is taking place
        first (float): First bin in the identified dangerous range
        last (float): Last bin in the identified dangerous range
    """

    message = "SHAPE: Dubious values at "
    message += format_power_curve_id(pc, first=first, last=last)
    warnings.warn(message, stacklevel=2)

def warn_reference_jump(pc: PowerCurve, first: float, last: float):
    """
    Raise a warning about a jump correction due to a difference with the
    reference curve

    Args:
        pc (PowerCurve): PowerCurve object where the calculation is taking place
        first (float): First bin in the identified dangerous range
        last (float): Last bin in the identified dangerous range
    """

    message = "REFERENCE DIFFERENCE: Large difference with reference detected for "
    message += format_power_curve_id(pc, first=first, last=last)
    warnings.warn(message, stacklevel=2)
