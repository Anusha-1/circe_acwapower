"""
wod/warnings/data_count.py

Warnings about number of data points
"""

from __future__ import annotations

from typing import TYPE_CHECKING
import warnings

from wod.warnings._format import format_power_curve_id, format_turbine_id
from wod.warnings._raise import raise_message

if TYPE_CHECKING:
    import pandas as pd
    from wod.power_curve import PowerCurve    
    from wod.wind_turbine import WindTurbine

def warn_low_number_of_valid_bins(
        current_number_of_bins: int,
        necessary_number_of_bins: int,
        pc: PowerCurve
):
    """
    Raise warning about a low number of valid bins when computing a PowerCurve

    Args:
        current_number_of_bins (int): Number of valid bins with current data 
            points
        necessary_number_of_bins (int): Necessary number of valid bins, 
            according to current algorithm parametrization
        pc (PowerCurve): PowerCurve object
    """
    
    message = "LOW NUMBER OF VALID BINS: "
    message += f"Number of valid bins ({current_number_of_bins}) do not reach "
    message += f"necessary threshold ({necessary_number_of_bins}), for " 
    message += format_power_curve_id(pc)

    warnings.warn(message, stacklevel=2)

def warn_high_proportion_of_invalid_data(
        turbine: WindTurbine,
        df: pd.DataFrame, 
        warn_threshold: float, 
        error_threshold: float):
    """
    Raise an error or a warning if the proportion of invalid data is too high

    Args:
        turbine (WindTurbine): Turbine affected
        df (pd.DataFrame): Dataframe. Requires a column 'validation_status'
        warn_threshold (float): Minimum threshold to raise a warning. 
        error_threshold (float): Minimum threshold to raise an error.
    """
    
    prop_invalid = (1- df['validation_status'].mean())*100

    if prop_invalid >= error_threshold:
        raise_message(
            f"Proportion of invalid data ({prop_invalid:.2f}%) is too high at {format_turbine_id(turbine)}",
            as_error=True
        )
    
    if prop_invalid >= warn_threshold:
        raise_message(
            f"Proportion of invalid data ({prop_invalid:.2f}%) is too high at {format_turbine_id(turbine)}",
            as_error=False
        )
