import warnings

from .wind_farm import WindFarm

__all__ = [WindFarm]


# Format the warning
def custom_formatwarning(msg, *args, **kwargs):
    return "Warning: " + str(msg) + '\n'

warnings.formatwarning = custom_formatwarning
