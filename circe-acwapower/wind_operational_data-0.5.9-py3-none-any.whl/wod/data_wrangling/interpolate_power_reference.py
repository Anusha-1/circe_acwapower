"""
src/wod/data_wrangling/interpolate_from_one_reference.py


"""

from __future__ import annotations

import pandas as pd
from scipy import interpolate

from wod.power_curve import PowerCurve

def interpolate_from_one_reference(
        df_pc: pd.DataFrame, data: pd.DataFrame,
        power_col: str = 'power',
        interpolated_power_col: str = 'power_reference') -> pd.DataFrame:
    """
    Interpolate the power curve at different speeds from a unique reference
    curve.

    Args:
        df_pc (pd.DataFrame): DataFrame with the power curve. Typically from the
            attribute 'data' of a PowerCurve object. Columns needed: 'bin' and
            an adjustable 'power' column
        data (pd.DataFrame): DataFrame with data points from which we want to
            obtain the interpolated power. Typically the attribute 'data' of a
            WindTurbine object. Needs a column 'speed'
        power_col (str, optional): Column of the power curve data to take as 
            reference. Defaults to 'power'.
        interpolated_power_col (str, optional): Name that the interpolated power
            will take in the resulting dataframe. Defaults to 'power_reference'.

    Returns:
        (pd.DataFrame): Same dataframe passed at the 'data' argument with an
            extra column for the interpolated power values.
    """


    # Interpolating function
    f = interpolate.interp1d(
        df_pc['bin'], df_pc[power_col],
        bounds_error=False,
        fill_value=(
            df_pc[df_pc['bin'] == df_pc['bin'].min()][power_col].iloc[0], 
            df_pc[df_pc['bin'] == df_pc['bin'].max()][power_col].iloc[0])
    )

    # Add reference at data
    data[interpolated_power_col] = f(data['speed'])  

    return data

def interpolate_from_temp_power_curves(
        data: pd.DataFrame, lst_power_curves: list[PowerCurve], 
        power_col: str = 'power', 
        interpolated_power_col: str = 'power_reference') -> pd.DataFrame:
    """
    Interpolate the power curve at different speeds from several power curves
    at different temperatures, i.e. it computes a 2D interpolation in 'speed' 
    and 'temperature'

    Args:        
        data (pd.DataFrame): DataFrame with data points from which we want to
            obtain the interpolated power. Typically the attribute 'data' of a
            WindTurbine object. Needs the columns 'speed' and 'temperature'
        lst_power_curves (list[PowerCurve]): List of PowerCurves to consider for
            the interpolation. They need to have 'temperature' as a metadata
            value. 
        power_col (str, optional): Column of the power curve data to take as 
            reference. Defaults to 'power'.
        interpolated_power_col (str, optional): Name that the interpolated power
            will take in the resulting dataframe. Defaults to 'power_reference'.

    Returns:
        (pd.DataFrame): Same dataframe passed at the 'data' argument with an
            extra column for the interpolated power values.
    """
    

    # Organize Power Curves data
    lst_dfs = []
    for pc in lst_power_curves:

        temperature = pc.metadata['temperature']
        df = pc.data
        df['temperature'] = temperature

        lst_dfs.append(
            df[['bin','temperature',power_col]]
        )
    df_pc = pd.concat(lst_dfs)
    
    # Add fictional curves at temp_min and temp_max
    min_pc_temp = df_pc.temperature.min()
    max_pc_temp = df_pc.temperature.max()
    
    for pc in lst_power_curves:
        if pc.metadata['temperature'] == min_pc_temp:
            df_aux = pc.data
            df_aux['temperature'] = -500
            df_pc = pd.concat([df_pc, df_aux[['bin', 'temperature', power_col]]])

        if pc.metadata['temperature'] == max_pc_temp:
            df_aux = pc.data
            df_aux['temperature'] = 500   
            df_pc = pd.concat([df_pc, df_aux[['bin', 'temperature', power_col]]])

    ## Fill NaN at power curve
    ## NOTE: It should be better to have them already complete at source
    df_pc[power_col] = df_pc[power_col].ffill()

    # Prepare x, y, z
    x = df_pc['bin']
    y = df_pc['temperature']
    z = df_pc[power_col]

    # Interpolation function
    interp = interpolate.LinearNDInterpolator(list(zip(x, y)), z)

    # Apply 2D interpolation
    data[interpolated_power_col] = interp(data['speed'], data['temperature'])

    return data
