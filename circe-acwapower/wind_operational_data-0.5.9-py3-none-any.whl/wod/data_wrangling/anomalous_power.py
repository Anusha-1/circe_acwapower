"""
wod/losses/anomalous_power.py

"""

import pandas as pd

def add_anomalous_power(data: pd.DataFrame,
        anomalous_power_label: str = 'Potencia anomala') -> pd.DataFrame:
    """
    Add anomalous power alarm. We modify each alarm state equal to Running, that 
    have a power lower than the reference, with a specific label. 
    If the data doesn't have an alarm column, we add one considering all status
    initially as Running

    Args:
        data (pd.DataFrame): Dataframe with 10-min data points
        anomalous_power_label (str, optional): Label of the new alarm. 
            Defaults to 'Potencia anomala'.

    Returns:
        (pd.DataFrame): Dataframe with changed alarms
    """
    
    if 'alarm' not in data:
        data['alarm'] = 'Running'

    data['alarm'] = data.apply(
        lambda row: anomalous_power_label if row.power < row.power_reference_min and row.speed > 0 and row.power > -9000 and row.alarm == 'Running' else row.alarm,
        axis=1
    )
    ## Note: We have to put here special conditions (speed > 0, power > 
    ## -9000) to avoid dealing with "incorrect" data. 
    ## A good data filtering would have prevented that 

    return data
