"""
wod.data_wrangling.non_registered_events

Functions to add non registered events at a turbine
"""

import pandas as pd

def add_non_registered_events(
        data: pd.DataFrame,
        min_speed: float = 3.0,
        max_speed: float = 30.0,
        mark_boundaries: bool = True,
        label: str = "Non-registered alarm"
) -> pd.DataFrame:
    """
    Add non-registered events. If we have 10-min with wind speed > min_speed and
    power == 0, with no recorded alarm, we mark it as non-registered alarm 
    alongside the previous and next 10-min 

    Args:
        data (pd.DataFrame): Dataframe with 10-min data points, with columns: 
            'datetime', 'speed', 'power' and 'alarm'
        min_speed (float, optional): Minimum speed to be considered a missing
            alarm. Defaults to 3.0.
        max_speed (float, optional): Maximum speed to be considered a missing
            alarm. Defaults to 30.0.
        mark_boundaries (bool, optional): If True, mark also the previous and
            next timestamp. Defaults to 3.0.
        label (str, optional): Label for missing alarms. 
            Defaults to "Non-registered alarm".

    Returns:
        (pd.DataFrame): Dataframe with changed alarms
    """

    df = data.copy()
    assert 'alarm' in df.columns, "alarms not in data"

    df = df.sort_values(by='datetime')

    # Boolean column to mark 10-min with power==0 (in proper wind conditions and
    # no previous alarm)
    df['mark'] = (df['power'] <= 0) & (df['speed'] > min_speed) & (df['speed'] < max_speed) & (df['alarm'] == 'Running')

    if mark_boundaries:
        # Mark previous and next
        df['mark_previous'] = df['mark'].shift(1)
        df['mark_next'] = df['mark'].shift(-1)

        # Combine three marks
        df['final_mark'] = df['mark'] | df['mark_previous'] | df['mark_next']
    else:
        df['final_mark'] = df['mark']

    # Merge with pre-existing alarms   
    def __assign_alarm(row):
        if row['alarm'] == 'Running':
            if row['final_mark']:
                return label
        return row['alarm']
    
    data['alarm'] = df.apply(__assign_alarm, axis=1)

    return data
