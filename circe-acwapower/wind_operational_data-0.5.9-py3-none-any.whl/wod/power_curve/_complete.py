"""
wod/power_curve/_complete.py

Methods to complete missing information
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve


def calculate_lower_threshold(self: PowerCurve):
    """
    Calculates a lower threshold for the power curve
    """

    self.data["power_min"] = (
        self.data["power"] - self.data["factor"] * self.data["deviation"]
    )

def calculate_upper_threshold(self: PowerCurve):
    """
    Calculates a lower threshold for the power curve
    """

    self.data["power_max"] = (
        self.data["power"] + self.data["factor"] * self.data["deviation"]
    )
