"""
wod/power_curve/_calculate.py

Method to manage the calculation of power curve from data points
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

import wod.power_curve.calculations as aux
from wod.warnings import warn_low_number_of_valid_bins, warn_fit

def calculate_power_curve(
    self: PowerCurve,
    factor: float = 2.5,
    minimum_points_before_elbow: int = 5,
    minimum_points_after_elbow: int = 2, 
    minimum_numer_of_bins: int = 20,
    minimum_power_bin: float = 3.0,
    merge_with_reference: bool = True,
    strict: bool = True,
    smooth_elbow: bool = True,
    jump_shape_correction: bool = True,
    jump_difference_correction: bool = True,
    window_length: int = 5,
    polyorder: int = 3,
    max_bin: float = 25.0,
    deviation_at_first_bins: float = 30.0,
    min_deviation_after_elbow: float = 20,
    difference_threshold: float = 10.0,
    jump_data_threshold: int = 25,
    nominal_power: float | None = None,
    dropout_speed: float | None = None,
    last_power: float | None = None,
    calculate_dropout: bool = False,
    fit_dropout: bool = True,
    only_cold_dropout: bool = True
):
    """
    Calculates power curves from data points, using a previous power curve as
    reference

    Args:
        factor (float, optional): Applied factor to obtain max and min 
            thresholds. Defaults to 2.5.
        minimum_points_before_elbow (int, optional): Minimum number we need to
            have in a bin before the elbow. If we don't reach this number, we'll
            consider the bin as not valid, and will be interpolated instead of
            using the average as a starting point. Defaults to 5.
        minimum_points_after_elbow (int, optional): Minimum number we need to
            have in a bin after the elbow. If we don't reach this number, we'll
            consider the bin as not valid, and will be interpolated instead of
            using the average as a starting point.. Defaults to 2.
        minimum_numer_of_bins (int, optional): Minimum number of valid bins we 
            need to have to calculate a power curve. If we don't reach this 
            number, the entire curve will be set as NaN. It will be later 
            completed with a power curve at other temperature. Defaults to 20.
        minimum_power_bin (float, optional): First bin at which we can have a
            non-zero power. Previous bins will be set to zero. Defaults to 3.0.
        merge_with_reference (bool, optional): If True, we'll merge the power
            averages with the reference curve, in order to limit the power. 
            Defaults to True.
        strict (bool, optional): If True, the merge with the reference will be
            strict, i.e. after the elbow, the power curve will copy the 
            reference. Defaults to True.
        smooth_elbow (bool, optional): If True, applies a specific smoothing at
            the elbow. As it is the joining point of the power averages and the
            reference curve, this is often needed. Defaults to True.
        jump_shape_correction (bool, optional): If True, applies a correction 
            for very aggresive jumps between bin statistics and reference. 
            Detection is based on the shape of the curve.
            Defaults to True.
        jump_difference_correction (bool, optional): If True, applies a 
            correction for very aggresive jumps between bin statistics and 
            reference. Detection is based on difference with reference curve.
            If there is no reference curve, this correction is skipped.
            Defaults to True.
        window_length (int, optional): Window length of the SavGol filter that
            we apply to the entire power curve. Defaults to 5.
        polyorder (int, optional): Polynomial order of the SavGol filter that
            we apply to the entire power curve. Defaults to 3.
        max_bin (float, optional): Maximum bin to calculate. Defaults to 25.0
        deviation_at_first_bins (float, optional): Deviation to consider at the 
            first few bins (with 0 power). Defaults to 30
        min_deviation_after_elbow (float, optional): Minimum deviation to 
            consider after elbow. Defaults to 20.0
        difference_threshold (float, optional): Threshold to detect difference
            with reference. Only used if jump_difference_correction is True.
            Defaults to 10.0
        jump_data_threshold (int, optional): Minimum number of data points
            to avoid a jump correction, even if the other requirements are
            fullfilled. Only used if jump_difference_correction or 
            jump_shape_correction is True.
            Defaults to 25
        nominal_power (float | None, optional): Nominal Power of the curve, to 
            be used if reference is not available. If None is passed, it takes 
            it from the maximum data. Defaults to None.
        dropout_speed (float | None, optional): Bin at which the dropout begins.
            If None is passed, it is taken as the max bin - 1. Defaults to None.
        last_power (float | None, optional): Power expected at max bin. If None 
            is passed, we take the same as the nominal power (meaning that there
            is no dropout). Defaults to None
        calculate_dropout (bool, optional): If False we don't try to calculate a 
            dropout, with a fit or with direct parameters. Defaults to False.
        fit_dropout (bool, optional): If True, we try to fit a dropout from 
            data. Defaults to True.
        only_cold_dropout (bool, optional): Only calculates dropout if it is the
            cold power curve. Defaults to True
    """

    # 1. Organize bin stats
    # Here, we create an initial proposal, based only on bin-wise statistics
    df = aux.organize_bin_stats(self, max_bin)   
    df["factor"] = factor ## We also add a factor column
    self.data = df ## We assign this here, so we can use it to calculate the 
                    ## elbow without reference
    
    # 2. Discard values.
    ## If at some bin we don't have enough data points, we'll discard the value
    ## It applies to both power and deviation
    df = aux.discard_values(
        df,
        self.elbow,
        minimum_points_before_elbow,
        minimum_points_after_elbow
    )

    ## If we don't have a minimum number of bins, we'll return an empty curve
    ## (we'll fill it with nan and stop there)
    df["valid_bin"] = ~df["power"].isna()
    if df["valid_bin"].sum() < minimum_numer_of_bins:
        warn_low_number_of_valid_bins(
            df["valid_bin"].sum(), minimum_numer_of_bins, self)
        df["power"] = np.nan
        df["deviation"] = np.nan
        self.data = df
        return

    # 3. Fill missing values.
    ## Here we fill the missing values with simple rules, and interpolations
    df = aux.fill_missing_values(
        df, minimum_power_bin, deviation_at_first_bins
    )

    # 4. Merge with reference curve
    ## As the end of the curve is not well populated, and has a lot of 
    ## restrictions (dropout, nominal power, etc.), we use the reference curve 
    ## to replace the last part of the power curve.
    if merge_with_reference:
        ## Limit the power curve to the reference we have
        if self.reference_power_curve is not None:
            df = aux.establish_limit(df, self)
        else:

            if only_cold_dropout:
                calculate_dropout = calculate_dropout or self.metadata.get('min_temperature', 0) == -np.inf

            if not calculate_dropout:
                nominal_power, dropout_speed, last_power = None, None, None
            else:
                if fit_dropout:
                    try:                
                        nominal_power, dropout_speed, last_power, max_bin = aux.fit_dropout_parameters(
                            df, self.elbow, minimum_points_after_elbow
                        )
                    except Exception:
                        warn_fit(self)

            df = aux.establish_limit_without_reference(
                df,
                nominal_power,
                dropout_speed,
                last_power,
                max_bin,
                df[df['bin'] > self.elbow]['deviation'].mean() ## We use as deviation the mean after elbow 
            )

        ## If 'strict' we'll force the curve to follow the reference after the
        ## elbow
        if strict:
            df = aux.paste_reference(df, self)

        ## Smooth elbow and its surroundings (+- 2 m/s)
        if smooth_elbow:
            df = aux.smooth_elbow(df, self)
            
            ## The smoothing of the elbow might cause some values to be lifted
            ## above the max limit again
            df["power"] = df[["power", "max_power_limit"]].min(axis=1)

        ## Jump Correction.
        ## In occassions, the merge of the bin statistics with the reference
        ## curve, produce very aggressive jumps.
        ## We'll try to detect and correct those cases
        if jump_shape_correction:
            df = aux.correct_jump_based_on_shape(
                df, self, minimum_power_bin, jump_data_threshold)
        if jump_difference_correction and self.reference_power_curve is not None:
            df = aux.correct_jump_based_on_difference(
                df, self, difference_threshold, jump_data_threshold)

    # 5. Global smoothing filter (for power and deviation)
    df = aux.smooth_curve(df, "power", window_length, polyorder)
    df = aux.smooth_curve(df, "deviation", window_length, polyorder)

    # 6. Apply power constraints again
    ## The filter might have changed some well established values.
    ## We can't surpass the max power limit
    df = aux.apply_constraints(
        df,
        minimum_power_bin,
        deviation_at_first_bins,
        min_deviation_after_elbow,
        self.elbow
    )

    ## We even repeat the merge with reference after the elbow again
    # if strict:
    #     df["power"] = df["reference"] * (df["bin"] > self.elbow) \
    #         + df["power"] * (df["bin"] <= self.elbow)

    self.data = df
