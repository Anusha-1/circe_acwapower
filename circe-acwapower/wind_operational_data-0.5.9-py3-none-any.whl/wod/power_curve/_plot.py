"""
src/wod/power_curves/_plot.py

Method functions for loading power curves data
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

import wod.visualization as vis
if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

def plot(self: PowerCurve, plot_type: str = 'power_curve', **kwargs) -> "go.Figure":
        """Plots Power Curve

        Args:
            plot_type (str, optional): Indicates the type of plot to make. 
                Options are:
                - 'power_curve': Plots power curve with its lower threshold
                - 'deriv': Plots available derivatives

        Returns:
            (go.Figure): Figure with Power Curve
        """

        if plot_type == 'power_curve':
            return vis.plot_power_curve(self.data, **kwargs)
        elif plot_type == 'deriv':
            return vis.plot_power_derivatives(self.data, **kwargs)