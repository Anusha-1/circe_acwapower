"""
src/wod/power_curves/_load.py

Method functions for loading power curves data
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Iterable

from numpy.typing import ArrayLike
import pandas as pd

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve


def load_complete_power_curves(
        self: PowerCurve, 
        power: ArrayLike | Iterable, 
        bin: ArrayLike | Iterable | None = None,
        n_data: ArrayLike | Iterable | None = None,
        deviation: ArrayLike | Iterable | None = None,
        power_max: ArrayLike | Iterable | None = None,
        power_min: ArrayLike | Iterable | None = None,
        factor: ArrayLike | Iterable | float | None = None):
    """
    Load complete power curves into the PowerCurve object

    Args:
        power (ArrayLike | Iterable): Array with avg power values
        bin (ArrayLike | Iterable | None, optional): Array with bins. 
                Defaults to None.
        n_data (ArrayLike | Iterable | None, optional): Array with number of 
                data points. Defaults to None.
        deviation (ArrayLike | Iterable | None, optional): Array with power
                deviation. Defaults to None.
        power_max (ArrayLike | Iterable | None, optional): Array with maximum
                power. Defaults to None.
        power_min (ArrayLike | Iterable | None, optional):  Array with minimum
                power. Defaults to None.
        factor (ArrayLike | Iterable | float | None, optional): Array with 
                applied factor to obtain min and max thresholds. 
                Defaults to None.
    """

    self.data = pd.DataFrame({'bin': bin, 'power': power})

    ## Option 1: Sigma + factor
    if deviation is not None and factor is not None:
        self.data['deviation'] = deviation
        self.data['factor'] = factor
        self.data['power_min'] = power - factor * deviation
        self.data['power_max'] = power + factor * deviation
    ## Option 2: Power min directly
    elif power_min is not None:
        self.data['power_min'] = power_min

    ## Complete with additional columns
    optional_args = [deviation, power_min, power_max, factor, n_data]
    optional_names = ["deviation", "power_min", "power_max", "factor", "n_data"]
    for arg, name  in zip(optional_args, optional_names):
        if arg is not None:
            self.data[name] = arg   

def load_data_points(
        self: PowerCurve, 
        data_points: pd.DataFrame):
    """
    Load data points for a power curve calculation

    Args:
        data_points (pd.DataFrame): DataFrame with data points to be used in
            power curve calculation. Should have the columns 'speed' and 'power'.
            Better to use the data attribute of a WindTurbine object
    """

    # Load only validated data
    self.data_points = data_points[data_points["validation_status"]].copy()
   
    # Assign a bin
    self.data_points["bin"] = self.data_points["speed"]\
        .apply(lambda x: round(x * 2) / 2)
    