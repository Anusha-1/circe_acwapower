"""
wod/power_curve/_bin.py

Methods for compute data points stats per bin
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

@property
def bin_stats(self: PowerCurve) -> pd.DataFrame | None:
    """
    Get bin statistics. The mean power per bin gives us an initial power curve

    Returns:
        (pd.DataFrame | None): DataFrame with bin stats (if there are data 
            points, otherwise we return None)
    """

    if self._bin_stats is None:
        ## Compute statistics

        df = self.data_points[~self.data_points['filter']]

        if len(df) > 0:
            self._bin_stats = df[["bin", "power"]]\
                .groupby(["bin"])\
                    .agg({"power": ("mean","std","count")})
        else:
            self._bin_stats = None

    return self._bin_stats
