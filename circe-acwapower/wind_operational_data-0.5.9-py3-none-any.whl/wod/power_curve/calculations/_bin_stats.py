"""
wod/power_curve/aux_calculations/_bin_stats.py

Auxiliary module with functions to organize bin-wise statistics
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

def create_initial_proposal(pc: PowerCurve) -> pd.DataFrame:
    """
    Takes the bin stats (property dataframe) of a PowerCurve, and organize it in
    a dataframe that will be the beggining for the computation of a generated
    power curve

    Args:
        pc (PowerCurve): PowerCurve object

    Returns:
        (pd.DataFrame | None): DataFrame with columns:
            - "power"
            - "deviation"
            - "n_data"
            - "raw_power_mean"
            - "raw_power_deviation"

            If we could build bin_stats we return None
    """

    if pc.bin_stats is not None:
        df = (
            pc.bin_stats.droplevel(0, axis=1)
            .reset_index()
            .rename(columns={"mean": "power", "std": "deviation", "count": "n_data"})
        )

        df["raw_power_mean"] = df["power"]
        df["raw_power_deviation"] = df["deviation"]

        return df
    
    return None

def complete_missing_bins(
        df: pd.DataFrame | None,
        max_bin: float) -> pd.DataFrame:
    """
    Complete missing bins. As we start with bin statistics, we might not have
    all the bins (if there are gaps of data). We fill those gaps here, adding 
    rows with empty bins

    Args:
        df (pd.DataFrame | None): Initial dataframe coming from bin stats.
            If None is passed, we'll construct an empty dataframe
        max_bin (float): Maximum bin to consider

    Returns:
        (pd.DataFrame): Dataframe filled with empty bins
    """

    # We create an artificial dataframe, just with all the bins from zero to max
    # Then, we join it with our initial dataframe.
    list_bins = list(np.arange(0,max_bin+0.5,0.5))
    df_empty = pd.DataFrame({"bin": list_bins})

    ## If we can, we use a dataframe to complete the proposal
    if df is not None:
        df = pd.merge(df_empty, df, how='left', on="bin")
    ## Otherwise, we fill it with empty columns
    else:
        df = df_empty
        df['power'] = np.nan
        df['deviation'] = np.nan
        df['n_data'] = np.nan
        df['raw_power'] = np.nan
        df['raw_deviation'] = np.nan

    # All columns (except bin) will have a NaN value. We only modify n_data to 
    # have a zero
    df["n_data"] = df["n_data"].fillna(0)

    return df

def organize_bin_stats(pc: PowerCurve, max_bin: float) -> pd.DataFrame:
    """
    Organize the bin stats of a PowerCurve, into an initial proposal of a 
    generated power curve

    Args:
        pc (PowerCurve): PowerCurve object
        max_bin (float): Maximum bin to consider

    Returns:
        (pd.DataFrame): DataFrame with columns:
        
            - "power"
            - "deviation"
            - "n_data"
            - "raw_power_mean"
            - "raw_power_deviation"
    """

    # Create an initial proposal from the PowerCurve data points bin statistics
    df = create_initial_proposal(pc)

    # Complete the dataframe with "empty bins", so we don't have any gap
    df = complete_missing_bins(df, max_bin)

    return df