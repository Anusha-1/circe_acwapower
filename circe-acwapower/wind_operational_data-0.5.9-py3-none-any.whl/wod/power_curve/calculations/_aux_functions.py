"""
wod/power_curve/calculations/_aux_functions.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import numpy.typing as npt
from scipy.optimize import curve_fit

if TYPE_CHECKING:
    import pandas as pd

def dropout_function(
        x: float | npt.ArrayLike,
        max_power: float, 
        dropout_bin: float, 
        last_power: float, 
        max_bin: float) -> float:
    """
    Function to replicate the behaviour of the curve at high winds with fixed
    parameters.

    Args:
        x (float | np.array): Wind speed
        max_power (float): Nominal power
        dropout_bin (float): Bin at which dropout begins
        last_power (float): Last value of power
        max_bin (float): Last bin

    Returns:
        float: Power at wind x
    """
    
    m = (max_power - last_power) / (max_bin - dropout_bin)

    if isinstance(x, float):
        return min(max_power - (x - dropout_bin)*m, max_power)
    
    result = np.array([])
    for i in x:
        result = np.append(
            result,
            min(max_power - (i - dropout_bin)*m, max_power))

    return result

def fit_dropout_parameters(
        df: pd.DataFrame,
        elbow: float,
        minimum_points_after_elbow: int
):

    ## Fit parameters
    df_aux = df[(df['bin'] > elbow) & (df['n_data'] > minimum_points_after_elbow)]
    
    ### Initial parameters
    p0 = (
        df['power'].max(),
        20.0,
        df['power'].max()*0.5,
        25.0
    )

    parameters, covariance = curve_fit(
        dropout_function, 
        list(df_aux['bin']), 
        list(df_aux['power']),
        p0)

    return parameters