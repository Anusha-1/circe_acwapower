"""
wod/power_curve/aux_calculations/_jump.py

Module to fix aggressive jumps
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from wod.warnings import warn_shape_jump, warn_reference_jump

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

def obtain_derivatives(df: pd.DataFrame) -> pd.DataFrame:
    """
    Obtain the first and second 

    Args:
        df (pd.DataFrame): Input Dataframe

    Returns:
        (pd.DataFrame): Output dataframe
    """

    df['power_first_deriv'] = df['power'].diff()
    df['power_second_deriv'] = df['power_first_deriv'].diff()

    return df

def get_position_consecutive_maxmin_at_second_deriv(
        df: pd.DataFrame) -> float | None:
    """
    Gets the position at which occurs a consecutive max-min in the 2nd 
    derivative of the power

    Args:
        df (pd.DataFrame): Input dataframe

    Returns:
        float | None: Bin position of the consecutive max-min. If it doesn't 
            occur, it returns None.
    """

    df_aux = df.set_index(['bin'])

    max_second_deriv = df_aux['power_second_deriv'].idxmax()
    min_second_deriv = df_aux['power_second_deriv'].idxmin()

    if abs(min_second_deriv - max_second_deriv) < 2.0:
        return max(min_second_deriv, max_second_deriv) + 0.5
    
    return None

def get_position_of_negative_before_elbow(
        df: pd.DataFrame,
        elbow: float,
        minimum_power_bin: float
) -> float | None:
    """
    Gets the first position (before the elbow), with a negative power first 
    derivative

    Args:
        df (pd.DataFrame): Input Dataframe
        elbow (float): Elbow value
        minimum_power_bin (float): First bin with allowed power data

    Returns:
        (float | None): Position of first negative in first derivative,
            before elbow. If this doesn't happen, returns None
    """
    
    df_aux = df[(df['bin'] < elbow) & (df['bin'] > minimum_power_bin)]\
        .set_index(['bin'])
    delta = -0.1 #To avoid sensitivity issues

    negative = (df_aux['power_first_deriv'] < delta)
    if any(negative):
        return df_aux[negative].index[0] - 0.5
    
    return None

def correct_jump_based_on_shape(
        df: pd.DataFrame, 
        pc: PowerCurve, 
        minimum_power_bin: float,
        data_threshold: int) -> pd.DataFrame:
    """
    Correct jump between bin statistics and reference, if we detect it

    Args:
        df (pd.DataFrame): Input Dataframe
        pc (PowerCurve): PowerCurve object
        minimum_power_bin (float): First bin with allowed power data
        data_threshold (int): Minimum count of data points to avoid jump
        
    Returns:
        (pd.DataFrame): Output dataframe
    """

    df = obtain_derivatives(df)

    last = get_position_consecutive_maxmin_at_second_deriv(df)
    first = get_position_of_negative_before_elbow(df, pc.elbow, minimum_power_bin)

    if first is not None and last is not None:

        ## Send a warning
        warn_shape_jump(pc, first, last)

        ## Check data count
        n_data = df[(df['bin'] >= (first - 0.6)) & (df['bin'] <= (last + 0.6))]['n_data']\
            .mean()

        if n_data < data_threshold:
            ## Delete power values in the area
            df.loc[(df['bin'] >= (first - 0.6)) & (df['bin'] <= (last + 0.6)), "power"] = np.nan

            ## Interpolates
            df['power'] = df['power'].interpolate(method="polynomial", order=2)
    
    return df

def correct_jump_based_on_difference(
        df: pd.DataFrame,
        pc: PowerCurve,
        value_threshold: float,
        data_threshold: int) -> pd.DataFrame:
    """
    Locates bins with a high difference with reference and low count of data 
    points, delete its previous values and interpolates

    Args:
        df (pd.DataFrame): Input Dataframe
        value_threshold (float): Minimum relative difference allowed
        data_threshold (int): Minimum count of data points

    Returns:
        (pd.DataFrame): Output dataframe
    """

    # Calculates differences
    df['difference'] = df['power'] - df['reference']
    df['rel_diff'] = df['difference'] / df['reference'].max() * 100

    # Check areas to correct
    checks = (df['rel_diff'].abs() > value_threshold) & (df['n_data'] < data_threshold)

    if any(checks):
        
        # Send a warning
        warn_reference_jump(
            pc, first=df[checks]['bin'].min(), last=df[checks]['bin'].max())

        # Delete
        df.loc[checks, 'power'] = np.nan

        # Interpolates
        df['power'] = df['power'].interpolate(method="polynomial", order=2)

    return df
