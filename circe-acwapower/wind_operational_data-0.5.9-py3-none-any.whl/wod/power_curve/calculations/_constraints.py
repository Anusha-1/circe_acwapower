"""
wod/power_curve/aux_calculations/_constraints.py

Module with constraints for power and deviation values
"""

import pandas as pd

from wod.power_curve.calculations._fill import complete_first_bins

def apply_constraints(
        df: pd.DataFrame,
        minimum_power_bin: float,
        deviation_at_first_bins: float,
        min_deviation_after_elbow: float,
        elbow: float,
) -> pd.DataFrame:
    """
    Apply some constraints to a power curve

    Args:
        df (pd.DataFrame): Input dataframe
        minimum_power_bin (float): First bin at which we can have a
            non-zero power.
        deviation_at_first_bins (float): Deviation to consider at the 
            first few bins (with 0 power)
        min_deviation_after_elbow (float): Deviation to consider after the elbow
        elbow (float): Value of the elbow

    Returns:
        (pd.DataFrame): Output dataframe
    """
    
    ## We can't surpass the max power limit
    df['power'] = df[['power', 'max_power_limit']].min(axis=1)

    ## We can't have negative values
    df['power'] = df['power'].apply(lambda x: max(0,x))

    ## and the first bins are zero for power (and fixed value for deviation)
    df = complete_first_bins(df, minimum_power_bin, deviation_at_first_bins)

    ## After elbow, there is also a minimum possible deviation
    df["deviation"] = df.apply(
        lambda row: max(row["deviation"], min_deviation_after_elbow) if row["bin"] > elbow else row["deviation"], 
        axis=1
    )

    ## and we also force a minimum deviation along the entire curve
    min_deviation = min(deviation_at_first_bins, min_deviation_after_elbow)
    df["deviation"] = df["deviation"]*(df["deviation"] > min_deviation)\
          + min_deviation_after_elbow*(df["deviation"] <= min_deviation)
    
    ## If we still have NaN at deviation (this can happen if reference curves
    ## are shorter than minimum bin), we fill it with min deviation
    df['deviation'] = df['deviation'].fillna(min_deviation)

    return df
