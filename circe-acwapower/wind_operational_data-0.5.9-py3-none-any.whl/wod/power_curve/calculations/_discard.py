"""
wod/power_curve/aux_calculations/_discard.py

Auxiliary functions to discard some power values before further computations
"""

import numpy as np
import pandas as pd

def __discard_points(
        row: pd.Series, 
        column: str, 
        elbow: float,
        minimum_points_before_elbow: float,
        minimum_points_after_elbow: float) -> None | float:
    """
    Row-wise function to replace a value in a column with NaN if we consider 
    that we don't have enough points

    Args:
        row (pd.Series): Row of the dataframe
        column (str): Column to consider
        elbow (float): Value of elbow in reference
        minimum_points_before_elbow (float): Minimum number of points needed
            before elbow
        minimum_points_after_elbow (float): Minimum number of points needed
            after elbow

    Returns:
        np.nan | float: Final value to consider for that field. If we had enough
            points, we'll respect the previous data, otherwise it will be
            replace by a NaN
    """
    
    if row["bin"] < elbow:
        minimum_points = minimum_points_before_elbow
    else:
        minimum_points = minimum_points_after_elbow

    return np.nan if row["n_data"] < minimum_points else row[column]


def discard_invalid_power_values(
        df: pd.DataFrame, 
        elbow: float,
        minimum_points_before_elbow: float,
        minimum_points_after_elbow: float) -> pd.DataFrame:
    """
    Discard invalid power values (because of low data) by replacing them with
    NaN

    Args:
        df (pd.DataFrame): Input DataFrame
        elbow (float): Value of elbow in reference
        minimum_points_before_elbow (float): Minimum number of points needed
            before elbow
        minimum_points_after_elbow (float): Minimum number of points needed
            after elbow

    Returns:
        (pd.DataFrame): Output dataframe
    """
    

    df["power"] = df.apply(
        __discard_points, 
        args=(
            "power", 
            elbow, 
            minimum_points_before_elbow, 
            minimum_points_after_elbow),
        axis=1)
    
    ## Also, we remove negative values
    df["power"] = df["power"].apply(lambda x: np.nan if x < 0 else x)

    return df

def discard_invalid_deviation_values(
        df: pd.DataFrame, 
        elbow: float,
        minimum_points_before_elbow: float,
        minimum_points_after_elbow: float) -> pd.DataFrame:
    """
    Discard invalid power deviation values (because of low data) by replacing 
    them with NaN

    Args:
        df (pd.DataFrame): Input DataFrame
        elbow (float): Value of elbow in reference
        minimum_points_before_elbow (float): Minimum number of points needed
            before elbow
        minimum_points_after_elbow (float): Minimum number of points needed
            after elbow

    Returns:
        (pd.DataFrame): Output dataframe
    """
    

    df["deviation"] = df.apply(
        __discard_points, 
        args=(
            "deviation", 
            elbow, 
            minimum_points_before_elbow, 
            minimum_points_after_elbow),
        axis=1)
    
    return df

def discard_values(
        df: pd.DataFrame, 
        elbow: float,
        minimum_points_before_elbow: float,
        minimum_points_after_elbow: float) -> pd.DataFrame:
    """
    Discard invalid power and deviation values (because of low data) by 
    replacing them with NaN

    Args:
        df (pd.DataFrame): Input DataFrame
        elbow (float): Value of elbow in reference
        minimum_points_before_elbow (float): Minimum number of points needed
            before elbow
        minimum_points_after_elbow (float): Minimum number of points needed
            after elbow

    Returns:
        (pd.DataFrame): Output dataframe
    """

    df = discard_invalid_power_values(
        df,
        elbow,
        minimum_points_before_elbow,
        minimum_points_after_elbow
    )

    df = discard_invalid_deviation_values(
        df,
        elbow,
        minimum_points_before_elbow,
        minimum_points_after_elbow
    )

    return df
