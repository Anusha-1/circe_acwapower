"""
wod/power_curve/aux_calculations/_smooth.py

Module for smoothing processes
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd
from scipy.signal import savgol_filter

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve


def smooth_area_value(
        df: pd.DataFrame, 
        field: str,
        area_mask: pd.Series[bool]) -> pd.DataFrame:
    """
    Smooth a certain area for 

    Args:
        df (pd.DataFrame): Input Dataframe
        field (str): Column to smooth
        area_mask (pd.Series[bool]): Bool series with rows to smooth as True

    Returns:
        (pd.DataFrame): Output DataFrame
    """    

    data_around_elbow = df[area_mask][field].values
    if len(data_around_elbow) > 3:
        data_around_elbow = savgol_filter(
            data_around_elbow,
            min(5, len(data_around_elbow)), ## Window length
            2, ## Polyorder 
        )
        df.loc[df[area_mask].index, field] = data_around_elbow

    return df

def smooth_elbow(df: pd.DataFrame, pc: PowerCurve) -> pd.DataFrame:
    """
    Smooth power and deviation in the elbow area. This is the point where we
    basically paste bin statistics with the reference curve.

    Args:
        df (pd.DataFrame): Input Dataframe
        pc (PowerCurve): PowerCurve

    Returns:
        (pd.DataFrame): Output DataFrame
    """

    elbow_area = (df["bin"] > pc.elbow - 2.0) & (df["bin"] < pc.elbow + 2.0)

    df = smooth_area_value(df, "power", elbow_area)
    df = smooth_area_value(df, "deviation", elbow_area)
    
    return df

def smooth_curve(
        df: pd.DataFrame, 
        field: str, 
        window_length: int, 
        polyorder:int) -> pd.DataFrame:
    """
    Smooths an entire column in the whole range

    Args:
        df (pd.DataFrame): Input Dataframe
        field (str): Column to smooth
        window_length (int): Window length of the SavGol filter that
            we apply to the entire power curve
        polyorder (int): Polynomial order of the SavGol filter that
            we apply to the entire power curve

    Returns:
        (pd.DataFrame): Output dataframe
    """

    df[field] = savgol_filter(
        df[field],
        window_length=window_length,
        polyorder=polyorder
    )

    return df
