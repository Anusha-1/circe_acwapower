"""
wod/power_curve/aux_calculations/_fill.py

Auxiliary functions to fill missing values
"""

import pandas as pd

def complete_first_bins(
        df: pd.DataFrame,
        minimum_power_bin: float,
        deviation_at_first_bins: float) -> pd.DataFrame:
    """
    Forces the values of power and deviation for the first bins.
    Power will be zero, and deviation is fixed to a value.

    Args:
        df (pd.DataFrame): Input DataFrame
        minimum_power_bin (float): First bin at which we can have a
            non-zero power.
        deviation_at_first_bins (float): Deviation to consider at the 
            first few bins (with 0 power)
    
    Returns:
        (pd.DataFrame): Output dataframe
    """

    df["power"] = df.apply(
        lambda row: 0 if row['bin'] < minimum_power_bin else row['power'],
        axis=1
    )
    df["deviation"] = df.apply(
        lambda row: row["deviation"] if row["bin"] >= minimum_power_bin else deviation_at_first_bins, 
        axis=1
    )

    return df

def interpolate_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fills NaN at power and deviation by applying an interpolation first, and 
    then a forward fill

    Args:
        df (pd.DataFrame): Input DataFrame

    Returns:
        (pd.DataFrame): Output Dataframe
    """

    df["power"] = df["power"].\
        interpolate(method="polynomial", order=2)\
        .ffill()
    df["deviation"] = df["deviation"]\
        .interpolate(method="polynomial", order=2)\
        .ffill()
    
    return df

def fill_missing_values(
        df: pd.DataFrame,
        minimum_power_bin: float,
        deviation_at_first_bins: float) -> pd.DataFrame:
    """
    Fills missing values of power and deviation

    Args:
        df (pd.DataFrame): Input DataFrame
        minimum_power_bin (float): First bin at which we can have a
            non-zero power.
        deviation_at_first_bins (float): Deviation to consider at the 
            first few bins (with 0 power)
    
    Returns:
        (pd.DataFrame): Output dataframe
    """

    # First, complete the initial bins
    df = complete_first_bins(df, minimum_power_bin, deviation_at_first_bins)

    # Then, interpolates (and extrapolates) for gaps
    df = interpolate_missing_values(df)

    return df
