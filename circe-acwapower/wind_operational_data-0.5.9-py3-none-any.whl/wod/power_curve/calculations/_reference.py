"""
wod/power_curve/aux_calculations/_reference.py

Module to manage the merging with the reference power curve
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from wod.power_curve.calculations._aux_functions import dropout_function

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve


def establish_limit(df: pd.DataFrame, pc: PowerCurve) -> pd.DataFrame:
    """
    Limits the power to its theoretical maximum, i.e. the nominal power before
    dropout and the reference curve after that.

    This also adds the columns: 'reference' and 'max_power_limit'

    Args:
        df (pd.DataFrame): Input Dataframe
        pc (PowerCurve): PowerCurve

    Returns:
        (pd.DataFrame): Output dataframe
    """

    df["reference"] = pc.reference_power_curve.data["power"]
    df["deviation_reference"] = pc.reference_power_curve.data["deviation"]

    df["max_power_limit"] = df.apply(
        lambda row: pc.nominal_power
        if row["bin"] <= pc.dropout_speed
        else row["reference"],
        axis=1,
    )
    df["power"] = df[["power", "max_power_limit"]].min(axis=1)

    return df


def establish_limit_without_reference(
    df: pd.DataFrame,
    max_power: float,
    dropout_bin: float,
    last_power: float,
    max_bin: float,
    deviation: float,
) -> pd.DataFrame:
    """
    Limits the power to its theoretical maximum, computed without a reference
    curve.

    This also adds the columns: 'reference' and 'max_power_limit'

    Args:
        df (pd.DataFrame): Input Dataframe
        max_power (float): Nominal power
        dropout_bin (float): Bin at which dropout begins
        last_power (float): Last value of power
        max_bin (float): Last bin
        deviation (float): Deviation to consider

    Returns:
        (pd.DataFrame): Output dataframe
    """

    if max_power is None:
        max_power = df["power"].max()
    if dropout_bin is None:
        dropout_bin = max_bin - 1.0
    if last_power is None:
        last_power = max_power

    df["reference"] = df["bin"].apply(
        dropout_function, args=(max_power, dropout_bin, last_power, max_bin)
    )
    df["deviation_reference"] = deviation
    df["max_power_limit"] = df["reference"]
    df["power"] = df[["power", "max_power_limit"]].min(axis=1)

    return df


def paste_reference(df: pd.DataFrame, pc: PowerCurve) -> pd.DataFrame:
    """
    Paste the reference curve in the current PowerCurve values after the elbow,
    for both power and deviation

    Args:
        df (pd.DataFrame): Input Dataframe
        pc (PowerCurve): PowerCurve

    Returns:
        (pd.DataFrame): Output dataframe
    """

    df["power"] = df["reference"] * (df["bin"] > pc.elbow) + df["power"] * (
        df["bin"] <= pc.elbow
    )
    df["deviation"] = df["deviation_reference"] * (df["bin"] > pc.elbow) + df[
        "deviation"
    ] * (df["bin"] <= pc.elbow)

    return df
