"""
wod/power_curve/_deriv.py

Methods to incorporate derivatives
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve


def calculate_deriv(self: PowerCurve, order: str | list[str] = 'first'):
    """
    Calculate derivatives of power
    """

    if not isinstance(order, list):
        order = [order]

    if 'first' in order:
        self.data["power_first_deriv"] = self.data["power"].diff()
    if 'second' in order:
        self.data["power_second_deriv"] = self.data["power"].diff().diff()
