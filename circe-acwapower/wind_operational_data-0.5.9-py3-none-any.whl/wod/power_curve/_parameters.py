"""
wod/power_curve/_parameters.py

Module for the calculation of important parameters for the curve
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

@property
def elbow(self: PowerCurve) -> float:
    """
    Calculates the elbow, i.e. the point at which the curve reaches the maximum

    Returns:
        float: Elbow value
    """

    if self._elbow is None:

        ## If we have a reference power curve, we try to take the elbow from it
        if self.reference_power_curve is not None:
            self._elbow = self.reference_power_curve.elbow

        ## If we don't have a reference curve, but we have a data attribute, 
        ## we'll calculate from there
        elif self.data is not None:

            try:
                deriv = self.data["power"].diff() * 2.0
                deriv_perc = deriv / self.data['power'].max() * 100
                bin_max_slope = self.data.loc[deriv.idxmax()]["bin"]

                deriv_threshold = 5 # HARD-CODED PARAMETER !!

                saturation = (deriv_perc < deriv_threshold) * (self.data["bin"] > bin_max_slope)

                self._elbow = self.data[saturation]["bin"].min()
            except Exception:
                self._elbow = 12.0
                ## This might be the best solution, but we should look into this

        ## If we don't have either, we raise an error
        else:
            raise Exception("Unable to calculate elbow")

    return self._elbow

@property
def nominal_power(self: PowerCurve) -> float:
    """
    Calculates the nominal power of the power curve

    Returns:
        float: Max power
    """

    if self._nominal_power is None:

        if self.reference_power_curve is not None:
            self._nominal_power = self.reference_power_curve.nominal_power
        else:            
            self._nominal_power = self.data["power"].max()

    return self._nominal_power

@property
def dropout_speed(self: PowerCurve) -> float:
    """
    Calculates the speed at which dropout begins

    Returns:
        float: Max power
    """

    if self._dropout_speed is None:

        if self.data is not None:
            df_aux = self.data.sort_values(by="bin", ascending=False)
            self._dropout_speed = df_aux.loc[df_aux["power"].idxmax()]["bin"]

        else:
            self._dropout_speed = self.reference_power_curve.dropout_speed

    return self._dropout_speed
