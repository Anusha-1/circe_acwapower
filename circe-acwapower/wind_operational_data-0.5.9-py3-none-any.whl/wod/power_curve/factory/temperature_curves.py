"""
wod/power_curve/factory/temperature_curves.py

Module to load different temperature-specific power curves
"""

import os
import pathlib

import numpy as np
import pandas as pd

from wod.power_curve import PowerCurve

def load_temperature_power_curves_from_file(
        file: os.PathLike,
        bin_column: str = 'bin',
        temp_column: str | tuple[str] | list[str] = ('Tmin', 'Tmax'),
        temp_extremes: tuple[int] | list[int] = (-20, 50),
        avg_prefix: str = 'mu',
        sd_prefix: str = 'sigma',
        use_as_suffix: bool = False,
        factor: float = 2.5,
        cut_value: float = 25.0,
        **kwargs
) -> dict[str, list[PowerCurve]]:
    """
    Loads different PowerCurves for different turbines and temperature segments
    from a table file

    Args:
        file (os.PathLike): Path to the txt file that contains all the power
            curves.
        bin_column (str, optional):Name of the column that specifies the bins.
            Defaults to 'bin'.
        temp_column (str | tuple[str] | list[str], optional): string or tuple of 
            strings, that specify the temperature column(s). If a string is 
            passed, we assume we only have a temperature column. If a tuple is 
            passed we assume that we have an interval. In that case, first 
            element of the tuple is the lower limit, and the second is the 
            upper. Defaults to ('Tmin', 'Tmax').
        temp_extremes (tuple[int] | list[int], optional): Minimum and maximum 
            temperatures considered in the input file. They will be transform to
            +-inf. Defaults to (-20, 50).
        avg_prefix (str, optional): Prefix of the columns that contains mean 
            power values. Defaults to 'mu'.
        sd_prefix (str, optional): Prefix of the columns with the standard 
            deviation power values. Defaults to 'sigma'.
        use_as_suffix (bool, optional): If True, it change the average and sd
            prefixes to suffixes instead. Default to False
        factor (float, optional): Factor to apply to obtain lower and upper 
            power bounds. Defaults to 2.5.
        cut_value (float, optional): Last bin to consider. From this bin, the 
            power drops to zero. Defaults to 25.0.
        **kwargs: Additional keyword arguments for the pandas function used
            to read the input data. The function will vary depending on the 
            extension of the file (read_csv, read_excel, ...)

    Returns:
        (dict[str, list[PowerCurve]]): Dictionary that recopilates the 
            PowerCurves:
            
            - key: Turbine designation
            - value: List of PowerCurves (one for each temperature segment)
    """
    

    ## Read dataframe
    file = pathlib.Path(file)
    if file.suffix in ['.txt', '.csv']:
        df: pd.DataFrame = pd.read_csv(file, sep = '\t', **kwargs)
    elif file.suffix in ['.xls', '.xlsx']:
        df: pd.DataFrame = pd.read_excel(file, **kwargs)
    else:
        raise ValueError("Unrecognized extension")

    ## Mark a reference temp column, to extract unique values
    ref_temp_column = temp_column
    flag_tuple = False
    if isinstance(temp_column, (tuple, list)):
        ref_temp_column = temp_column[0]
        flag_tuple = True

    ## Extract turbine info
    ### Look for all avg and sd columns
    if not use_as_suffix:
        avg_cols = [col for col in df.columns if col.startswith(avg_prefix)]
        sd_cols = [col for col in df.columns if col.startswith(sd_prefix)]
    else:
        avg_cols = [col for col in df.columns if col.endswith(avg_prefix)]
        sd_cols = [col for col in df.columns if col.endswith(sd_prefix)]

    assert len(avg_cols) == len(sd_cols), "Mismatch number of avg and sd columns"
    assert len(avg_cols) > 0, "Unable to find avg and sd columns"

    ### Extract the suffixes of these columns as the turbine names
    if not use_as_suffix:
        avg_suffixes = [x[len(avg_prefix) :] for x in avg_cols]
        sd_suffixes = [x[len(sd_prefix) :] for x in sd_cols]
    else:
        avg_suffixes = [x[:-len(avg_prefix)] for x in avg_cols]
        sd_suffixes = [x[:-len(sd_prefix)] for x in sd_cols]

    assert set(sd_suffixes) == set(avg_suffixes),\
        "Mismatch on turbine designations in avg and sd columns"

    lst_turbines = avg_suffixes

    ## Loop over turbines
    dict_curves: dict[str, list[PowerCurve]] = {}
    for turbine_name in lst_turbines:

        dict_curves[turbine_name] = []

        if not use_as_suffix:
            avg_col_name = f"{avg_prefix}{turbine_name}"
            sd_col_name = f"{sd_prefix}{turbine_name}"
        else:
            avg_col_name = f"{turbine_name}{avg_prefix}"
            sd_col_name = f"{turbine_name}{sd_prefix}"
    
        df_aux: pd.DataFrame = pd.concat(
            [
                df[bin_column],
                df[avg_col_name],
                df[sd_col_name],
            ],
            axis = 1,
        )
        if flag_tuple:
            df_aux[temp_column[0]] = df[temp_column[0]] 
            df_aux[temp_column[1]] = df[temp_column[1]]
        else:
            df_aux[temp_column] = df_aux[temp_column]

        df_aux = df_aux.rename(
            columns={
                bin_column: "bin",
                avg_col_name: "power",
                sd_col_name: "deviation",
            }
        )
        df_aux['factor'] = factor

        ## Loop over temperatures
        lst_temp = list(set(df_aux[ref_temp_column]))
        lst_temp.sort()
        for temp in lst_temp:

            df_aux2: pd.DataFrame = df_aux[df_aux[ref_temp_column] == temp].copy()

            ## Extract temperature values
            if flag_tuple:
                temp_min = df_aux2[temp_column[0]].iloc[0]
                temp_max = df_aux2[temp_column[1]].iloc[0]

                if temp_min <= temp_extremes[0]:
                    temp_min = -np.inf
                    temp_ref = temp_max
                elif temp_max >= temp_extremes[1]:
                    temp_max = np.inf
                    temp_ref = temp_min
                else:
                    temp_ref = 0.5*(temp_max + temp_min)

            else:
                temp_ref = temp     

            ## Prepare metadata
            metadata = {
                'type': 'temperature',
                'temperature': temp_ref}
            if flag_tuple:
                metadata['max_temperature'] = temp_max
                metadata['min_temperature'] = temp_min

            ## Patch the end of the curve
            df_aux2['power'] = df_aux2['power']\
                .ffill() * (df_aux2['bin'] <= cut_value)
            df_aux2['deviation'] = df_aux2['deviation']\
                .ffill() * (df_aux2['bin'] <= cut_value)

            df_aux2 = df_aux2.reset_index(drop=True)

            dict_curves[turbine_name].append(
                PowerCurve.from_dataframe(
                    df_aux2[['bin','power','deviation','factor']], 
                    metadata=metadata
                )
            )
    
    return dict_curves
    