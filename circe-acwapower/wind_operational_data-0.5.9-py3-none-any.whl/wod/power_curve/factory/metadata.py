"""
wod/power_curve/factory/metadata.py

Module to build power curve's metadata dictionary, to be used to build new
Power Curves
"""

import numpy as np

def build_metadata_list_by_temperature(
        temp_boundaries: list[float]
) -> list[dict]:
    """
    Build a list of metadata dictionaries for different temperature segments, 
    given a list of temperature boundaries: T1, T2, ..., TN.
    The temperature segments will be [-inf, T1], [T1, T2], ... , [TN, inf]

    The list can then be used to create power curves, using the 
    WindFarm / WindTurbine method create_power_curves
    
    Args:
        temp_boundaries (list[float]): List of temperature boundaries to define
            the segments. The boundaries should not include +- inf.

    Returns:
        (list[dict]): List of metadata dictionaries, with the keys: "type", 
            "temperature", "max_temperature" and "min_temperature"
    """

    start_temp = -np.inf
    temp_boundaries.sort()
    temp_boundaries.append(np.inf)

    lst_metadata = []
    for temp in temp_boundaries:

        if start_temp == -np.inf:
            mean_temp = temp
        elif temp == np.inf:
            mean_temp = start_temp
        else:
            mean_temp = 0.5*(start_temp + temp)

        lst_metadata.append(
            {
                "type": "temperature",
                "temperature": mean_temp,
                "max_temperature": temp,
                "min_temperature": start_temp
            }
        )

        start_temp = temp

    return lst_metadata
