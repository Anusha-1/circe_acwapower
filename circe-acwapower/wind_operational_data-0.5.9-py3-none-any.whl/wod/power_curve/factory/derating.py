"""
wod/power_curve/factory/derating.py

Module to add derating to external power curves
"""

from wod.power_curve import PowerCurve

def add_derating(
        dict_curves: dict[str, PowerCurve], 
        derating_info: list[dict]) -> dict[str, list[PowerCurve]]:
    """
    Add derating information to a dictionary of reference power curves, so a 
    base power curve is limited to different max thresholds for each temperature

    Args:
        dict_curves (dict[str, PowerCurve]): Original base curves for each turbine.

            - key: Turbine name
            - value: PowerCurve object
        
        derating_info (list[dict]): Derating information. Is a list that 
            contains dictionaries. Each dictionary has the structure:

                {"turbines": [],
                "segments":[
                    {
                        "temperature":
                        "max_power":
                    }
                ]}

            "turbines" is the list of turbines for which the temperature 
            segments from "segments" apply. This way we can have different
            segments for different turbines.

    Returns:
        (dict[str, list[PowerCurve]]): Dictionary with:

            - key: Turbine name
            - value: List of PowerCurves
    """

    new_dict_curves: dict[str, list[PowerCurve]] = {}
    for turbine, pc in dict_curves.items():

        new_dict_curves[turbine] = []

        segments = []
        for turbine_info in derating_info:
            if turbine in turbine_info["turbines"]:
                segments = turbine_info["segments"]
                continue

        for item in segments:

            ## Apply max power
            df_aux = pc.data.copy()
            df_aux['new_power'] = df_aux['power'].apply(
                lambda x: min(x, item['max_power'])
            )

            ## Lower min power, assuming the same sigma
            delta = df_aux['new_power'] - df_aux['power']
            df_aux['new_power_min'] = df_aux['power_min'] + delta

            ## Drop old cols and rename
            df_aux = df_aux.drop(columns=['power', 'power_min'])
            df_aux = df_aux.rename(columns={
                'new_power': 'power',
                'new_power_min': 'power_min'
            })

            ## New PowerCurve
            metadata = item.copy()
            metadata.pop('max_power')
            metadata['type'] = 'temperature'
            new_dict_curves[turbine].append(
                PowerCurve.from_dataframe(df_aux, metadata=metadata))

    return new_dict_curves
