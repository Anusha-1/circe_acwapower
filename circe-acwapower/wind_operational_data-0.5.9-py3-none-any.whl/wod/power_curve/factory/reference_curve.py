"""
wod/power_curve/factory/reference_curve.py

Module to read reference curve from external files
"""

import os

import pandas as pd

from wod.power_curve import PowerCurve

def read_external_reference_curve(
        file_path: os.PathLike,
        turbine_column: str = 'WTG',
        turbine_transformation: str = 'str',
        cols_names: dict[str, str] = {'power': "Avg. Power"}
        ) -> dict[str, PowerCurve]:
    """
    Reads Power Curves for each turbine from an external file

    Args:
        file_path (os.PathLike): Path to file
        turbine_column (str, optional): Column name with turbine info. 
            Defaults to 'WTG'.
        turbine_transformation (str, optional): How to transform turbine designation. 
            Options are:

            - 'str': Coerce to string
            - None: Do nothing
            
            Defaults to 'str'.
        cols_names (dict[str, str], optional): Dictionary with columns to 
            include, key is how it should be name for PowerCurve init, and value
            is the name of the column in the input data. 'power' is mandatory. 
            Defaults to {'power': "Avg. Power"}.

    Returns:
        (dict[str, PowerCurve]): Dictionary of PowerCurve objects. 
            Key is the turbine designation
    """

    assert 'power' in cols_names.keys(), "power is mandatory in cols_names"

    # Read data
    df = pd.read_csv(file_path, sep="\t")

    # Loop in turbines
    dict_curves: dict[str, PowerCurve] = {}
    for turbine in set(df[turbine_column]):

        # Filter data for turbine
        df_aux = df[df[turbine_column] == turbine]

        # Turbine designation
        turbine_designation = turbine
        if turbine_transformation == 'str':
            turbine_designation = str(turbine_designation)

        # Extract power (mandatory)
        power = df_aux[cols_names['power']]

        # Extract other columns in a dictionary (as kwargs)
        kwargs = dict()
        for key in cols_names.keys():
            if key != 'power':
                kwargs[key] = df_aux[cols_names[key]]
    
        # Create the PowerCurve object
        metadata = {"type": "global"}
        dict_curves[turbine_designation] = PowerCurve.from_series(
            power, metadata=metadata, **kwargs)

    return dict_curves
