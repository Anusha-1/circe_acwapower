"""
wod/power_curve/factory/aggregate_power_curves.py

Module for aggregation of power curves into an aggregated power curve
"""

from wod.power_curve import PowerCurve

def aggregate_temp_power_curves(
        dict_temp_power_curves: dict[str, list[PowerCurve]]
) -> dict[str, PowerCurve]:
    """
    Takes different PowerCurves per turbine and aggregates them into a single
    PowerCurve.

    Args:
        dict_temp_power_curves (dict[str, list[PowerCurve]]): Dictionary with
            a list of PowerCurves (value) per each turbine (key)    

    Returns:
        dict[str, PowerCurve]: Returns a dictionary with a unique PowerCurve per
            turbine.
    """
    
    dict_global_power_curves: dict[str, PowerCurve] = {}
    for key, list_pc in dict_temp_power_curves.items():

        ## Initial dataframe
        df = list_pc[0].data.set_index('bin').add_suffix("_0")

        ## Join the other power curves
        for i, pc in enumerate(list_pc[1:]):            
            df = df.join(
                pc.data.set_index('bin').add_suffix(f"_{i+1}"),
                how="outer",
            )

        ## Build aggregated power values
        df['power'] = df.filter(regex=("power_[0-9]+")).mean(axis=1)
        df['power_max'] = df.filter(regex=("power_max_[0-9]+")).max(axis=1)
        df['power_min'] = df.filter(regex=("power_min_[0-9]+")).min(axis=1)
        df['factor'] = df.filter(regex=("factor_[0-9]+")).max(axis=1)

        ## Extract a reference sigma
        df['sigma_down'] = (df['power'] - df['power_min']) / df['factor']
        df['sigma_up'] = (df['power_max'] - df['power']) / df['factor']
        df['deviation'] = df[['sigma_down', 'sigma_up']].max(axis=1)

        ## Clean the dataframe
        df = df[['power', 'deviation', 'factor', 'power_min', 'power_max']]
        df = df.reset_index()

        dict_global_power_curves[key] = PowerCurve.from_dataframe(
            df, metadata={'type': 'global'})

    return dict_global_power_curves
