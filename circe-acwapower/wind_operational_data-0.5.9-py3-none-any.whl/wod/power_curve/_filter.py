"""
wod/power_curve/_filter.py

Methods for filtering data points
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from scipy import interpolate

if TYPE_CHECKING:
    import pandas as pd
    from wod.power_curve import PowerCurve


def filter_points(
        self: PowerCurve, 
        min_wind: float = 0.0, 
        max_wind: float = 30.0):
    """
    Applies different filtering options to the data points.

    It creates an additional column 'filter', which indicates the data points
    that should be filtered due to the filters we decide to implement

    Args:
        min_wind (float, optional): Minimum wind of the data points to be
            considered. Defaults to 0.0.
        max_wind (float, optional): Maximum wind of the data points to be
            considered. Defaults to 30.0.
    """

    self.data_points["filter"] = False

    ## Filter points for wind
    self.data_points["filter"] = self.data_points["filter"] | (
        self.data_points["speed"] < min_wind
    )
    self.data_points["filter"] = self.data_points["filter"] | (
        self.data_points["speed"] > max_wind
    )

    ## Filter with reference
    if self.reference_power_curve is not None:
        self.data_points = __filter_with_reference(
            self.data_points, self.reference_power_curve
        )

    ## Filter without reference
    else:
        self.data_points = __filter_without_reference(
            self.data_points
        )

def __filter_with_reference(
        df: pd.DataFrame, reference_pc: PowerCurve
) -> pd.DataFrame:
    """
    Filters wind/speed data points based on a previous power curve

    Args:
        df (pd.DataFrame): Dataframe with data points. Needs columns: 'bin', 
            'power' and 'filter'
        reference_pc (PowerCurve): Reference Power Curve

    Returns:
        (pd.DataFrame): Dataframe with filtered data points
    """

    # Interpolate an upper and lower threshold function
    for col in ['power_min', 'power_max']:
        df_group = reference_pc.data[['bin', col]]
        f = interpolate.interp1d(
            df_group['bin'], df_group[col],
            bounds_error=False,
            fill_value=(
                df_group[col].iloc[0],
                df_group[col].iloc[-1]
            )
        )

        if col == 'power_min':
            df['lower_threshold'] = f(df['speed'])
        else:
            df['upper_threshold'] = f(df['speed'])
    
    ## Lower threshold per bin    
    df["filter"] = df.apply(
        lambda row: row["filter"] if row["power"] > row["lower_threshold"] else True,
        axis=1
    )
    df = df.drop(columns=["lower_threshold"])

    ## Upper threshold per bin    
    df["filter"] = df.apply(
        lambda row: row["filter"] if row["power"] < row["upper_threshold"] else True,
        axis=1
    )
    df = df.drop(columns=["upper_threshold"])

    return df

def __filter_without_reference(
        df: pd.DataFrame, 
        min_power_bin: float = 3.0, 
        min_percentile: float = 0.05,
        max_percentile: float = 0.95
) -> pd.DataFrame:
    """
    Filters data without a previous power curve reference.

    It follows the following algortihm:

        1. Remove zeroes beyond min_power_bin
        2. Calculate percentiles (min_percentile and max_percentile) per bin
        3. Use the percentiles to filter out data

    Args:
        df (pd.DataFrame): Dataframe with data points. Required columns: 'bin',
            'power', 'speed'
        min_power_bin (float, optional): Maximum bin where we allow zeroes. 
            Defaults to 3.0.
        min_percentile (float, optional): Percentile used for lower threshold. 
            Defaults to 0.05.
        max_percentile (float, optional): Percentile used for upper threshold. 
            Defaults to 0.95.

    Returns:
        (pd.DataFrame): Dataframe with filtered data points
    """
    
    # 1. Remove zeroes 
    def __keep_point(row):
        if row['speed'] > min_power_bin and row['power'] <= 0.0:
            return True
        return row['filter']
    df['filter'] = df.apply(__keep_point, axis=1)

    # 2. Calculate percentiles
    df_group = df[~df['filter']].groupby('bin').agg(
        upper_threshold = ('power', lambda x: x.quantile(max_percentile)),
        lower_threshold = ('power', lambda x: x.quantile(min_percentile)),
    )
    df_group = df_group.reset_index()

    # 3. Interpolate an upper and lower threshold function
    for col in ['upper_threshold', 'lower_threshold']:

        f = interpolate.interp1d(
            df_group['bin'], df_group[col],
            bounds_error=False,
            fill_value=(
                df_group[col].iloc[0],
                df_group[col].iloc[-1]
            )
        )

        df[col] = f(df['speed'])

    # 4. Use the percentiles to filter data
    df['filter'] = df.apply(
        lambda row: (row['power'] < row['lower_threshold']) or (row['power'] > row['upper_threshold']) or row['filter'],
        axis=1
    )

    df = df.drop(columns=["upper_threshold", "lower_threshold"])

    return df
