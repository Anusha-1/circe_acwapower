"""
src/wod/power_curve/__init__.py

Defintion of the class PowerCurve
"""

from __future__ import annotations

from typing import Iterable

import pandas as pd
from numpy.typing import ArrayLike

import wod.errors as errors

class PowerCurve:
    """
    PowerCurve class: Organizes the data related to a power curve

    Attributes:
        metadata (dict): Metadata of the power curve. It is used mainly to 
            specify temperature settings: 'temperature', 'max_temperature' and
            'min_temperature'. However, it has a free structure and other 
            relevant information might be introduced here as well 
        data (pd.DataFrame): DataFrame with all information related to the power
            curve. Minimum set of columns are 'bin' and 'power', but more 
            columns might be available if passed to the load method.
        data_points (pd.DataFrame): DataFrame with the data points of power and
            speed that will be used to calculate the power curve
        reference_power_curve (PowerCurve): PowerCurve object that serves as
            reference for the new calculated power curve
        bin_stats (pd.DataFrame): Statistics (mean, std, count) per bin
        elbow (float): Points at which the curve is reaching the saturation
        nominal_power (float): Maximum power of the curve
        dropout_speed (float): Speed at which dropout starts
        difference (pd.DataFrame): Dataframe with difference between new power
            curve and reference
        total_difference (dict): Dictionary with total difference results

    """
    
    ## Import methods
    from ._bin import bin_stats
    from ._calculate import calculate_power_curve
    from ._complete import calculate_lower_threshold, calculate_upper_threshold
    from ._deriv import calculate_deriv
    from ._difference import difference, total_difference
    from ._filter import filter_points
    from ._load import (
        load_complete_power_curves,
        load_data_points
    )
    from ._parameters import (
        elbow,
        nominal_power,
        dropout_speed
    )
    from ._plot import plot

    def __init__(self, metadata: dict = {}):
        """Initialization method

        Args:
            metadata (dict, optional): Metadata values to consider. 
                Defaults to {}.
        """

        self.metadata = metadata
        if 'type' not in self.metadata.keys():
            self.metadata['type'] = 'unknown'

        ## Attributes
        self.data: pd.DataFrame | None = None
        self.data_points: pd.DataFrame | None = None
        self.reference_power_curve: PowerCurve | None = None

        ## Properties
        self._bin_stats: pd.DataFrame | None = None     
        self._elbow: float | None = None  
        self._nominal_power: float | None = None
        self._dropout_speed: float | None = None
        self._difference: pd.DataFrame | None = None
        self._total_difference: dict | None = None

    def __str__(self):
        return f"PowerCurve(columns={list(self.data.columns)})"

    def __repr__(self):
        text_string = "Power Curve \n"
        text_string += f"Available columns: {list(self.data.columns)} \n" 
        for key, value in self.metadata.items():
            text_string += f" --> {key}: {value} \n"
        return text_string

    @classmethod
    def from_series(
        cls, 
        power: ArrayLike | Iterable, 
        metadata: dict = {}, 
        **kwargs) -> PowerCurve:
        """
        Initializes a PowerCurve object, loading the power values (and other
        related series), directly

        Args:
            power (ArrayLike | Iterable): Sequence of Power Values
            metadata (dict, optional): Metadata values to consider.
                Defaults to {}
            **kwargs: Additional series to introduce. Possible options are:
                "bin", "n_data", "power_max", "power_min", "factor"
    
        Returns:
            (PowerCurve): PowerCurve object with the given data
        """

        pc = cls(metadata = metadata)
        pc.load_complete_power_curves(power, **kwargs)

        return pc
        
    @classmethod
    def from_dataframe(
        cls, df: pd.DataFrame, metadata: dict = {}) -> PowerCurve:
        """Initializes a power curve from a dataframe

        Args:
            df (pd.DataFrame): DataFrame with a power curve. Its column must 
                have the proper names: 'power', "bin", "deviation", "power_min",
                "power_max", "factor", "n_data"
            metadata (dict, optional): Metadata associated with the power curve.
                Defaults to {}.

        Returns:
            (PowerCurve): An object of the PowerCurve class, with the given data
        """

        power = df['power']
        list_args = [
            "bin", "deviation", "power_min", "power_max", "factor", "n_data"]
        kwargs = {}
        for a in list_args:
            if a in df.columns:
                kwargs[a] = df[a]
        
        return cls.from_series(power, metadata = metadata, **kwargs)

    @classmethod
    def from_data_points(
        cls, 
        data_points: pd.DataFrame,
        reference_power_curve: PowerCurve = None,
        filter_points_kwargs: dict = {},
        algorithm_kwargs: dict = {},
        metadata: dict = {}
    ) -> PowerCurve:
        """
        Initializes a PowerCurve object from data points

        Args:
            data_points (pd.DataFrame): DataFrame with data points to use. Needs
                the columns 'speed' and 'power'
            reference_power_curve (PowerCurve, optional): PowerCurve object to
                use as reference. Defaults to None.
            filter_points_kwargs (dict, optional): Keyword arguments for the 
                filtering of data points. Check the method function
                filter_points at wod/power_curve/_filter.py.                
                Defaults to {}
            algorithm_kwargs (dict, optional): Keyword arguments for the 
                algorithm that calculates the power curve. Check the method
                function calculate_power_curve at wod/power_curve/_calculate.py.
                Defaults to {}
            metadata (dict, optional): Metadata information. Defaults to {}.

        Returns:
            (PowerCurve): PowerCurve object build from the given data points
        """

        ## Load data points
        metadata_aux = metadata.copy()
        pc = cls(metadata = metadata_aux)
        pc.load_data_points(data_points)

        ## Load reference power curve
        if reference_power_curve is not None:
            assert isinstance(reference_power_curve, PowerCurve), \
                "reference_power_curve should be a PowerCurve object"
        pc.reference_power_curve = reference_power_curve
      
        if len(pc.data_points) == 0 and reference_power_curve is None:
            raise errors.NumberDataPointsException(pc)

        ## Filter data points 
        pc.filter_points(**filter_points_kwargs)
                        
        ## Calculate power curve
        pc.calculate_power_curve(**algorithm_kwargs)

        ## Complete missing information
        pc.calculate_upper_threshold()
        pc.calculate_lower_threshold()
        
        return pc
