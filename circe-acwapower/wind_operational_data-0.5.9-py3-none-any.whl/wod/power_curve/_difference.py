"""
wod/power_curve/_difference.py

Methods for computing the difference between new power curve and reference
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve

@property
def difference(self: PowerCurve) -> pd.DataFrame:
    """
    Obtain a dataframe with the difference between new and reference power curve

    Returns:
        (pd.DataFrame): Dataframe with difference values per bin
    """

    if self._difference is None:

        # Merge data
        df = self.data[['bin', 'power']]\
                .join(self.reference_power_curve.data[['bin', 'power']].set_index(['bin']),
                      on='bin',
                      how='left',
                      lsuffix='_new',
                      rsuffix='_reference')
        
        # Difference
        df['difference'] = df['power_new'] - df['power_reference']
        df['rel_diff'] = df['difference'] / df['power_reference'] * 100
        df['rel_diff_with_max'] = df['difference'] / df['power_reference'].max() * 100

        self._difference = df

    return self._difference

@property
def total_difference(self: PowerCurve) -> dict:
    """
    Obtains a measure of the difference between new and reference curve in the
    full range

    Returns:
        dict: Dictionary with metadata and results
    """

    if self._total_difference is None:

        # Start with the metadata
        dict_result = self.metadata.copy()

        # Calculate values
        sum_power = self.difference['power_new'].sum()
        sum_abs_diff = self.difference['difference'].abs().sum()
        dict_result['relative_difference_perc'] = sum_abs_diff / sum_power * 100

        self._total_difference = dict_result

    return self._total_difference
