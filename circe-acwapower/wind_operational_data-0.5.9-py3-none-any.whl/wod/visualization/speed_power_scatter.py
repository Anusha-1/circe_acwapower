"""
src/visualization/speed_power_scatter.py

Module with visualization tools for Power vs Speed scatter plots
"""

import pandas as pd
import plotly.graph_objects as go


def plot_power_vs_speed(
    data: pd.DataFrame,  
    size: int = 1,
    hover: bool = True,
    color: str = 'black',
    **kwargs) -> "go.Figure":
    """
    Plot power vs speed

    Args:
        data (pd.DataFrame): Dataframe with columns: 
            speed, power, validation_status
        size (int, optional): Size of the points. Defaults to 1
        hover (bool): Displays hover info. Defaults to True
        color (str): Color of the points

    Returns:
        (go.Figure): Plotly figure
    """

    ## Filter data
    data = data[data.validation_status]

    fig = go.Figure()

    if hover:
        hovertemplate = "Speed: %{x:.2f} <br>Power: %{y:.2f}<extra></extra>"
        hoverinfo = None
    else:
        hovertemplate = None
        hoverinfo = "skip"

    fig.add_trace(
        go.Scatter(
            name="Timeseries Data Points",
            x=data["speed"],
            y=data["power"],
            mode="markers",
            marker=dict(color=color, line_width=0, size=size),
            hovertemplate=hovertemplate,
            hoverinfo=hoverinfo,
            legendgroup="Timeseries Data Points"
        )
    )

    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")

    return fig

def plot_power_vs_speed_with_temp(
    data: pd.DataFrame,
    size: int = 1,
    hover: bool = True,
    **kwargs
) -> "go.Figure":
    """
    Plot power vs speed

    Args:
        data (pd.DataFrame): Dataframe with columns: 
            speed, power, validation_status
        size (int, optional): Size of the points. Defaults to 1
        hover (bool): Displays hover info. Defaults to True

    Returns:
        (go.Figure): Plotly figure
    """

    ## Filter data
    data = data[data.validation_status]

    fig = go.Figure()

    if hover:
        hovertemplate = "Speed: %{x:.2f} <br>Power: %{y:.2f} <br>Temperature: %{text:.2f}<extra></extra>"
        hoverinfo = None
    else:
        hovertemplate = None
        hoverinfo = "skip"

    fig.add_trace(
        go.Scatter(
            name="Timeseries Data Points",
            x=data["speed"],
            y=data["power"],
            mode="markers",
            marker=dict(
                color=data["temperature"],
                colorscale="Cividis",
                colorbar=dict(title="Temperature", orientation='h'),
                line_width=0,
                size=size,
            ),
            text=data['temperature'],
            hovertemplate=hovertemplate,
            hoverinfo=hoverinfo,
            legendgroup="Timeseries Data Points"
        )
    )

    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")
    fig.update_layout(coloraxis_colorbar=dict(orientation="h"))

    return fig

def plot_power_vs_speed_with_temp_segments(
    data: pd.DataFrame,
    temp_segments: list[dict],
    size: int = 1,
    hover: bool = True,
    **kwargs
) -> "go.Figure":
    """
    Plot power vs speed at different temp segments

    Args:
        data (pd.DataFrame): Dataframe with columns: 
            speed, power, validation_status
        temp_segments: Temperature segments to consider.
            Expected format is a list of dictionaries, and for each segment:
            'name', 'min', 'max', 'color'
        size (int, optional): Size of the points. Defaults to 1
        hover (bool): Displays hover info. Defaults to True

    Returns:
        (go.Figure): Plotly figure
    """
    
    ## Filter data
    data = data[data.validation_status]

    fig = go.Figure()

    if hover:
        hovertemplate = "Speed: %{x:.2f} <br>Power: %{y:.2f} <br>Temperature: %{text:.2f}<extra></extra>"
        hoverinfo = None
    else:
        hovertemplate = None
        hoverinfo = "skip"

    ## Loop in segments
    for segment in temp_segments:

        data_aux = data[(data.temperature>=segment["min"]) & (data.temperature<segment["max"])]

        fig.add_trace(
            go.Scatter(
                name="Data Points",
                x=data_aux["speed"],
                y=data_aux["power"],
                mode="markers",
                marker=dict(line_width=0, size=size, color=segment['color']),
                text=data_aux['temperature'],
                hovertemplate=hovertemplate,
                hoverinfo=hoverinfo,
                legendgroup=segment["name"],
                legendgrouptitle_text=segment["name"],
            )
    )
    
    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")

    return fig

def plot_power_vs_speed_with_alarms(
    data: pd.DataFrame,  
    size: int = 1,
    hover: bool = True,
    **kwargs) -> "go.Figure":
    """
    Plot power vs speed, separating alarm status (Yes or No) by color

    Args:
        data (pd.DataFrame): Dataframe with columns: 
            speed, power, validation_status
        size (int, optional): Size of the points. Defaults to 1
        hover (bool): Displays hover info. Defaults to True

    Returns:
        (go.Figure): Plotly figure
    """

    ## Filter data
    data = data[data.validation_status]

    ## Alarm status
    data['alarm_status'] = data['alarm'].apply(
        lambda x: 'Yes' if x != 'Running' else 'No')

    fig = go.Figure()

    if hover:
        hovertemplate = "Speed: %{x:.2f} <br>Power: %{y:.2f} <br>Alarm: %{text}<extra></extra>"
        hoverinfo = None
    else:
        hovertemplate = None
        hoverinfo = "skip"

    for status in ["No", "Yes"]:

        data_aux = data[data.alarm_status == status]

        fig.add_trace(
            go.Scatter(
                name=f"Alarm: {status}",
                x=data_aux["speed"],
                y=data_aux["power"],
                mode="markers",
                marker=dict(line_width=0, size=size),
                text=data_aux['alarm_status'],
                hovertemplate=hovertemplate,
                hoverinfo=hoverinfo,
            ))

    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")

    return fig

def plot_power_vs_speed_with_derating(
    data: pd.DataFrame,  
    size: int = 1,
    hover: bool = True,
    **kwargs) -> "go.Figure":
    """
    Plot power vs speed, separating alarm status (Yes or No) by color

    Args:
        data (pd.DataFrame): Dataframe with columns: 
            speed, power, validation_status
        size (int, optional): Size of the points. Defaults to 1
        hover (bool): Displays hover info. Defaults to True

    Returns:
        (go.Figure): Plotly figure
    """

    ## Filter data
    data = data[data.validation_status]

    ## Alarm status
    derating_status_series = data['derating_status'].apply(
        lambda x: 'Yes' if x else 'No')

    fig = go.Figure()

    if hover:
        hovertemplate = "Speed: %{x:.2f} <br>Power: %{y:.2f} <br>Alarm: %{text}<extra></extra>"
        hoverinfo = None
    else:
        hovertemplate = None
        hoverinfo = "skip"

    for status in ["No", "Yes"]:

        data_aux = data[derating_status_series == status]

        fig.add_trace(
            go.Scatter(
                name=f"Derating: {status}",
                x=data_aux["speed"],
                y=data_aux["power"],
                mode="markers",
                marker=dict(line_width=0, size=size),
                text=derating_status_series,
                hovertemplate=hovertemplate,
                hoverinfo=hoverinfo,
            ))

    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")

    return fig
