"""
wod/visualization/temp_power_curves.py

Module to plot temperature-specific power curves
"""

import numpy as np
import plotly.graph_objects as go

from wod.power_curve import PowerCurve
from wod.visualization import obtain_discrete_colors

def plot_temperature_power_curves_in_turbine(
        power_curves: list[PowerCurve],
        visible: bool = True) -> go.Figure:
    """
    Plot temperature power curves in turbines

    Args:
        power_curves (list[PowerCurve]): List of Power Curves to represent
        visible (bool, optional): Make the trace visible. Defaults to True.

    Returns:
        (go.Figure): Plotly figure
    """
    
    lst_power_curves = [pc for pc in power_curves if pc.metadata['type'] == 'temperature']

    ## Obtain colors
    color_list = obtain_discrete_colors(range(len(lst_power_curves)))

    ## Initialize figure
    fig = go.Figure()

    ## Loop to add traces
    for i, pc in enumerate(lst_power_curves):

        color = color_list[i]

        ## Legend Group
        if pc.metadata['min_temperature'] == -np.inf:
            legendgroup = f" < {pc.metadata['max_temperature']}º"
        elif pc.metadata['max_temperature'] == np.inf:
            legendgroup = f" > {pc.metadata['min_temperature']}º"
        else:
            legendgroup = f"{pc.metadata['min_temperature']}º - {pc.metadata['max_temperature']}º"

        ## Trace 1: Data Points
        df = pc.data_points[~pc.data_points['filter']]
        if len(df)>0:    
            fig.add_trace(
                go.Scatter(
                    name='Filtered data',
                    x=df["speed"],
                    y=df["power"],
                    legendgroup=legendgroup,
                    legendgrouptitle_text=legendgroup,
                    mode="markers",
                    marker=dict(
                        color=color,
                        size=2
                    ),
                    visible=visible,
                    hoverinfo='skip',
                    opacity=0.5
                )
            )

        ## Trace 2: Power Average
        fig.add_trace(
            go.Scatter(
                name='Power Curve',
                x=pc.data['bin'],
                y=pc.data['power'],
                legendgroup=legendgroup,
                legendgrouptitle_text=legendgroup,
                line=dict(color=color, shape="spline"),
                visible=visible
            )
        )

        ## Trace 3: Power lower threshold
        fig.add_trace(
            go.Scatter(
                name='Inferior Limit',
                x=pc.data['bin'],
                y=pc.data['power_min'],
                legendgroup=legendgroup,
                legendgrouptitle_text=legendgroup,
                line=dict(color=color, dash='dash'),
                visible=visible
            )
        )

    fig.update_layout(
        xaxis_title="Wind Speed (m/s)",
        yaxis_title="Power (kW)",
    )
    fig.update_layout(legend=dict(groupclick="toggleitem"))
    fig.update_layout(hovermode="x unified")

    return fig
