"""
wod/visualization/color.py

Module for color treatment in plots
"""

from plotly.express.colors import sample_colorscale

def obtain_discrete_colors(
        indexes: list[int], colorscale: str = 'Rainbow') -> list[str]:
    """
    Obtain a set of discrete colors from a continuous colorscale

    Args:
        indexes (list[int]): List of indexes
        colorscale (str, optional): Plotly colorscales (see 
            https://plotly.com/python/builtin-colorscales/). 
            Defaults to 'Rainbow'.

    Returns:
        (list[str]): List of HEX colors
    """
    
    # Min-Max Indexes to be in the range 0-1
    # NOTE: We could use the sklearn minmax scaler, but it seems silly to force
    # that dependency only for this. However, if in the future we need it for
    # other things, we could change it
    min_index = min(indexes)
    max_index = max(indexes)
    color_indexes = [(x - min_index)/(max_index - min_index) for x in indexes]

    # Return sample colors of the scale
    return sample_colorscale(colorscale, color_indexes)
