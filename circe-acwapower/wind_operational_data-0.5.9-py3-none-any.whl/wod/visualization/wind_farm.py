"""
wod/visualization/wind_farm.py

Module to organize wind farm level plots
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def plot_temperature_power_curves_in_farm(
        wf: WindFarm, plot_type: str
) -> go.Figure:
    """
    Plot temperature power curves for a WindFarm by merging the plots for 
    individual turbines with a dropdown menu

    Args:
        wf (WindFarm): WindFarm object to plot
        plot_type (str): Plot type to apply to the turbine plot method

    Returns:
        go.Figure: Plotly figure
    """

    # Initial traces (turbine 1)
    fig: go.Figure = list(wf.get_ok_turbines().values())[0].plot(
        plot_type=plot_type)
    visible_array = [True] * len(fig.data)
    traces_index_per_turbine = [(0, len(fig.data))]
    current_number_of_traces = len(fig.data)

    # Extend figure
    for turbine in list(wf.get_ok_turbines().values())[1:]:
        trace_counter = 0
        for trace in turbine.plot(plot_type=plot_type, visible=False).data:
            fig.add_trace(trace)
            visible_array.append(False)
            trace_counter += 1
        traces_index_per_turbine.append((current_number_of_traces, current_number_of_traces+trace_counter))
        current_number_of_traces += trace_counter

    # Visible arrays per turbine
    buttons = []
    for i, turbine in enumerate(list(wf.get_ok_turbines().values())):
        visible_array_aux = [False] * len(visible_array)
        for index in range(traces_index_per_turbine[i][0], traces_index_per_turbine[i][1]):
            visible_array_aux[index] = True

        buttons.append(
            dict(
                label=f"Turbine {turbine.name}",
                method='update',
                args=[{"visible": visible_array_aux}]
            )
        )

    for i, trace in enumerate(fig.data):
        trace["visible"] = visible_array[i]

    fig.update_layout(updatemenus=[dict(active=0, buttons=buttons)])
    fig.update_layout()
    fig.update_layout(
        title=f"{wf.name}",
    )

    return fig
