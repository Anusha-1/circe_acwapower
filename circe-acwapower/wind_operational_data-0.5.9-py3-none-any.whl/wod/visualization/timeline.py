"""
wod/visualization/timeline.py

Plot timelines
"""

from datetime import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from wod.alarms.filter import filter_by_date
from wod.alarms.stats import calculate_alarms_total_duration

def plot_timeline_alarms(
        df: pd.DataFrame, start: datetime = None, end: datetime = None, 
        threshold: float = 0.0 ) -> "go.Figure":
    """
    Plot alarms in Gantt plot

    Args:
        data (pd.DataFrame): Alarm dataframe. Columns are 'alarm', 'start_date'
            'end_date'
        start (datetime, optional): Start of the filtered period. 
            Defaults to None.
        end (datetime, optional): End of the filtered period. Defaults to None.
        threshold (float, optional):  All alerts whose accumulated duration is 
            less than this fraction of the total alarm duration are grouped into
            a category called 'Other'. Defaults to 0.0.

    Returns:
        (go.Figure): Plotly figure
    """

    # Filter dates
    df_aux = filter_by_date(df, start=start, end=end)

    # Group alarms
    df_group = calculate_alarms_total_duration(df_aux, start=start, end=end)

    # Cumulative percentage and threshold
    df_group['cum_perc'] = df_group.percentage.cumsum() / df_group.percentage.sum()
    df_group['under_threshold'] = df_group.cum_perc < (1.0 - threshold)
    df_group.loc[(~df_group['under_threshold']).idxmax(), 'under_threshold'] = True
    lst_alerts = list(df_group[df_group.under_threshold].index)

    # Apply category
    df_aux['category'] = df_aux.alarm.apply(lambda x: x if x in lst_alerts else 'Other')

    fig = px.timeline(df_aux, x_start="start_date", x_end="end_date", y="category")
    return fig
