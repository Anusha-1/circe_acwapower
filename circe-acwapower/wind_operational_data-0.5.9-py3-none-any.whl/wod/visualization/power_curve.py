"""
wod/visualization/power_curve.py

Module to plot power curves
"""

import pandas as pd
import plotly.graph_objects as go

def plot_power_curve(
        data: pd.DataFrame, 
        **kwargs) -> "go.Figure":
    """
    Plots a Power Curve

    Args:
        data (pd.DataFrame): Data with Power Curve
        **kwargs: Keyword arguments to add_power_curve_trace

    Returns:
        (go.Figure): Plotly figure
    """    
    
    fig = go.Figure()

    fig = add_power_curve_trace(fig, data, **kwargs)

    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")
    
    return fig

def add_power_curve_trace(
        fig: go.Figure, 
        data: pd.DataFrame,
        max_bin: float = None, 
        width: int = 1,
        legendgroup: str = 'Power Curves',
        color: str = 'black',
        **kwargs):
    """
    Adds Power Curve traces

    Args:
        fig (go.Figure): Plotly figure
        data (pd.DataFrame): Data with Power Curve
        max_bin (float, optional): Last bin to plot. Defaults to None.
        width (int, optional): Line width. Defaults to 1.
        legendgroup (str): Legend Group
        color (str): Color for the trace. Defaults to 'black'

    Returns:
        (go.Figure): Plotly with Power Curve traces
    """
    
    # Filter by max bin
    if max_bin:
        data = data[data.bin <= max_bin]

    fig.add_trace(
        go.Scatter(
            x=data['bin'],
            y=data['power'],
            name='Power',
            line=dict(
                color=color,
                width=width),
            legendgroup=legendgroup,
            legendgrouptitle_text=legendgroup,
        )
    )

    fig.add_trace(
        go.Scatter(
            x=data['bin'],
            y=data['power_min'],
            name='Min Power',
            line=dict(
                color=color,
                width=width,
                dash='dash'),
            legendgroup=legendgroup,
            legendgrouptitle_text=legendgroup,
        )
    )

    fig.update_layout(hovermode="x unified")

    return fig

def plot_power_derivatives(
        data: pd.DataFrame,
        max_bin: float = None,
        width: int = 1,
) -> go.Figure:
    
    fig = go.Figure()

    if max_bin:
        data = data[data.bin <= max_bin]

    fig.add_trace(
        go.Scatter(
            x=data['bin'],
            y=data['power'],
            name='Power',
            line=dict(
                width=width),
        )
    )

    if 'power_first_deriv' in data.columns:
        fig.add_trace(
            go.Scatter(
                x=data['bin'],
                y=data['power_first_deriv'],
                name='Power First Deriv',
                line=dict(
                    width=width),
            )
        )

    if 'power_second_deriv' in data.columns:
        fig.add_trace(
            go.Scatter(
                x=data['bin'],
                y=data['power_second_deriv'],
                name='Power Second Deriv',
                line=dict(
                    width=width),
            )
        )

    fig.update_layout(hovermode="x unified")
    fig.update_layout(xaxis_title="Wind Speed", yaxis_title="Power")

    return fig