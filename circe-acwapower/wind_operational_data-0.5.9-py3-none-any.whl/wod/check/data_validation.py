"""
wod/check/validation_status.py

Functions to validate data
"""

import pandas as pd

from .consecutive_duplicates import drop_consecutive_duplicates

def validate_data(
    df: pd.DataFrame,
    min_speed: float = None,
    max_speed: float = None,
    min_power: float = None,
    max_power: float = None,
    min_temperature: float = None,
    max_temperature: float = None,
    drop_consecutive_speed: bool = True
) -> pd.DataFrame:
    """
    Validates data. It creates a new column: validation_status, that is True for
    "correct" data, and False for "incorrect" data. This classification is done 
    based on value range (typically missing data will have rare values like 
    -9999.99).

    Args:
        df (pd.DataFrame): Original dataframe with columns datetime, speed, 
            power, temperature (optional). Even a previous validation_status 
            column could exist, the algorithm will respect the False, and check
            if the True still persists.
        min_speed (float, optional): Minimum speed to consider for valid data. 
            Defaults to None.
        max_speed (float, optional): Maximum speed to consider for valid data. 
            Defaults to None.
        min_power (float, optional): Minimum power to consider for valid data. 
            Defaults to None.
        max_power (float, optional): Maximum power to consider for valid data.
            Defaults to None.
        min_temperature (float, optional): Minimum temperature to consider for
            valid data. Defaults to None.
        max_temperature (float, optional): Maximum temperature to consider for 
            valid data. Defaults to None.
        drop_consecutive_spped (bool): If True, consecutive duplicates in speed
            are set as None. Defaults to True

    Returns:
        (pd.DataFrame): Dataframe with extra column
    """

    ## Initialize series of True
    df["validation_status"] = True

    ## Check conditions
    if min_speed:
        df.loc[df.speed < min_speed, "speed"] = None

    if max_speed:
        df.loc[df.speed > max_speed, "speed"] = None

    if min_power:
        df.loc[df.power < min_power, "power"] = None

    if max_power:
        df.loc[df.power > max_power, "power"] = None

    if min_temperature:
        df.loc[df.temperature < min_temperature, "temperature"] = None

    if max_temperature:
        df.loc[df.temperature > max_temperature, "temperature"] = None

    if drop_consecutive_speed:
        df = drop_consecutive_duplicates(df)
    
    df.loc[df.isna().any(axis=1), "validation_status"] = False

    return df
