"""
wod/check/consecutive_duplicates.py

Functions to manage consecutive duplicates
"""

import pandas as pd

def drop_consecutive_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """
    Drop consecutive duplicates of speed (at least 3 in a row)

    Args:
        df (pd.DataFrame): Original Dataframe with a 'speed' column

    Returns:
        (pd.DataFrame): Dataframe with remove speeds
    """


    lag2 = df.speed.shift(2) == df.speed
    consec_dupl = lag2 | lag2.shift(-1) | lag2.shift(-2)

    df.loc[consec_dupl, 'speed'] = None

    return df