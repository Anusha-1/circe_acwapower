"""
wod/alarms/load/dataframe.py

Module to load alarms from a treated dataframe
"""

import pandas as pd

from wod.alarms import Alarms

from wod.warnings import warn_missing_columns

def load_alarms_from_dataframe(
        df: pd.DataFrame,
        turbine_column: str = 'WTG',
        alarm_column: str = 'Alarm',
        start_date_column: str = 'Start Date',
        end_date_column: str = 'End Date',
        datetime_format: str = "mixed",
        alarms_to_drop: list[str] | None = None,
        transform_dates_to_datetime: bool = False,
        dayfirst: bool = True,
        turbine_transformation: str | None = None,
) -> dict[str, Alarms]:
    """
    Load alarms from dataframe

    Args:
        df (pd.DataFrame): Dataframe with alarms
        turbine_column (str, optional): Column with turbine names. 
            Defaults to 'WTG'.
        alarm_column (str, optional): Column with alarm category. 
            Defaults to 'Alarm'.
        start_date_column (str, optional): Column with start datetimes. 
            Defaults to 'Start date'.
        end_date_column (str, optional): Column with end datetimes. 
            Defaults to 'End date'.
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%d/%m/%Y %H:%M:%S".
        alarms_to_drop (list[str] | None, optional): List of alarms to drop. 
            If None, it does not drop any alarm. Defaults to None.
        transform_dates_to_datetime (bool, optional): Trasnform date columns to 
            datetime objects. Defaults to False.
        dayfirst (bool, optional): dayfirst argument of pandas to_datetime()
            function. Only relevant if transform_dates_to_datetime is True (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to True
        turbine_transformation (str, optional): How to transform turbine designation. 
            Options are:

            - 'str': Coerce to string
            - None: Do nothing
            
            Defaults to 'str'.

    Returns:
        (dict[str, Alarms]): Dictionary with:

            - keys: Turbine designation
            - values: Alarms object   
    """


    # Assert columns
    warn_missing_columns(
        [alarm_column, start_date_column, end_date_column, turbine_column],
        list(df.columns),
        as_error=True,
        df_name='alarms')
    
    # Rename columns
    df = df.rename(columns={
        alarm_column: "alarm",
        start_date_column: "start_date",
        end_date_column: "end_date"
    })

    # Drop alarms
    if alarms_to_drop is not None:
        for alarm in alarms_to_drop:
            df = df[df["alarm"] != alarm].copy()

    # Date to datetime
    if transform_dates_to_datetime:
        df.start_date = pd.to_datetime(
            df.start_date, format=datetime_format, dayfirst=dayfirst)
        df.end_date = pd.to_datetime(
            df.end_date, format=datetime_format, dayfirst=dayfirst)

    # Loop through turbines and build Alarms objects
    dict_alarms = {}
    turbine_list = list(set(df[turbine_column]))
    for turbine in turbine_list:
        df_aux = df[df[turbine_column] == turbine].copy()
        df_aux = df_aux.drop(columns=[turbine_column])

        if turbine_transformation == 'str':
            turbine_name = str(turbine)
        else:
            turbine_name = turbine

        dict_alarms[turbine_name] = Alarms(df_aux)

    return dict_alarms