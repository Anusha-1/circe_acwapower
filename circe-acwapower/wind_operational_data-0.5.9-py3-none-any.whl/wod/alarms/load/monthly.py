"""
wod/alarms/load/monthly.py

Module to load alarms from monthly data
"""

import os
import pathlib
from datetime import datetime

import pandas as pd

from wod.alarms import Alarms
from wod.alarms.load.dataframe import load_alarms_from_dataframe
from wod.load.path import select_month_folders


def load_alarms_from_monthly_data(
        folder_path: os.PathLike,
        start_date: datetime,
        end_date: datetime,
        turbine_column: str = 'WTG',
        alarm_column: str = 'Alarm',
        start_date_column: str = 'Start Date',
        end_date_column: str = 'End Date',
        datetime_format: str = "mixed",
        dayfirst: bool = True,
        turbine_transformation: str = 'str',
        file_prefix: str = 'Eventos_',        
        take_treated_alarms: bool = True) -> dict[str, Alarms]:
    """
    Loads alarms from monthly data

    Args:
        folder_path (os.PathLike): Path to folder
        start_date (datetime): Start datetime.
        end_date (datetime): End datetime.
        turbine_column (str, optional): Column with turbine names. 
            Defaults to 'WTG'.
        alarm_column (str, optional): Column with alarm category. 
            Defaults to 'Alarm'.
        start_date_column (str, optional): Column with start datetimes. 
            Defaults to 'Start date'.
        end_date_column (str, optional): Column with end datetimes. 
            Defaults to 'End date'.
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%d/%m/%Y %H:%M:%S".
        dayfirst (bool, optional): dayfirst argument of pandas to_datetime()
            function. (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to True
        turbine_transformation (str, optional): How to transform turbine designation. 
            Options are:

            - 'str': Coerce to string
            - None: Do nothing
            
            Defaults to 'str'.
        take_treated_alarms (bool, optional): Looks for the file with treated 
            events, inside the output folder. Defaults to True
    
    Returns:
        (dict[str, Alarms]): Dictionary with:

            - keys: Turbine designation
            - values: Alarms object    
    """

    lst_folder = select_month_folders(folder_path, start_date, end_date)
    
    # Loop through folders
    lst_dfs: list[pd.DataFrame] = []
    for month in lst_folder:
        month_folder_path = pathlib.Path(folder_path, month)

        ## Look for file with alarms
        ## If take_treated_alarms, we look for them inside 'output'
        if take_treated_alarms:
            for file in os.listdir(pathlib.Path(month_folder_path, "output")):
                if file.startswith(file_prefix) and file.endswith(".txt"):
                    data_file = pathlib.Path(month_folder_path, 'output', file)
                    break


        ## We assume it is a txt file that starts with file_prefix
        else:
            for file in os.listdir(month_folder_path):
                if file.startswith(file_prefix) and file.endswith(".txt"):
                    data_file = pathlib.Path(month_folder_path, file)
                    break

        ## Open dataframe
        ## Note that we expect a tab seperated value file (despite the extension
        ## being .txt)
        df = pd.read_csv(
            data_file, 
            sep="\t",  
            encoding = "ISO-8859-1", 
            skip_blank_lines = True)
        lst_dfs.append(df)

    # Concatenate all the monthly dataframes into a full dataframe
    df = pd.concat(lst_dfs)    
    
    return load_alarms_from_dataframe(
        df,
        turbine_column = turbine_column,
        alarm_column = alarm_column,
        start_date_column = start_date_column,
        end_date_column = end_date_column,
        datetime_format = datetime_format,
        alarms_to_drop = ["Potencia Anomala", "AlarmasNoRegistradas-B", "AlarmasNoRegistradas-A","DERATING_TEMPERATURE"],
        transform_dates_to_datetime = True,
        dayfirst = True,
        turbine_transformation = 'str'
    )
