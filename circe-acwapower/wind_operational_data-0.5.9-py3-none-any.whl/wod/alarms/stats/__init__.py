from .duration import calculate_alarms_total_duration

__all__ = [calculate_alarms_total_duration]