"""
wod/alarms/stats/duration.py

Stats related with alarms' duration
"""

from datetime import datetime
import pandas as pd
from ..filter import filter_by_date

def calculate_alarms_total_duration(
        data: pd.DataFrame,
        start: datetime = None,
        end: datetime = None,
    ) -> pd.DataFrame:
    """
    Calculate aggregated duration of the alarms in a given period

    Args:
        data (pd.DataFrame): Alarm dataframe. Columns are 'alarm', 'start_date'
            'end_date'
        start (datetime, optional): Start of considered period. Defaults to None.
        end (datetime, optional): End of considered period. Defaults to None.

    Returns:
        (pd.DataFrame): Dataframe with alarm duration info
    """

    # Filter dates
    data = filter_by_date(data, start=start, end=end)
    
    # Calculate duration, and sum by alarm groups
    data['duration'] = data.end_date - data.start_date
    data_group = data[['alarm','duration']].groupby(['alarm']).sum()
    data_group = data_group.sort_values(by='duration', ascending=False)

    # Get percentage over total duration
    if not start:
        start = data.start_date.min()
    if not end:
        end = data.end_date.max()
    
    total_duration = end - start
    data_group['percentage'] = data_group.duration / total_duration * 100

    return data_group

    