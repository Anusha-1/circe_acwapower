"""
wod/alarms/filter/date.py

Functions to filter alarms by date
"""

from datetime import datetime

import pandas as pd

def filter_by_date(data: pd.DataFrame, start: datetime = None,
        end: datetime = None) -> pd.DataFrame:
    """
    Filter an alarm dataframe between start and end dates

    Args:
        data (pd.DataFrame): Alarm dataframe. Columns are 'alarm', 'start_date'
            'end_date'
        start (datetime, optional): Start of the filtered period. 
            Defaults to None.
        end (datetime, optional): End of the filtered period. Defaults to None.

    Returns:
        (pd.DataFrame): Filtered dataframe
    """
    
    if start:
        data = data[(data.end_date >= start)]
    if end:
        data = data[(data.start_date <= end)]

    return data.copy()