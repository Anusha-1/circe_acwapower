"""
wod/alarms/alarms.py

Module with Alarms class
"""


from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd
import plotly.graph_objects as go

import wod.visualization as vis
import wod.alarms.stats as stats

if TYPE_CHECKING:
    from datetime import datetime

class Alarms:
    """
    class Alarms: Manage the data related to alarms

    Attributes:
        data (pd.DataFrame): DataFrame with alarms information
        start (datetime): Beginning of the alarms
        end (datetime): End of the alarms
    """

    def __init__(
            self, 
            data: pd.DataFrame, 
            start: datetime | None = None,
            end: datetime | None = None):
        """
        Initialization method

        Args:
            data (pd.DataFrame): Dataframe that incorporates the alarms to 
                consider, with the following columns:
                
                - alarm: Category of the alarm
                - start_date: Beginning of the alarm
                - end_data: End of the alarm
        """

        self.data = data

        self.start = start if start is not None else self.data["start_date"].min()
        self.end = end if end is not None else self.data["end_date"].max()

    def __str__(self):
        return f"Alarms(len={len(self.data)})"
    
    def __repr__(self):
        text = "Alarms \n"
        text += f" --> Number of alarms: {len(self.data)} \n"
        text += f" --> Period considered: {self.start} - {self.end} \n"

        return text

    def plot(self, **kwargs) -> "go.Figure":
        """Plots the alarms in a Gantt figure

        Returns:
            (go.Figure): Plotly figure
        """

        return vis.plot_timeline_alarms(self.data, **kwargs)
    
    def get_alarm_duration(self, **kwargs) -> pd.DataFrame:
        """
        Group by stats by alarms categories

        Returns:
            (pd.DataFrame): Duration of alarms by category
        """
        return stats.calculate_alarms_total_duration(self.data, **kwargs)

    @classmethod
    def from_no_data(cls, start_date: datetime, end_date: datetime) -> Alarms:
        """
        Creates an empty Alarms objects, for cases in which we don't have any
        alarm

        Args:
            start_date (datetime): Start date
            end_date (datetime): End date

        Returns:
            (Alarms): "Empty" alarms object
        """

        return cls(
            pd.DataFrame(columns=['alarm','start_date','end_date']),
            start = start_date,
            end = end_date)
