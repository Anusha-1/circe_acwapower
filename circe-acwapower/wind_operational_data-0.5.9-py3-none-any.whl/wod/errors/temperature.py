"""
wod/errors/temperature.py

Class for temperature errors
"""

class TemperatureException(Exception):
    """
    Exception to manage temperature missing error
    """

    def __init__(self, wind_farm: str):
        """Init method

        Args:
            wind_farm (str): Name of the wind farm
        """

        self.message = f"TEMPERATURE ERROR: Missing temperature at {wind_farm}"

    def __str__(self):
        return self.message
    