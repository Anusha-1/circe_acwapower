"""
wod/errors/data points.py

Class for data points errors
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from wod.warnings._format import format_power_curve_id

if TYPE_CHECKING:
    from wod.power_curve import PowerCurve  

class NumberDataPointsException(Exception):
    """
    Exception to manage temperature missing error
    """

    def __init__(self, pc: PowerCurve):
        """Init method

        Args:
            pc (PowerCurve)
        """

        self.message = f"LOW NUMBER OF DATA POINTS: {format_power_curve_id(pc)}"

    def __str__(self):
        return self.message