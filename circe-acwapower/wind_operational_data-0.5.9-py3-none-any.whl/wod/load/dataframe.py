"""
wod/load/dataframe.py

Loads data from dataframes
"""

from datetime import datetime

import pandas as pd

from .format import format_df_timeseries

def load_dataframe_aux(
        df: pd.DataFrame,
        start_date: datetime = None, 
        end_date: datetime = None,
        datetime_column: str = "timestamp",
        turbine_column: str = "wtg",
        speed_column: str = "WindSpeedms",
        power_column: str = "ActivePowerW",
        datetime_format: str = "%Y-%m-%d %H:%M:%S",
        format_datetime: bool = False
) -> pd.DataFrame:
    """
    Load dataframe with 10-min data and at least 4 columns: datetime, turbine,
    speed and power

    Args:
        df (pd.DataFrame): Dataframe of 10-min
        start_date (datetime, optional): Start datetime. Defaults to None
        end_date (datetime, optional): End datetime. Defaults to None
        datetime_column (str, optional): Name of the datetime column. 
            Defaults to "timestamp".
        turbine_column (str, optional): Name of the turbine column. 
            Defaults to "wtg".
        speed_column (str, optional): Name of the speed column. 
            Defaults to "WindSpeedms".
        power_column (str, optional): Name of the power column. 
            Defaults to "ActivePowerW".
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%Y-%m-%d %H:%M:%S".
        format_datetime (bool, optional): Whether to force the formatting of 
            datetime. Defaults to False.

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
        
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power
    """
    
    # Assert column names 
    assert datetime_column in df.columns, \
        f"Datetime column {datetime_column} not in data"
    assert turbine_column in df.columns, \
        f"Turbine column {turbine_column} not in data"
    assert speed_column in df.columns, \
        f"Speed column {speed_column} not in data"
    assert power_column in df.columns, \
        f"Power column {power_column} not in data"

    # Turbines
    lst_turbines = list(set(df[turbine_column]))
    lst_turbines.sort()

    # Dictionary for columns rename
    dict_col_rename = {
        datetime_column: "datetime",
        speed_column: "speed",
        power_column: "power",
    }

    # Prepare the dict
    dict_dfs: dict[str, pd.DataFrame] = {}
    for turbine in lst_turbines:

        df_aux: pd.DataFrame = df[df[turbine_column]==turbine][
            list(dict_col_rename.keys())
        ]

        df_aux = df_aux.rename(columns=dict_col_rename)

        if format_datetime:
            df_aux["datetime"] = pd.to_datetime(
                df_aux["datetime"], format=datetime_format)
 
        # Limit dates
        if start_date:
            df_aux = df_aux[df_aux.datetime >= start_date].copy()
        if end_date:
            df_aux = df_aux[df_aux.datetime <= end_date].copy()

        if format_datetime:
            df_aux = format_df_timeseries(df_aux)

        dict_dfs[turbine] = df_aux

    return dict_dfs
