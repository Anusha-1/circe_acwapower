"""
wod/load/filtered.py

Module to load already filtered data
"""

import os

import pandas as pd


def load_data_without_timestamps_aux(
        file_path: os.PathLike, 
        power_col_name: str = 'power_ave',
        speed_col_name: str = 'wind_ave',
        temp_col_name: str = 'temp_ave',
        sep: str | None = '\t',
        **kwargs
) -> dict[str, pd.DataFrame]:
    """
    Load data for a single file without timestamps containing already filtered
    data, to be used for power curves calculation

    Args:
        file_path (os.PathLike): Path to file
        power_col_name (str, optional): Name of power columns. 
            Defaults to 'power_ave'.
        speed_col_name (str, optional): Name of speed columns. 
            Defaults to 'wind_ave'.
        temp_col_name (str, optional): Name of temperature columns. 
            Defaults to 'temp_ave'.
        sep (str | None, optional): Character or regex pattern to treat as the 
            delimiter (see 
            https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_csv.html). 
            Defaults to '\t'.

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power columns
    """
    

    # Load data
    df = pd.read_csv(file_path, sep=sep, **kwargs)

    # Drop unnecesary columns (typically indexes)
    expected_preffixes = (power_col_name, speed_col_name, temp_col_name)
    cols_to_drop = [col for col in df.columns if not col.startswith(expected_preffixes)]
    df = df.drop(columns=cols_to_drop)

    # Assert number of columns
    assert len(df.columns) % 3 == 0, \
        "Incorrect number of columns"
    
    # Locate each column type
    power_cols = [col for col in df.columns if col.startswith(power_col_name)]
    speed_cols = [col for col in df.columns if col.startswith(speed_col_name)]
    temp_cols = [col for col in df.columns if col.startswith(temp_col_name)]

    # Extract the suffixes for each column type. These suffixes indicate the
    # turbine, and should coincide exactly in each type
    power_suffixes = [col.replace(power_col_name,'') for col in power_cols]
    speed_suffixes = [col.replace(speed_col_name,'') for col in speed_cols]
    temp_suffixes = [col.replace(temp_col_name,'') for col in temp_cols]

    assert power_suffixes == speed_suffixes, \
        "Incoherent columns. We need power, speed and temp for each turbine"
    assert power_suffixes == temp_suffixes, \
        "Incoherent columns. We need power, speed and temp for each turbine"
    
    # After checking, we can use whatever suffixes list.
    suffixes = power_suffixes

    # For each turbine (i.e., each unique suffix), we isolate its power, speed
    # and temperature in a unique dataframe
    dict_dfs = {}
    for i, suf in enumerate(suffixes):

        turbine_name = str(i+1) # By default we id the turbines starting from 1

        # Build columns names
        power_col = power_col_name + suf
        speed_col = speed_col_name + suf
        temp_col = temp_col_name + suf

        # Isolate dataframe
        df_aux = df[[power_col, speed_col, temp_col]].copy()
        df_aux = df_aux.rename(
            columns={
                power_col: 'power',
                speed_col: 'speed',
                temp_col: 'temperature'
            })        
        df_aux = df_aux.dropna()

        dict_dfs[turbine_name] = df_aux

    return dict_dfs
