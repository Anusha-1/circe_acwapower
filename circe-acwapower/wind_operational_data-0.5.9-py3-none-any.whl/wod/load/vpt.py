"""
wod/load/vpt.py

Module with functions to load VPT monthly data
"""

import os
import pathlib
from datetime import datetime

import pandas as pd

from wod.load.path import select_month_folders
from wod.warnings import warn_missing_file

from .format import format_df_timeseries


def load_vpt_month_data_aux(
        folder_path: os.PathLike,
        start_date: datetime,
        end_date: datetime,
        datetime_format: str = "%d/%m/%Y %H:%M"
) -> dict[str, pd.DataFrame]:
    """
    Loads data from VPT files and distribute it into different turbines.

    Args:
        folder_path (os.PathLike): Path of the folder containing the data.
        start_date (datetime): Start datetime.
        end_date (datetime): End datetime.
        datetime_format (str, optional): Format for the datetime column. 
            Defaults to "%d/%m/%Y %H:%M".

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power columns
    """
    

    lst_folder = select_month_folders(folder_path, start_date, end_date)

    # Loop through folders
    lst_dfs: list[pd.DataFrame] = []
    for month in lst_folder:
        month_folder_path = pathlib.Path(folder_path, month)
        data_file = None
        ## Look for file with speed, power and temperature data
        ## We assume is a txt file that contains -VPT-
        ## NOTE: This rule could be more robust
        for file in os.listdir(month_folder_path):

            if "-VPT-" in file and file.endswith(".txt"):
                data_file = pathlib.Path(month_folder_path, file)
                break

        if data_file is None:
            warn_missing_file(
                f"VPT File (Month {month})",
                as_error=True
            )

        ## Open dataframe
        ## Note that we expect a tab seperated value file (despite the extension
        ## being .txt)
        df = pd.read_csv(data_file, sep="\t", header=None)
        lst_dfs.append(df)

    # Concatenate all the monthly dataframes into a full dataframe
    df = pd.concat(lst_dfs)

    return separate_vpt_dataframe_into_columns(
        df, start_date, end_date, datetime_format
    )


def load_vpt_file_aux(
        file_path: os.PathLike,
        start_date: datetime,
        end_date: datetime,
        datetime_format: str = "%d/%m/%Y %H:%M",
        use_temp: bool = True
)  -> dict[str, pd.DataFrame]:
    """
    Load a unique VPT file.

    Args:
        file_path (os.PathLike): Path of the file containing the data.
        start_date (datetime): Start datetime.
        end_date (datetime): End datetime.
        datetime_format (str, optional): Format for the datetime column. 
            Defaults to "%d/%m/%Y %H:%M".

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power columns
    """
    

    ## Open dataframe
    df = pd.read_csv(file_path, sep="\t", header=None)

    return separate_vpt_dataframe_into_columns(
        df, start_date, end_date, datetime_format, use_temp
    )


def separate_vpt_dataframe_into_columns(
        df: pd.DataFrame,
        start_date: datetime,
        end_date: datetime,
        datetime_format: str,
        use_temp: bool = True        
) -> dict[str, pd.DataFrame]:
    """
    Separate a VPT dataframe into different turbines

    Args:
        df (pd.DataFrame): Dataframe with an initial column of datetime, and 
            consecutive speed, power and temperature columns.
        start_date (datetime): Start datetime.
        end_date (datetime): End datetime.
        datetime_format (str, optional): Format for the datetime column. 
            Defaults to "%d/%m/%Y %H:%M".
        use_temp (bool, optional): If True we keep the temperatures, if False
            we delete it. Defaults to True

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power columns
    """

    # First column is assumed to be the datetime series
    datetime_series = df[0]
    datetime_series = pd.to_datetime(datetime_series, format=datetime_format)

    # The remaining columns are assumed to be speed, power and temperature for
    # each turbine
    # Let's rename the columns
    assert (len(df.columns) - 1) % 3 == 0, "Incorrect number of columns"
    num_turbines = (len(df.columns) - 1) // 3
    lst_turbines = [str(x) for x in range(1,num_turbines+1)]

    lst_new_cols = []
    for turbine in lst_turbines:
        lst_new_cols.append(f"speed_{turbine}")
        lst_new_cols.append(f"power_{turbine}")
        lst_new_cols.append(f"temperature_{turbine}")
    
    lst_new_cols = ['datetime'] + lst_new_cols
    df.columns = lst_new_cols

    ## In a loop, we extract the data for each turbine separatedly, and 
    ## incorporate into a dictionary:
    ##  - key: Turbine designation
    ##  - value: Dataframe with columns: datetime, speed, power, temperature
    dict_dfs = {}
    for turbine in lst_turbines:
        df_aux = pd.concat(
            [
                datetime_series,
                df[f"speed_{turbine}"],
                df[f"power_{turbine}"],
                df[f"temperature_{turbine}"]
            ],
            axis = 1,
        )
        df_aux.columns = ['datetime', 'speed', 'power', 'temperature']

        if not use_temp:
            df_aux = df_aux.drop(columns='temperature')

        # Limit dates
        if start_date:
            df_aux = df_aux[df_aux.datetime >= start_date].copy()
        if end_date:
            df_aux = df_aux[df_aux.datetime <= end_date].copy()

        df_aux = format_df_timeseries(df_aux)

        dict_dfs[turbine] = df_aux

    return dict_dfs
