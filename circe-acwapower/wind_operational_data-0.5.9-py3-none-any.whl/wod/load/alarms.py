"""
wod/load/alarms.py

Module to merge alarms data with 10-min timeseries
"""

from datetime import timedelta

import pandas as pd

def merge_alarms(data: pd.DataFrame, data_alarms: pd.DataFrame) -> pd.DataFrame:
    """
    Introduce alarm status in 10-min data

    Args:
        data (pd.DataFrame):Dataframe with 10-min timeseries data
        data_alarms (pd.DataFrame): Dataframe with alarm, start_date and end_date

    Returns:
        (pd.DataFrame): Dataframe with 10-min timeseries data + alarm status
    """
        
    # Set-up an alarm column
    data['alarm'] = 'Running'

    # For each alarm, change the corresponding 10-min
    for i, row in data_alarms.iterrows():

        # Round start to next 10-min
        start = row.start_date
        start = start - timedelta(
            minutes=start.minute % 10, seconds=start.second)
        start = start + timedelta(minutes=10)

        # Round end to next 10-min
        end = row.end_date
        delta = timedelta(minutes=start.minute % 10, seconds=start.second)
        end = end - delta

        ## If the end of the alarm coincides exactly at a 10 min boundary,
        ## we don't want to include the next timetamp
        ## We consider that the timestamps mark the end of the period, i.e.
        ## the value at 0:10 is the average between 0:00 and 0:10
        if delta.seconds > 0: 
            end = end + timedelta(minutes=10)

        # Modify alarm for datetimes between start and end
        condition = (data.datetime >= start) & (data.datetime <= end)
        data.loc[condition, "alarm"] = row.alarm

    return data
