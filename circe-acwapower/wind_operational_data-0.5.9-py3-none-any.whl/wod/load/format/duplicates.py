"""
wod/load/format/duplicates.py

Functions to deal with duplicates
"""

import pandas as pd

def rename_duplicates_datetime(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """
    Rename duplicates in a columns

    Args:
        df (pd.DataFrame): Dataframe
        column (str): Column to rename

    Returns:
        (pd.Dataframe): Dataframe with renamed duplicates
    """

    df = df.copy()

    # Obtain duplicated indexes
    duplicated = df.duplicated(subset=[column], keep='first')
    df_aux = df[duplicated].copy()

    lst_index = []
    for i, row in df_aux.iterrows():
        datetime_index = row[column]
        datetime_index = datetime_index[:-5] + 'Z' + datetime_index[-5:]
        lst_index.append(datetime_index)
 
    df.loc[duplicated, column] = lst_index

    return df
