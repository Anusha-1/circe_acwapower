"""
wod/load/format/format.py

Module to format dataframes
"""

import pandas as pd

from .duplicates import rename_duplicates_datetime

def format_df_timeseries(
        df: pd.DataFrame, datetime_column: str = 'datetime') -> pd.DataFrame:
    """
    Format dataframe timeseries

    Args:
        df (pd.DataFrame): Dataframe with timeseries. It needs to have a column
            of datetimes
        datetime_column (str): Name of the datetime column

    Returns:
        (pd.DataFrame): Formatted dataframe
    """

    datetime_format: str = "%Y/%m/%d %H:%M:%S"

    ## Create an index
    df["datetime_index"] = df[datetime_column].dt.strftime(datetime_format)
    df = rename_duplicates_datetime(df, column="datetime_index")

    ## Sort
    df = df.sort_values(by='datetime_index', ascending=True)

    ## Set index
    df = df.set_index("datetime_index")

    return df
