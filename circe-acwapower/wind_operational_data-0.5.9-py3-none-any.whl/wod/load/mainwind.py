"""
wod/load/mainwind.py

Module to load mainwind outputs
"""

import os
import pathlib
from datetime import datetime

import pandas as pd

from wod.load.path import select_month_folders

from wod.load.format import format_df_timeseries


def load_mainwind_from_monthly_folders(
        folder_path: os.PathLike,
        start_date: datetime,
        end_date: datetime,
        **kwargs) -> dict[str, pd.DataFrame]:
    """
    Load data from MainWind

    Args:
        folder_path (os.PathLike): Parent folder with monthly subfolders,
            containing the MainWind output data
        start_date (datetime): Start datetime.
        end_date (datetime): End datetime.
        ** kwargs: Keyword argument for transform_mainwind_output

    Returns:
        dict[str, pd.DataFrame]: Dictionary with:
            
            - key: Turbine
            - value: Dataframe of mainwind output for that turbine
    """

    lst_folder = select_month_folders(folder_path, start_date, end_date)

    # Loop through folders
    lst_dfs: list[pd.DataFrame] = []
    for month in lst_folder:
        month_folder_path = pathlib.Path(folder_path, month, "output")
        ## Look for file with power vs speed data
        ## We assume is a txt file that contains VP_Perd_10min
        for file in os.listdir(month_folder_path):
            if "VP_Perd_10min" in file and file.endswith(".txt"):
                data_file = pathlib.Path(month_folder_path, file)
                break

        ## Open dataframe
        ## Note that we expect a tab seperated value file (despite the extension
        ## being .txt)
        df = pd.read_csv(data_file, sep="\t")
        lst_dfs.append(df)

    # Concatenate all the monthly dataframes into a full dataframe
    df = pd.concat(lst_dfs)

    return transform_mainwind_output(df, **kwargs)

def load_mainwind_from_file(        
        file_path,
        **kwargs) -> dict[str, pd.DataFrame]:
    """
    Load data from mainwind from a file

    Args:
        file_path (str): Path to file.
        ** kwargs: Keyword argument for transform_mainwind_output

    Returns:
        dict[str, pd.DataFrame]: Dictionary with:
            
            - key: Turbine
            - value: Dataframe of mainwind output for that turbine
    """
    
    df = pd.read_csv(file_path,sep='\t')

    return transform_mainwind_output(df, **kwargs)

def transform_mainwind_output(
        df: pd.DataFrame,
        turbine_transformation: str = 'str') -> dict[str, pd.DataFrame]:
    """
    Transform mainwind output

    Args:
        df (pd.DataFrame): Dataframe with mainwind output
        turbine_transformation (str, optional): Label to indicates how to
            transform turbine names. Options are:

            - 'str': Coerce to string 
            
            Defaults to 'str'..

    Returns:
        dict[str, pd.DataFrame]: Dictionary with:
            
            - key: Turbine
            - value: Dataframe of mainwind output for that turbine
    """

    # Transform datetime
    df['timestamp'] = pd.to_datetime(df.timestamp, format="%d/%m/%Y %H:%M:%S")

    # Loop through turbines
    dict_outputs = {}
    turbine_list = list(set(df['wtg']))
    for turbine in turbine_list:
        df_aux = df[df['wtg'] == turbine].copy()
        df_aux = df_aux.drop(columns=['wtg'])

        if turbine_transformation == 'str':
            turbine_name = str(turbine)

        df_aux = format_df_timeseries(df_aux, datetime_column='timestamp')

        dict_outputs[turbine_name] = df_aux

    return dict_outputs
