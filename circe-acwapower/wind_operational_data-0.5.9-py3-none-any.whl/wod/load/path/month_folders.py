"""
src/wod/load/path/month_folders.py

Select month folders to look for
"""

import os
from datetime import datetime, timedelta

from dateutil.rrule import MONTHLY, rrule

from wod.warnings import warn_missing_months

def select_month_folders(
        folder_path: os.PathLike,
        start_date: datetime,
        end_date: datetime) -> list[str]:
    """
    Searchs for all month folders between two dates.
    It looks for folders with format %Y%m (e.g. 202309), and if it can't find 
    all, it tries to add folders with format %Y%#m (e.g. 20239)

    Args:
        folder_path (os.PathLike): Folder where to look for month folders
        start_date (datetime): Starting date
        end_date (datetime): Ending date

    Raises:
        Exception: It can't find all expected month folders

    Returns:
        (list[str]): List of month folders
    """

    # Extract months folder to look for
    dates = [dt for dt in rrule(
        MONTHLY, dtstart=start_date, until=end_date-timedelta(days=1))]
    dates_folder = [dt.strftime("%Y%m") for dt in dates] 

    # Extract list of folders at folder path, and retain the intersection
    lst_folder = os.listdir(folder_path)
    lst_folder = list(set(dates_folder) & set(lst_folder))

    # Legacy: If len(dates_folder) < len(lst_folder), try to look for months
    # folder without leading zero
    if len(dates_folder) > len(lst_folder):
        warn_missing_months(dates_folder)

        dates_folder = [dt.strftime("%Y%#m") for dt in dates] 
        lst_folder = os.listdir(folder_path)
        lst_folder = list(set(dates_folder) & set(lst_folder))

    if len(dates_folder) == len(lst_folder):
        return lst_folder
    
    raise Exception("Coudn't find all months folders")
