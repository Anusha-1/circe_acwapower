"""
wod/load/complete_excel.py

Loads data from an Excel file containing all the information
"""

import os
from datetime import datetime
from typing import Union

import pandas as pd

from .format import format_df_timeseries

def load_from_two_sheets_excel_aux(
        file_path:os.PathLike, 
        start_date: datetime = None, 
        end_date: datetime = None,
        main_sheet_name: Union[str,int] = 0,
        temp_sheet_name: Union[str,int] = 1,
        datetime_column: str = "Datetime",
        speed_prefix: str = "W",
        power_prefix: str = "P",
        temp_prefix: str = "T",
        speed_suffix: str = "",
        power_suffix: str = "",
        temp_suffix: str = " (°C)",
        datetime_format: str = "%d/%m/%Y %H:%M:%S") -> pd.DataFrame:
    """
    Load data from Excel with two sheets: power/speed and temperature

    Args:
        file_path (os.PathLike): Path to Excel file
        start_date (datetime): Start datetime. Defaults to None
        end_date (datetime): End datetime. Defaults to None
        main_sheet_name (Union[str,int], optional): Name or position of sheet
            with speed/power data. Defaults to 0.
        temp_sheet_name (Union[str,int], optional): Name or position of sheet
            with temperature data. Defaults to 1.
        datetime_column (str, optional): Name of datetime column. 
            Defaults to "Datetime".
        speed_prefix (str, optional): Prefix of speed columns. Defaults to "W".
        power_prefix (str, optional): Prefix of power columns. Defaults to "P".
        temp_prefix (str, optional): Prefix of temperature columns. Defaults to "T".
        speed_suffix (str, optional): Suffix of speed columns. Defaults to "".
        power_suffix (str, optional): Suffix of power columns. Defaults to "".
        temp_suffix (str, optional): Suffix of temperature columns. Defaults to " (°C)".
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%d/%m/%Y %H:%M:%S".

    Returns:
        (pd.DataFrame): Dataframe with final data
    """
    
    # Read main sheet (power and speed)
    df = pd.read_excel(file_path, sheet_name=main_sheet_name)

    # Read temperature sheet
    df_temp = pd.read_excel(file_path, sheet_name=temp_sheet_name)

    # Separate data in turbines
    ## First, separate the datetime column
    datetime_series = df[datetime_column]
    datetime_series = pd.to_datetime(datetime_series, format=datetime_format)

    ## Look for all Speed, Power, Temperature columns
    speed_cols = [col for col in df.columns if col.startswith(speed_prefix) and col.endswith(speed_suffix)]
    power_cols = [col for col in df.columns if col.startswith(power_prefix) and col.endswith(power_suffix)]
    temp_cols = [col for col in df_temp.columns if col.startswith(temp_prefix) and col.endswith(temp_suffix)]   
    assert len(speed_cols) == len(power_cols), "Mismatch number of power and speed columns"
    assert len(speed_cols) == len(temp_cols), "Mismatch number of temperature columns"

    ## Extract the suffixes of these columns
    if len(speed_suffix) > 0:
        speed_turbine_names = [x[len(speed_prefix):-len(speed_suffix)] for x in speed_cols]
    else:
        speed_turbine_names = [x[len(speed_prefix):] for x in speed_cols]
    if len(power_suffix) > 0:
        power_turbine_names = [x[len(power_prefix):-len(power_suffix)] for x in power_cols]
    else:
        power_turbine_names = [x[len(power_prefix):] for x in power_cols]
    if len(temp_suffix) > 0:
        temp_turbine_names = [x[len(temp_prefix):-len(temp_suffix)] for x in temp_cols]
    else:
        temp_turbine_names = [x[len(temp_prefix):] for x in temp_cols]
    assert set(speed_turbine_names) == set(power_turbine_names),\
        "Mismatch on turbine designations in speed and power columns"
    assert set(speed_turbine_names) == set(temp_turbine_names), \
        "Mismatch on turbine designations in temperature columns"

    ## If the suffixes coincide, we can take one of them as the turbine 
    ## designations
    lst_turbines = speed_turbine_names

    ## In a loop, we extract the data for each turbine separatedly, and 
    ## incorporate into a dictionary:
    ##  - key: Turbine designation
    ##  - value: Dataframe with columns: datetime, speed, power, temperature
    dict_dfs = {}
    for turbine in lst_turbines:
        df_aux = pd.concat(
            [
                datetime_series,
                df[f"{speed_prefix}{turbine}{speed_suffix}"],
                df[f"{power_prefix}{turbine}{power_suffix}"],
                df_temp[f"{temp_prefix}{turbine}{temp_suffix}"]
            ],
            axis = 1,
        )
        df_aux = df_aux.rename(
            columns={
                datetime_column: "datetime",
                f"{speed_prefix}{turbine}{speed_suffix}": "speed",
                f"{power_prefix}{turbine}{power_suffix}": "power",
                f"{temp_prefix}{turbine}{temp_suffix}": "temperature"
            }
        )       

        # Limit dates
        if start_date:
            df_aux = df_aux[df_aux.datetime >= start_date].copy()
        if end_date:
            df_aux = df_aux[df_aux.datetime <= end_date].copy()

        df_aux = format_df_timeseries(df_aux)

        dict_dfs[turbine] = df_aux

    return dict_dfs
