"""
wod/load/turbine_column.py

Module to load data with a turbine column
"""

from datetime import datetime
import os

import pandas as pd

from .format import format_df_timeseries
from wod.warnings import warn_missing_temperature

def load_from_file_with_turbine_column_aux(
        file_path: os.PathLike,
        start_date: datetime = None, 
        end_date: datetime = None,
        datetime_column: str = "timestamp",
        turbine_column: str = "wtg",
        speed_column: str = "WindSpeedms",
        power_column: str = "ActivePowerW",
        temperature_column: str = "EnvTmp",
        datetime_format: str = "%Y-%m-%d %H:%M:%S",
        **kwargs
) -> dict[str, pd.DataFrame]:
    """
    Loads data from a csv file with 5 columns: datetime, turbine, speed, power
    and temperature 

    Args:
        file_path (os.PathLike): File to load
        start_date (datetime, optional): Start datetime. Defaults to None
        end_date (datetime, optional): End datetime. Defaults to None
        datetime_column (str, optional): Name of the datetime column. 
            Defaults to "timestamp".
        turbine_column (str, optional): Name of the turbine column. 
            Defaults to "wtg".
        speed_column (str, optional): Name of the speed column. 
            Defaults to "WindSpeedms".
        power_column (str, optional): Name of the power column. 
            Defaults to "ActivePowerW".
        temperature_column (str, optional): Name of the temperature column. 
            Defaults to "EnvTemp".
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%Y-%m-%d %H:%M:%S".
        **kwargs: Keyword arguments for pandas read_csv 
            https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_csv.html

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
        
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power, temperature
    """
    
    # Load data
    df: pd.DataFrame = pd.read_csv(file_path, **kwargs)

    # Assert column names 
    assert datetime_column in df.columns, \
        f"Datetime column {datetime_column} not in data"
    assert turbine_column in df.columns, \
        f"Turbine column {turbine_column} not in data"
    assert speed_column in df.columns, \
        f"Speed column {speed_column} not in data"
    assert power_column in df.columns, \
        f"Power column {power_column} not in data"

    # Turbines
    lst_turbines = list(set(df[turbine_column]))
    lst_turbines.sort()

    # Dictionary for columns rename
    dict_col_rename = {
        datetime_column: "datetime",
        speed_column: "speed",
        power_column: "power",
    }
    if temperature_column in df.columns:

        ## Check temperature has actual data
        if all(df[temperature_column].isna()):
            warn_missing_temperature()
            df = df.drop(columns = temperature_column)
        else:
            dict_col_rename[temperature_column] = "temperature"

    else:
        warn_missing_temperature()

    # Prepare the dict
    dict_dfs: dict[str, pd.DataFrame] = {}
    for turbine in lst_turbines:

        df_aux: pd.DataFrame = df[df[turbine_column]==turbine][
            list(dict_col_rename.keys())
        ]

        df_aux = df_aux.rename(columns=dict_col_rename)

        df_aux["datetime"] = pd.to_datetime(
            df_aux["datetime"], format=datetime_format)
 
        # Limit dates
        if start_date:
            df_aux = df_aux[df_aux.datetime >= start_date].copy()
        if end_date:
            df_aux = df_aux[df_aux.datetime <= end_date].copy()

        df_aux = format_df_timeseries(df_aux)

        dict_dfs[str(turbine)] = df_aux

    return dict_dfs
