"""
wod/load/monthly.py

Module with functions to load monthly data
"""

from datetime import datetime
import os
import pathlib
import re

import pandas as pd

from wod.load.path import select_month_folders

from .format import format_df_timeseries

def load_from_monthly_data_aux(
        folder_path: os.PathLike,
        start_date: datetime = None, 
        end_date: datetime = None,
        datetime_column: str = "Datetime",
        speed_prefix: str = "W",
        power_prefix: str = "P",
        datetime_format: str = "%d/%m/%Y %H:%M:%S",
    ) -> dict[str, pd.DataFrame]:
    """
    Loads basic (datetime, speed and power) data for a wind farm

    Args:
        folder_path (os.PathLike): Path of the folder containing the data
        start_date (datetime, optional): Start datetime. Defaults to None
        end_date (datetime, optional): End datetime. Defaults to None
        datetime_column (str, optional): Name of the Datetime columns. 
            Defaults to "Datetime".
        speed_prefix (str, optional): Name of the prefix for wind speed columns.
            Defaults to "W".
        power_prefix (str, optional): name of the prefix for power column. 
            Defaults to "P".
        datetime_format (str, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%d/%m/%Y %H:%M:%S".

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
        
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, speed, power columns
    """


    # Looks for month folders
    if start_date is not None and end_date is not None:
        lst_months = select_month_folders(folder_path, start_date, end_date)
    else:
        # It assumes that the month folders have the format YYYYM (e.g. 20239)
        lst_folder = os.listdir(folder_path)
        pattern = "20[0-9]{3,4}"
        lst_months = [folder for folder in lst_folder if re.match(pattern, folder)]

    # Loop through folders
    lst_dfs: list[pd.DataFrame] = []
    for month in lst_months:
        month_folder_path = pathlib.Path(folder_path, month)
        ## Look for file with power vs speed data
        ## We assume is a txt file that starts with the month
        for file in os.listdir(month_folder_path):
            if file.startswith(month) and file.endswith(".txt"):
                data_file = pathlib.Path(month_folder_path, file)
                break

        ## Open dataframe
        ## Note that we expect a tab seperated value file (despite the extension
        ## being .txt)
        df = pd.read_csv(data_file, sep="\t")
        lst_dfs.append(df)

    # Concatenate all the monthly dataframes into a full dataframe
    df = pd.concat(lst_dfs)

    # Separate data in turbines
    ## First, separate the datetime column
    datetime_series = df[datetime_column]
    datetime_series = pd.to_datetime(datetime_series, format=datetime_format)

    ## Look for all Speed and Power columns
    speed_cols = [col for col in df.columns if col.startswith(speed_prefix)]
    power_cols = [col for col in df.columns if col.startswith(power_prefix)]
    assert len(speed_cols) == len(power_cols), "Mismatch number of power and speed columns"

    ## Extract the suffixes of these columns
    speed_suffixes = [x[len(speed_prefix) :] for x in speed_cols]
    power_suffixes = [x[len(power_prefix) :] for x in power_cols]
    assert set(speed_suffixes) == set(power_suffixes), "Mismatch on turbine designations in speed and power columns"

    ## If the suffixes coincide, we can take one of them as the turbine 
    ## designations
    lst_turbines = speed_suffixes

    ## In a loop, we extract the data for each turbine separatedly, and 
    ## incorporate into a dictionary:
    ##  - key: Turbine designation
    ##  - value: Dataframe with columns: datetime, speed, power
    dict_dfs = {}
    for turbine in lst_turbines:
        df_aux = pd.concat(
            [
                datetime_series,
                df[f"{speed_prefix}{turbine}"],
                df[f"{power_prefix}{turbine}"],
            ],
            axis = 1,
        )
        df_aux = df_aux.rename(
            columns={
                datetime_column: "datetime",
                f"{speed_prefix}{turbine}": "speed",
                f"{power_prefix}{turbine}": "power",
            }
        )

        # Limit dates
        if start_date:
            df_aux = df_aux[df_aux.datetime >= start_date].copy()
        if end_date:
            df_aux = df_aux[df_aux.datetime <= end_date].copy()

        df_aux = format_df_timeseries(df_aux)

        dict_dfs[turbine] = df_aux

    return dict_dfs
