"""
load/temperatures.py

Module to load temperatures from external files
"""

import os
import pathlib

import pandas as pd

from .format import format_df_timeseries

def load_temperature_data(
        folder_path: os.PathLike, datetime_column: str = "FECHA y HORA",
        datetime_format: str = "%d/%m/%Y %H:%M:%S", 
        temp_prefix: str = "Tª WTG ", temp_suffix: str = " (°C)",
        turbine_design_transformation: str = "str_int"
) -> dict[str, pd.DataFrame]:
    """
    Load temperature timeseries data from external Excel files (i.e. independent
    of speed and power)

    Args:
        folder_path (os.PathLike): Pâth to folder that contains the Excel files
        datetime_column (str, optional): Name of the datetime column. 
            Defaults to "FECHA y HORA".
        datetime_format (_type_, optional): Format of datetime column as accepted
            by pandas to_datetime() function (See 
            https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html). 
            Defaults to "%d/%m/%Y %H:%M:%S".
        temp_prefix (str, optional): Expected prefix of temperature columns. 
            Defaults to "Tª WTG ".
        temp_suffix (str, optional): Expected suffix of temperature columns.
            Defaults to " (°C)".
        turbine_design_transformation (str, optional): Posible transformation to 
            apply to turbine designation. We might need this in order to align
            it with speed and power data. 
            Options are:

            - "str_int": Coerce to int and then to str. Thus "001" becomes "1"
                   
            Defaults to "str_int".

    Returns:
        (dict[str, pd.DataFrame]): Dictionary with:
            - keys: Turbine designation
            - values: Pandas dataframes with datetime, temperature columns
    """


    # Extract all excel files (with extension xlsx)
    lst_files = os.listdir(folder_path)
    lst_excel_files = [file for file in lst_files if file.endswith(".xlsx")]

    # Load data from each excel and concatenate into one dataframe
    lst_dfs: list[pd.DataFrame] = []
    for file in lst_excel_files:
        lst_dfs.append(
            pd.read_excel(pathlib.Path(folder_path, file))
        )  # Read first sheet
    df = pd.concat(lst_dfs)

    # Separate data in turbines
    ## First, separate the datetime column
    datetime_series = df[datetime_column]
    datetime_series = pd.to_datetime(datetime_series, format=datetime_format)

    ## Look for all temperature columns
    temp_cols = [col for col in df.columns if col.startswith(temp_prefix) and col.endswith(temp_suffix)]

    ## Extract turbine designation
    lst_turbines = [x[len(temp_prefix):-len(temp_suffix)] for x in temp_cols]
    if turbine_design_transformation == "str_int":
        lst_turbines = [str(int(turbine)) for turbine in lst_turbines]
    
    ## In a loop, we extract the data for each turbine separatedly, and 
    ## incorporate into a dictionary:
    ##  - key: Turbine designation
    ##  - value: Dataframe with columns: datetime, temperature
    dict_dfs = {}
    for turbine, col in zip(lst_turbines, temp_cols):
        df_aux = pd.concat(
            [
                datetime_series,
                df[col]
            ], axis = 1
        )
        df_aux = df_aux.rename(
            columns={
                datetime_column: "datetime",
                col: "temperature"
            }
        )

        df_aux = format_df_timeseries(df_aux)

        dict_dfs[turbine] = df_aux

    return dict_dfs
