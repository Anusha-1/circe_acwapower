"""
src/wod/wind_farm/_add_extra.py

Method functions to add new data beyond wind speed/power 10 min
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from wod.alarms import Alarms
import wod.load as load
from wod.power_curve import PowerCurve

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm   


def add_temperature_data(
    self: WindFarm, folder_path: os.PathLike, data_validation: dict
):
    """
    Adds temperature data from an external file

    Args:
        folder_path (os.PathLike): Folder with external temperature data
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            method add_temperature_data
    """
    dict_temp = load.load_temperature_data(folder_path)

    for turbine_name, turbine_obj in self.get_ok_turbines().items():
        turbine_obj.add_temperature_data(dict_temp[turbine_name], **data_validation)

def add_power_curves(
    self: WindFarm, dict_power_curves: dict[str, PowerCurve], 
    required: bool = True, **kwargs
):
    """
    Add wind farm power curves

    Args:
        dict_power_curves (dict[str,PowerCurve]): Dictionary with power curves
            objects.
            keys should coincide with turbine names, and values are
            PowerCurve objects
        required (bool, optional): If True, all turbines are expected to have a
            PowerCurve, raising an error if it is not fulfilled.
        **kwargs: Additional keyword arguments for WindTurbine add_power_curves
            method
    """

    self.check_data_structures_flex(
        dict_power_curves, "power curves", required=required)

    for turbine_name, turbine_obj in self.get_ok_turbines().items():
        turbine_obj.add_power_curves(dict_power_curves[turbine_name], **kwargs)

def create_power_curves(
        self: WindFarm, 
        dict_reference_power_curves: dict[str, PowerCurve] | None = None,
        list_metadata: list[dict] | None = None,
        **kwargs
):
    """
    Creates power curves from the data of speed, power and temperature.

    This function requires one (and only one) of the keyword arguments to be 
    passed, either dict_reference_power_curves or list_metadata.

    Args:
        dict_reference_power_curves (dict[str, PowerCurve] | None, optional): 
            Dictionary with reference power curves. Defaults to None.
        list_metadata (list[dict] | None, optional): List of metadata 
            dictionaries with the metadata of each power curve. 
            For each turbine, and each entry in the metadata list, a power curve
            will be calculated. Defaults to None. 
    """
    
    if dict_reference_power_curves is None and list_metadata is None:
        raise ValueError(
            "dict_reference_power_curves or list_metadata must be passed")
    if dict_reference_power_curves is not None and list_metadata is not None:
        raise ValueError(
            "dict_reference_power_curves and list_metadata are mutually exclusive"
        )

    if dict_reference_power_curves is not None:
        self.check_data_structures(dict_reference_power_curves)

        for turbine_name, turbine_obj in self.get_ok_turbines().items():

            turbine_obj.create_power_curves(
                power_curves=dict_reference_power_curves[turbine_name], 
                **kwargs)          
    
    else:
        for turbine_name, turbine_obj in self.get_ok_turbines().items():

            turbine_obj.create_power_curves(
                list_metadata=list_metadata,
                **kwargs)

def add_alarms(self: WindFarm, dict_alarms: dict[str, Alarms]):
    """
    Add alarms

    Args:
        dict_alarms (dict): Dictionary with alarm objects
    """

    self.check_data_structures_flex(dict_alarms, "alarms")

    for turbine_name, turbine_obj in self.get_ok_turbines().items():
        
        if turbine_name in dict_alarms.keys():
            turbine_obj.add_alarms(dict_alarms[turbine_name])
        else:
            turbine_obj.add_alarms(
                Alarms.from_no_data(self.start_date, self.end_date)
            )


def load_mainwind_output(
        self: WindFarm, 
        folder_path: os.PathLike,
        from_file: bool = False,
        **kwargs):
    """
    Load mainwind output losses

    Args:
        folder_path (os.PathLike): Path to folder or file with mainwind
            outputs
        from_file (bool, optional): If True, load mainwind output from a csv, if
            False look for mainwind output in monthly folders
        **kwargs: Kwargs for load_mainwind_output_losses
    """


    if from_file:
        dict_output_data = load.load_mainwind_from_file(
            folder_path, **kwargs
        )
    else:
        kwargs.pop('mode',None)
        dict_output_data = load.load_mainwind_from_monthly_folders(
            folder_path, self.start_date, self.end_date, **kwargs
        )

    self.check_data_structures(dict_output_data)

    for turbine_name, turbine_obj in self.get_ok_turbines().items():
        turbine_obj.add_mainwind_output_losses(dict_output_data[turbine_name])
