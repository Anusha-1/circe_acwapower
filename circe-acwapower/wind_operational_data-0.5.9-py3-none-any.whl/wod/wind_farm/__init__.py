"""
src/wod/wind_farm/__init__.py

Defintion of the class WindFarm
"""

from datetime import datetime

from wod.wind_turbine import WindTurbine


class WindFarm:
    """
    class WindFarm: Organizes operational data of a Wind Farm

    Attributes:
        name (str): Name of the wind farm
        start_date (datetime): Start datetime
        end_date (datetime): End datetime
        turbines (list[WindTurbine]): List of WindTurbine objects, belonging to
            this wind farm
        catch_turbine_errors (bool): Boolean that indicates the behaviour on 
            turbine errors
    """

    # Import methods
    from ._add_extra import (
        add_temperature_data,
        add_power_curves,
        create_power_curves,
        add_alarms,
        load_mainwind_output,
    )
    from ._check import (
        check_data_structures,
        check_data_structures_flex
    )
    from ._load import (
        load_from_monthly_data, 
        load_from_two_sheets_excel, 
        load_vpt_month_data,
        load_data_without_timestamps,
        load_from_file_with_turbine_column,
        load_vpt_file,
        load_dataframe
    )
    from ._output import (
        write_powerbi_output, 
        write_power_anomalies, 
        write_power_curves,
        write_global_power_curve
    )
    from ._plot import plot
    from ._power_curve import (
        get_power_curves_differences,
        correct_temperatures,
        check_power_curves
    )
    from ._stats import print_losses_stats, print_derating_losses_stats

    def __init__(
        self, 
        name: str | None = None, 
        start_date: datetime | None = None, 
        end_date: datetime | None = None,
        catch_turbine_errors: bool = False
    ):
        """Initialization method

        Args:
            name (str, optional): Name of the wind farm. Defaults to None.
            start_date (datetime): Start datetime. Defaults to None.
            end_date (datetime): End datetime. Defaults to None.
            catch_turbine_errors (bool): If True, it catches the errors that
                occur in specific turbines, so we don't lose calculations on 
                other turbines. If False, it raises the errors on the spot.
                Defaults to False
        """
        self.name: str = name
        self.start_date: datetime = start_date
        self.end_date: datetime = end_date
        self.catch_turbine_errors: bool = catch_turbine_errors

        ## Turbines
        self.turbines: dict[str, WindTurbine] = {}

    def __str__(self) -> str:
        return f"WindFarm(name={self.name}, start_date={self.start_date}, end_date={self.end_date})"

    def __repr__(self) -> str:
        repr_str = self.__str__() + "\n"
        for turbine in self.turbines.values():
            repr_str += "--------------\n"
            repr_str += repr(turbine) + "\n"

        return repr_str

    def get_ok_turbines(self) -> dict[str, WindTurbine]:
        """
        Returns a dictionary with only the correct turbines

        Returns:
            dict[str, WindTurbine]: Dictionary with the correct turbines, i.e.
                status = 'Ok'
        """

        new_turbines_dict: dict[str, WindTurbine] = {}

        for turbine_key, turbine_obj in self.turbines.items():
            if turbine_obj.status == 'Ok':
                new_turbines_dict[turbine_key] = turbine_obj

        return new_turbines_dict
     