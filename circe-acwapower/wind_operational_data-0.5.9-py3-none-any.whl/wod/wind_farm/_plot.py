"""
wod/wind_farm/_plot.py

Plot methods for the Wind Farm class
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

import wod.visualization as vis
if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def plot(
        self: WindFarm,
        plot_type: str = 'temp_power_curves'
) -> go.Figure:
    """
    Plot method for WindFarm

    Args:
        plot_type (str, optional): Label to specify the type of plot to make. 
            Options are the same as in WindTurbine plot method          

            Defaults to 'temp_power_curves'.

    Returns:
        (go.Figure): Plotly figure
    """

    return vis.plot_temperature_power_curves_in_farm(self, plot_type)
