"""
wod/wind_farm/_power_curve.py

Methods to aggregate power curves information
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def get_power_curves_differences(self: WindFarm) -> pd.DataFrame:
    """
    Get a dataframe with total differences between new and reference for all the
    power curves of the farm

    Returns:
        (pd.DataFrame): Dataframe with total differences
    """

    lst_records: list[dict] = []
    for turbine in self.get_ok_turbines().values():
        for pc in turbine.power_curves:
            lst_records.append(pc.total_difference)
    
    return pd.DataFrame.from_records(lst_records)

def correct_temperatures(self: WindFarm):
    """
    Correct temperatures for all turbines in the farm
    """

    for turbine in self.get_ok_turbines().values():
        turbine.correct_temperatures()

def check_power_curves(self: WindFarm):
    """
    Check number of power curves per WindFarm
    """

    for turbine in self.get_ok_turbines().values():
        print(f"Turbine {turbine.name}: {len(turbine.power_curves)} power curves")
