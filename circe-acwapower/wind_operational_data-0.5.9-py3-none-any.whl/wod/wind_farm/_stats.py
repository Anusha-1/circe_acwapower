"""
src/wod/wind_farm/_stats.py

Method functions to get stats
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def print_losses_stats(self: WindFarm, output_file: os.PathLike = None):
    """
    Print losses stats

    Args:
        output_file (os.PathLike, optional): Output file path. 
            Defaults to None.
    """
    text = ''
    for turbine_name, turbine in self.get_ok_turbines().items():

        text += f'Turbine {turbine_name} \n'
        text += turbine.get_losses_stats()
        text += '------------------------\n'

    print(text)

    if output_file:
        with open(output_file, "w") as f:
            f.write(text)

def print_derating_losses_stats(self: WindFarm, output_file: os.PathLike = None):
    """
    Print derating losses stats

    Args:
        output_file (os.PathLike, optional): Output file path. 
            Defaults to None.
    """
    text = ''
    for turbine_name, turbine in self.get_ok_turbines().items():

        text += f'Turbine {turbine_name} \n'
        text += turbine.get_derating_losses_stats()
        text += '------------------------\n'

    print(text)

    if output_file:
        with open(output_file, "w") as f:
            f.write(text)
