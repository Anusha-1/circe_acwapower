"""
wod/wind_farm/_check.py

Check methods
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from wod.warnings import (
    warn_mismatch_turbines,
    warn_turbines_without_additional_data,
    warn_missing_original_turbines
)

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def check_data_structures(self: WindFarm, dict_data: dict):
    """
    Check if a new data structure (dictionary with keys designating turbines) is
    coherent with current turbines.
    If names doesn't match, but the number of turbines coincide, we'll replace
    the turbines keys with the new dictionary keys.
    If match is impossible, we'll return an error

    Args:
        dict_data (dict): New data structure we want to introduce in our 
            WindFarm. Keys should be the turbines

    Raises:
        Exception: If the new data can't be assigned between current turbines
    """
    
    current_turbines = list(self.get_ok_turbines().keys())
    proposed_turbines = list(dict_data.keys())

    if set(current_turbines) != set(proposed_turbines):
        if len(current_turbines) == len(proposed_turbines):
            
            dict_turbines = {
                new_key: self.turbines[old_key] 
                for old_key, new_key in zip(current_turbines, proposed_turbines)
            }
            self.turbines = dict_turbines
            for turbine_key, turbine in self.get_ok_turbines().items():
                turbine.name = turbine_key

            warn_mismatch_turbines(current_turbines, proposed_turbines)

        else:
            raise Exception("Can't match turbines data")

def check_data_structures_flex(
        self: WindFarm, dict_data: dict, data_type: str, 
        required: bool = False):
    """
    Checks data structures in a flexible way. This means that we are not looking
    for a 1-to-1 relation between turbines in the WindFarm object and turbines
    in the dictionary data structure. 

    We'll just check the intersection and the union, and warn about turbines
    outside from the intersection.

    Args:
        dict_data (dict): Dictionary structure with new turbines data 
            (alarms, power curves, ...). Keys must be the name of the turbines
        data_type (str): Specifies the data type we are trying to add after this
            comparison. E.g: alarms, power curves,...
        required (bool, optional): If True, all original turbines are supposed
            to have a counterpart in the new data structure, raising an Error if
            this condition is not met, instead of a simple warning. 
            The inverse is not true, turbines that appear in the new data 
            structure but are missing in the original object would still be only
            a warning. Defaults to False. 
    """

    current_turbines = set(list(self.get_ok_turbines().keys()))
    proposed_turbines = set(list(dict_data.keys()))

    warn_turbines_without_additional_data(
        current_turbines.difference(proposed_turbines), data_type)
    warn_missing_original_turbines(
        proposed_turbines.difference(current_turbines), data_type, required)
