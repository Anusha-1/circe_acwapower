"""
src/wod/wind_farm/_load.py

Method functions for loading data
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import wod.load as load

if TYPE_CHECKING:
    import pandas as pd
    from wod.wind_farm import WindFarm

from wod.wind_turbine import WindTurbine


def load_from_monthly_data(
        self: WindFarm, folder_path: os.PathLike, data_validation: dict = {}, 
         **kwargs
    ):
    """
    Loads basic power vs speed data from monthly folders into the different 
    turbines

    Args:
        folder_path (os.PathLike): Path to Wind Farm folder
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Keyword arguments for function load_basic_monthly_data at
            wod/load/monthly.py
    """

    dict_data = load.load_from_monthly_data_aux(
        folder_path, start_date = self.start_date, end_date = self.end_date,
        **kwargs)
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }
        
def load_from_two_sheets_excel(
        self: WindFarm, file_path: os.PathLike, data_validation: dict = {}, 
        **kwargs):
    """Load data from an Excel with two sheets, in one sheet we have speed 
    and power time series and in the other sheet we have temperature 
    timeseries.

    Args:
        file_path (os.PathLike): Path to the excel file
        data_validation (dict, optional): Data validation keyword arguments.
            Defaults to {}.
        **kwargs: Keyword arguments for WindTurbine
    """

    dict_data = load.load_from_two_sheets_excel_aux(
        file_path, start_date=self.start_date, end_date=self.end_date, 
        **kwargs)
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }

def load_vpt_month_data(
        self: WindFarm, folder_path: os.PathLike, data_validation: dict = {}, 
        **kwargs
):
    """
    Load data from a monthly folder structure, looking for files with VPT data
    (i.e. speed, power and temperature)

    Args:
        folder_path (os.PathLike): Path to Wind Farm folder
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Keyword arguments for function load_basic_vpt_data at
            wod/load/vpt.py
    """
    
    dict_data = load.load_vpt_month_data_aux(
        folder_path, self.start_date, self.end_date,
        **kwargs)
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }

def load_data_without_timestamps(
        self: WindFarm, 
        file_path: os.PathLike, 
        data_validation: dict = {}, 
        **kwargs):
    """
    Load data for a single file without timestamps. The expected structure of 
    the file consists in power, wind and temperature columns for each turbine
    in successive columns. Example:

    power_ave   wind_ave	temp_ave	power_ave	wind_ave	temp_ave    ...

    Each turbine can have a different number of data points.

    Unlike other load methods, we are not passing a data_validation dictionary.
    Thus, all data points will in principle be labelled as valid. 

    Args:
        file_path (os.PathLike): Path to file with data
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Kwargs for function load_filtered_data at wod/load/filtered.py
    """

    dict_data = load.load_data_without_timestamps_aux(
        file_path, **kwargs
    )
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }

def load_from_file_with_turbine_column(
        self: WindFarm, 
        file_path: os.PathLike,
        data_validation: dict = {}, 
        **kwargs):
    """
    Loads data from a csv file with 5 columns: datetime, turbine, speed, power
    and temperature 

    Args:
        file_path (os.PathLike): Path to file with data
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Kwargs for function load_file_with_turbine_columns at 
            wod/load/turbine_column.py
    """

    dict_data = load.load_from_file_with_turbine_column_aux(
        file_path, **kwargs
    )
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }

def load_vpt_file(
        self: WindFarm, 
        file_path: os.PathLike,
        data_validation: dict = {}, 
        **kwargs):
    """
    Load a unique VPT file of data

    Args:
        file_path (os.PathLike): Path to file with data
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Kwargs for function load_vpt_file_aux at 
            wod/load/vpt.py
    """

    dict_data = load.load_vpt_file_aux(
        file_path, self.start_date, self.end_date, **kwargs
    )
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }

def load_dataframe(
        self: WindFarm,
        df: pd.DataFrame,
        data_validation: dict = {}, 
        **kwargs
):
    """
    Loads a dataframe of 10-min info

    Args:
        df (pd.DataFrame): Dataframe with 10-min info
        data_validation (dict): Dictionary with **kwargs for WindTurbine
            class
        **kwargs: Kwargs for function load_vpt_file_aux at 
            wod/load/dataframe.py
    """

    dict_data = load.load_dataframe_aux(
        df, self.start_date, self.end_date, **kwargs
    )
    self.turbines = {
        key: WindTurbine(
            key, 
            value,
            wind_farm_name=self.name,
            catch_error=self.catch_turbine_errors,
            **data_validation) for key, value in dict_data.items()
    }