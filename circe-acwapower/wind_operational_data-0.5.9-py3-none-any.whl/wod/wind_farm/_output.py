"""
src/wod/wind_farm/_output.py

Method functions to write output files
"""

from __future__ import annotations

import itertools
import os
import pathlib
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from wod.wind_farm import WindFarm

def write_powerbi_output(
        self: WindFarm, file_path: os.PathLike, derating: bool = False, 
        reduced_file: bool = False):
    """
    Write an output in a format suitable for PowerBI

    Args:
        file_path (os.PathLike): Output path for the file
        derating (bool, optional): Activates derating rows. Defaults to False
        reduced_file (bool, optional): Writes a second reduced file with limited
            columns and a comma as decimal separator
    """

    ## Loop through turbines
    lst_dfs: list[pd.DataFrame] = []
    for turbine_name in self.get_ok_turbines().keys():

        lst_dfs.append(
            self.turbines[turbine_name].emulate_mainwind_output(
                self.name, derating=derating)
        )

    df_final = pd.concat(lst_dfs)

    # Write in file
    file_path = pathlib.Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    df_final.to_csv(file_path, sep = '\t', index=False)

    # (Optional) Write second reduced file
    # This file will have the suffix _red before the extension, only will have
    # a limited set of the original columns, and decimal separator will be ','
    if reduced_file:
        file_path = file_path.with_name(
            file_path.stem + '_red' + file_path.suffix)
        lst_columns_to_keep = ['windfarm', 'timestamp', 'wtg', 'w', 'p', 'perd',
                               'rechazo', 'month', 'temp_segment']
        df_red = df_final[lst_columns_to_keep]
        df_red.to_csv(file_path, sep = '\t', index=False, decimal=',')


def write_power_anomalies(self: WindFarm, file_path: os.PathLike):
    """
    Generates an output file with speed and power for each turbine, but 
    modifying power substracting a -30000 when a power anomaly is detected

    Args:
        file_path (os.PathLike): Output file path
    """

    ##Loop through turbines
    lst_dfs: list[pd.DataFrame] = []
    for turbine_name in self.get_ok_turbines().keys():
        lst_dfs.append(
            self.turbines[turbine_name].format_power_anomalies()
        )

    ## Let's use the first df to save the datetime column
    df_init = lst_dfs[0]

    ## For the rest, we drop the column
    lst_dfs_aux = [df.drop(columns=['Datetime']) for df in lst_dfs[1:]]

    ## Final list of dataframes to paste is:
    lst_dfs = [df_init] + lst_dfs_aux

    ## Concat dataframes
    df_final = pd.concat(lst_dfs, axis=1)

    # Write in file
    file_path = pathlib.Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    df_final.to_csv(file_path, sep = '\t', index=False)

def write_power_curves(
        self: WindFarm, 
        folder_path: os.PathLike,
        temp_min_column: str = 'Tmin',
        temp_max_column: str = 'Tmax',
        bin_column: str = 'bin',
        power_column_prefix: str = 'mu',
        deviation_column_prefix: str = 'sigma',
        min_temp: float | int = -20,
        max_temp: float | int = 50,
        round_decimals: int = 1,
        add_global_deviation: bool = False,
        replace_with_global_deviation: bool = False):
    """
    Writes the PowerCurves of a WindFarm in a single Excel file with the format:

    Tmin  Tmax  bin  sigma1  mu1  sigma2  mu2  ...

    Args:
        folder_path (os.PathLike): Folder where we'll write the final excel.
            The name of the file is selected from the wind farm name
        temp_min_column (str, optional): Name of the column with the lower 
            bounds of temperature. Defaults to 'Tmin'.
        temp_max_column (str, optional): Name of the column with the upper 
            bounds of temperature. Defaults to 'Tmax'.
        bin_column (str, optional): Name of the column with the wind speed bins.
            Defaults to 'bin'.
        power_column_prefix (str, optional): Name of the column with the average
            power values. Defaults to 'mu'.
        deviation_column_prefix (str, optional): Name of the column with the 
            standard deviation of the power. Defaults to 'sigma'.
        min_temp (float | int, optional): Minimum temperature possible. 
            Defaults to -20.
        max_temp (float | int, optional): Maximum temperature possible. 
            Defaults to 50.
        round_decimals (int, optional): Number of decimals to consider. 
            Defaults to 1.
        add_global_deviation (bool, optional): If True, adds a extra column with
            the deviation of a global PowerCurve with all the data points.
            This had to be previously calculated. Defaults to False
        replace_with_global_deviation (bool, optional): If True, the deviation of
            the global PowerCurve is used to replace the temperature-specific
            deviation. It shouldn't be used with add_global_deviation = True.
            Defaults to False
    """
    
    # Extract all dataframes in a dictionary
    dict_dfs: dict[str, dict[tuple | str, pd.DataFrame]] = {}
    lst_temp: list[tuple] = []
    for turbine in self.get_ok_turbines().values():

        if turbine.status != 'Ok':
            continue

        dict_dfs[turbine.name] = {}

        for power_curve in turbine.temperature_power_curves():
            temp_tuple = (power_curve.metadata['min_temperature'],
                          power_curve.metadata['max_temperature'])
            
            dict_dfs[turbine.name][temp_tuple] = power_curve.data[['bin','power','deviation']]
            lst_temp.append(temp_tuple)

        ## Add additional reference sigma
        if add_global_deviation or replace_with_global_deviation:            
            dict_dfs[turbine.name]['global'] = turbine\
                .global_power_curve.data[['bin','power','deviation']]

            if dict_dfs[turbine.name]['global'] is None:
                raise Exception("Missing a global PowerCurve")

    set_temp = set(lst_temp)
    
    # Paste the dataframes in the desired format
    temp_dfs: list[pd.DataFrame] = []
    for temp_tuple in set_temp:

        bin_lists: list[list] = []
        dfs_list: list[pd.DataFrame] = []
        for turbine_key in dict_dfs.keys():

            df = dict_dfs[turbine_key][temp_tuple]
            
            columns_of_interest = ['deviation', 'power']
            if add_global_deviation or replace_with_global_deviation:
                ## Join global deviation
                df = df.join(
                    dict_dfs[turbine_key]['global'][["bin", "deviation"]]\
                        .set_index('bin')\
                        .rename(columns={'deviation': 'global_deviation'}),
                    on='bin'
                )
                columns_of_interest.append('global_deviation')
       
            bin_lists.append(list(df['bin']))

            df_aux = df[columns_of_interest].rename(columns={
                'power': f'{power_column_prefix}{turbine_key}',
                'deviation': f'{deviation_column_prefix}{turbine_key}'
            })

            if add_global_deviation or replace_with_global_deviation:
                df_aux = df_aux.rename(
                    columns={
                        'global_deviation': f'global_sigma{turbine_key}'
                    }
                )

            dfs_list.append(df_aux)

        for bin_list_a, bin_list_b in itertools.product(bin_lists, bin_lists):
            assert bin_list_a == bin_list_b, "Bins are not the same across turbines"
        bin_final_list = bin_lists[0]

        ## Common columns
        t_min = [temp_tuple[0]]*len(bin_final_list)
        t_max = [temp_tuple[1]]*len(bin_final_list)
        df_init = pd.DataFrame({
            temp_min_column: t_min,
            temp_max_column: t_max,
            bin_column: bin_final_list
        })

        ## Concat all turbine dfs (horizontally)
        dfs_list = [df_init] + dfs_list
        temp_dfs.append(pd.concat(dfs_list, axis=1))

    # Concat all temperature dfs (vertically)
    final_df = pd.concat(temp_dfs)

    # Replace min and max temperatures
    final_df[temp_min_column] = final_df[temp_min_column].replace(
        final_df[temp_min_column].min(),
        min_temp
    )
    final_df[temp_max_column] = final_df[temp_max_column].replace(
        final_df[temp_max_column].max(),
        max_temp
    )
    
    # Round to X decimals
    final_df = final_df.round(round_decimals)

    # Sort values (temperatures are not in order)
    final_df = final_df.sort_values(by=[temp_min_column, bin_column])

    # Final formatting
    if replace_with_global_deviation:
        for turbine_key in dict_dfs.keys():
            final_df[f'{deviation_column_prefix}{turbine_key}'] = final_df[f'global_sigma{turbine_key}']
        
        if not add_global_deviation:
            for turbine_key in dict_dfs.keys():
                final_df = final_df.drop(columns=[f'global_sigma{turbine_key}'])

    # Write final dataframe to excel
    name = f"reference_{self.name.lower()}"
    final_df.to_excel(
        pathlib.Path(folder_path, f"{name}.xlsx"),
        sheet_name=name,
        index=False
    )

def write_global_power_curve(
        self: WindFarm,
        folder_path: os.PathLike,
        suffix_name: str = '_global',
        temp_min_column: str = 'Tmin',
        temp_max_column: str = 'Tmax',
        bin_column: str = 'bin',
        power_column_prefix: str = 'mu',
        deviation_column_prefix: str = 'sigma',
        min_temp: float | int = -20,
        max_temp: float | int = 50,
        round_decimals: int = 1,
):
    """
    Writes the global power curve (i.e. without temperature distinction)

    NOTE: This logic is repeated (partially) in write_power_curve. It can be 
    improved with common function

    Args:
        folder_path (os.PathLike): Folder where we'll write the final excel.
            The name of the file is selected from the wind farm name
        suffix_name (str, optional): Suffix for the name of the resulting Excel
            file. Defaults to "_global" 
        temp_min_column (str, optional): Name of the column with the lower 
            bounds of temperature. Defaults to 'Tmin'.
        temp_max_column (str, optional): Name of the column with the upper 
            bounds of temperature. Defaults to 'Tmax'.
        bin_column (str, optional): Name of the column with the wind speed bins.
            Defaults to 'bin'.
        power_column_prefix (str, optional): Name of the column with the average
            power values. Defaults to 'mu'.
        deviation_column_prefix (str, optional): Name of the column with the 
            standard deviation of the power. Defaults to 'sigma'.
        min_temp (float | int, optional): Minimum temperature possible. 
            Defaults to -20.
        max_temp (float | int, optional): Maximum temperature possible. 
            Defaults to 50.
        round_decimals (int, optional): Number of decimals to consider. 
            Defaults to 1.
    """

    # Extract the dataframe for each turbine in a list
    dfs_list: list[pd.DataFrame] = []
    bin_lists: list[pd.Series] = []
    for turbine in self.get_ok_turbines().values():
        
        bin_lists.append(list(turbine.global_power_curve.data['bin']))
        
        df_aux = turbine.global_power_curve.data[['power','deviation']]
        df_aux = df_aux.rename(
            columns={
                'power': f'{power_column_prefix}{turbine.name}',
                'deviation': f'{deviation_column_prefix}{turbine.name}'
            }
        )
        # df_aux = df_aux.reset_index()
        dfs_list.append(df_aux)

    for bin_list_a, bin_list_b in itertools.product(bin_lists, bin_lists):
        assert bin_list_a == bin_list_b, "Bins are not the same across turbines"
    bin_final_list = bin_lists[0]

    # Prepare common columns
    t_min = [min_temp]*len(bin_final_list)
    t_max = [max_temp]*len(bin_final_list)
    df_init = pd.DataFrame({
        temp_min_column: t_min,
        temp_max_column: t_max,
        bin_column: bin_final_list
    })

    # Concat horizontally
    dfs_list = [df_init] + dfs_list
    final_df = pd.concat(dfs_list, axis=1)

    # Round to X decimals
    final_df = final_df.round(round_decimals)

    # Write final dataframe to excel
    name = f"reference_{self.name.lower()}{suffix_name}"
    final_df.to_excel(
        pathlib.Path(folder_path, f"{name}.xlsx"),
        sheet_name=name,
        index=False
    )
