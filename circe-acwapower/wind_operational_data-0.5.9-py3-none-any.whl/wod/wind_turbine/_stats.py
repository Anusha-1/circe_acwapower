"""
src/wod/wind_turbine/_stats.py

Method functions to get stats
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine
    
def get_losses_stats(self: WindTurbine) -> str:
    """
    Calculate losses stats and give a text description of the results

    Returns:
        (str): Text with losses stats
    """

    df = self.data
    df['old_loss'] = self.mainwind_output_losses['perd']
    df['diff'] = df['loss'] - df['old_loss']
    df['abs_diff'] = df['diff'].abs()

    text = f"Total loss: {df['loss'].sum():.2f} \n"
    text += f"Total old loss: {df['old_loss'].sum():.2f} \n"
    text += f"Total difference: {df['diff'].sum():.2f} ({df['diff'].sum()/df.loss.sum()*100:.3f} %) \n"
    text += f"Total absolute difference: {df['abs_diff'].sum():.2f} ({df['abs_diff'].sum()/df['loss'].sum()*100:.3f} %) \n"

    return text

def get_derating_losses_stats(self: WindTurbine) -> str:
    """
    Calculate derating losses stats and give a text description of the results

    Returns:
        (str): Text with derating losses stats
    """

    df = self.data

    text = f"Total derating loss {df['derating_loss'].sum():.2f} \n"
    text += f"Proportion with respect to total loss: {df['derating_loss'].sum()/df['loss'].sum()*100:.2f} % \n"

    return text
