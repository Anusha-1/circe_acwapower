"""
wod/wind_turbine/temperature_correction/_check.py

Module with checks between power curves
"""

import pandas as pd

def check_value_up(
        row: int, col: int, df: pd.DataFrame
) -> bool:
    """
    Check if current value of a dataframe is higher than the previous row

    Args:
        row (int): Current row index
        col (int): Current column index
        df (pd.DataFrame): Dataframe to check

    Returns:
        bool: True if current value is higher than the value above him in the
            same column
    """

    check_prev = False
    if row > 0:
        check_prev = (
            df.loc[row - 1, col] < df.loc[row, col]
        )

    return check_prev

def check_value_down(
        row: int, col: int, df: pd.DataFrame
) -> bool:
    """
    Check if current value of a dataframe is lower than the next row

    Args:
        row (int): Current row index
        col (int): Current column index
        df (pd.DataFrame): Dataframe to check

    Returns:
        bool: True if current value is lower than the value below him in the
            same column
    """

    check_next = False
    if row < (len(df.index) - 1):
        check_next = (
            df.loc[row, col] < df.loc[row + 1, col]
        )
    
    return check_next
