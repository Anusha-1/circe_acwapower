"""
wod/wind_turbine/temperature_correction/_matrix.py

Module for the creation of auxiliary matrix formed with different temperature
power curves
"""
from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def create_power_curves_matrix(
        wt: WindTurbine,
        field: str
) -> pd.DataFrame:
    """
    Creates a dataframe where the rows are different PowerCurves and the columns
    are bins. In the cells we can place different values.

    Args:
        wt (WindTurbine): WindTurbine with the desired PowerCurves
        field (str): Value to place in the cells. Must be a column of the 
            PowerCurve data attribute

    Returns:
        (pd.DataFrame): Final matrix of power curves
    """

    return pd.DataFrame(
        data = [list(pc.data[field].copy()) for pc in wt.temperature_power_curves()]
    )