"""
wod/wind_turbine/temperature_correction/_correction.py

Module with temperature correction algorithms
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

import wod.wind_turbine.temperature_correction._check as check
import wod.wind_turbine.temperature_correction._matrix as mat
import wod.wind_turbine.temperature_correction._replace as rep
if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def correct_temperature_v1(wt: WindTurbine):
    """
    Correct power values at a wind turbine object to make them always decreasing
    with temperature

    Args:
        wt (WindTurbine): WindTurbine object whose PowerCurves we want to 
            correct
    """
    
    # We build a dataframe where columns are bins and rows are temperatures
    # for powers and for count of data
    # Also, we need two versions, as one will be modified on the flight    
    df_power = mat.create_power_curves_matrix(wt, 'power')
    df_count = mat.create_power_curves_matrix(wt, 'n_data')
    df_sigma = mat.create_power_curves_matrix(wt, 'deviation')
    df_power_new, df_count_new, df_sigma_new = df_power.copy(), df_count.copy(), df_sigma.copy()

    # While loop. We'll iterate through the power curve values until there is no
    # error on temperatures
    condition = True
    loop_counter = 0
    while condition and loop_counter <= 5:
        number_of_replaces = 0
        for col in df_power.columns:
            for row in np.arange(len(wt.power_curves)):
                
                ## Check need to change
                ### 1. Is already a NaN
                check_nan = np.isnan(df_power.loc[row, col])
                check_nan_sigma = np.isnan(df_sigma.loc[row, col])

                ### 2. Is higher than previous temp or lower than next temp
                if not check_nan:
                    check_prev = check.check_value_up(row, col, df_power)
                    check_next = check.check_value_down(row, col, df_power)
                else:
                    check_prev, check_next = False, False

                ### 3. If it is NaN, replace by previous or next
                if check_nan:
                    df_power_new, df_count_new = rep.replace_if_nan(
                        row, col, df_power, df_power_new, df_count, df_count_new
                    )
                    number_of_replaces += 1  
                if check_nan_sigma:
                    df_sigma_new, df_count_new = rep.replace_if_nan(
                        row, col, df_sigma, df_sigma_new, df_count, df_count_new
                    )
                    number_of_replaces += 1                    

                ### 4. If check_prev or check_next, we need to compare the counts.
                if check_prev or check_next:

                    df_power_new, df_count_new, number_of_replaces = rep.replace_if_inversion(
                        row, col, df_power, df_power_new, df_count, df_count_new,
                        number_of_replaces, check_prev, check_next
                    )

        loop_counter += 1

        df_power = df_power_new.copy()
        df_count = df_count_new.copy()
        df_sigma = df_sigma_new.copy()
        condition = number_of_replaces > 0

    # Final NaN replacement (with previous temperature)
    df_power.ffill(axis=1)

    ## Change each power curve with new values
    for i, pc in enumerate(wt.power_curves):
        pc.data['power'] = df_power.iloc[i]
        pc.data['deviation'] = df_sigma.iloc[i]

        ## Re-arrange limits
        pc.data['power_min'] = pc.data['power'] - pc.data['factor']*pc.data['deviation']
        pc.data['power_max'] = pc.data['power'] + pc.data['factor']*pc.data['deviation']
