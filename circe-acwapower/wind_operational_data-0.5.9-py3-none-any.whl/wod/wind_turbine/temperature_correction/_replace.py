"""
wod/wind_turbine/temperature_correction/_replace.py

Module to perform replacements in matrices
"""

import numpy as np
import pandas as pd

def replace_if_nan(
        row: int, col: int,
        df: pd.DataFrame, df_new: pd.DataFrame,
        df_count: pd.DataFrame, df_count_new: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Replacement algorithm when we have a NaN value. It will fill the value
    with a neighbour. If it can choose, it will use the power value 
    corresponding to the higher count of data points.

    Args:
        row (int): Current row
        col (int): Current column
        df (pd.DataFrame): Dataframe with values as of previous iteration
        df_new (pd.DataFrame): Dataframe with values for current iteration
        df_count (pd.DataFrame): Dataframe with count values as of previous 
            iteration
        df_count_new (pd.DataFrame): Dataframe with count values for current
            iteration
    Returns:
        (pd.DataFrame): New dataframe for power values
        (pd.DataFrame): New dataframe for count values
    """

    if row == 0:
        replace_with = 1

        df_new.loc[row, col] = df.loc[row + replace_with, col]
        df_count_new.loc[row, col] = df_count.loc[row + replace_with, col]

    elif row == (len(df.index) - 1):
        replace_with = -1

        df_new.loc[row, col] = df.loc[row + replace_with, col]
        df_count_new.loc[row, col] = df_count.loc[row + replace_with, col]

    else:
        replace_with = int(
            (df_count.loc[row + 1, col] >= df_count.loc[row - 1, col])
        ) - int(
            (df_count.loc[row + 1, col] < df_count.loc[row - 1, col])
        )

        # replace if not NaN
        if not np.isnan(df.loc[row + replace_with, col]):
            df_new.loc[row, col] = df.loc[row + replace_with, col]
            df_count_new.loc[row, col] = df_count.loc[row + replace_with, col]

        # If NaN, try to repace in the other directon
        elif not np.isnan(df.loc[row - replace_with, col]):
            df_new.loc[row, col] = df.loc[row - replace_with, col]
            df_count_new.loc[row, col] = df_count.loc[row - replace_with, col]

    return df_new, df_count_new


def replace_if_inversion(
        row: int, col: int,
        df_power: pd.DataFrame, df_power_new: pd.DataFrame,
        df_count: pd.DataFrame, df_count_new: pd.DataFrame,
        number_of_replaces: int, 
        check_prev: bool, check_next: bool
) -> tuple[pd.DataFrame, pd.DataFrame, int]:
    """
    Replacement algorithm for the case when we have a temperature inversion

    Args:
        row (int): Current row
        col (int): Current value
        df_power (pd.DataFrame): Dataframe with power values as of previous 
            iteration
        df_power_new (pd.DataFrame): Dataframe with power values for current
            iteration
        df_count (pd.DataFrame): Dataframe with count values as of previous 
            iteration
        df_count_new (pd.DataFrame): Dataframe with count values for current
            iteration
        number_of_replaces (int): Current number of replacements made
        check_prev (bool): True if there is a temperature inversion with respect
            to previous temperature
        check_next (bool): True if there is a temperature inversion with respect
            to next temperature

    Returns:
        (pd.DataFrame): New dataframe for power values
        (pd.DataFrame): New dataframe for count values
        (int): Updated number of replaces
    """

    ## The three points are inverted, replace with the point with more count
    row_to_replace_with = df_count.loc[
        row - int(check_prev) : row + int(check_next), col].idxmax()

    df_power_new.loc[row, col] = df_power.loc[row_to_replace_with, col]
    df_count_new.loc[row, col] = df_count.loc[row_to_replace_with, col]
    if row_to_replace_with != row:
        number_of_replaces += 1

    return df_power_new, df_count_new, number_of_replaces
