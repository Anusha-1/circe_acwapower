"""
src/wod/wind_turbine/_add_extra.py

Method functions to add extra data
"""

from __future__ import annotations

from copy import copy
from typing import TYPE_CHECKING

import pandas as pd

import wod.check as check
import wod.load as load
from wod.alarms import Alarms
from wod.power_curve import PowerCurve
from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def add_temperature_data(self: WindTurbine, df_temp: pd.DataFrame, **kwargs):
    """
    Add temperature data by merging basic data with temperature data

    Args:
        df_temp (pd.DataFrame): Dataframe with datetime, temperature columns
        **kwargs: Keyword arguments for check.data_validation
    """

    df_base = self.data[['datetime','speed','power']]
    self.data = df_base.merge(
        df_temp[['temperature']], 
        how='left',
        left_index=True,
        right_index=True)        

    self.data = check.validate_data(self.data, **kwargs)
    
    # Recalculate start and end times
    ## (They might change if we drop NaN after merge)
    self.start_time = self.data.datetime.min()
    self.end_time = self.data.datetime.max()

@catch_error
def add_power_curves(
        self: WindTurbine, 
        power_curves: PowerCurve | list[PowerCurve]):
    """
    Add Power Curves to turbine

    Args:
        power_curves (PowerCurve | list[PowerCurve]): Power Curve(s) 
            to add. Can be a single PowerCurve or a list of PowerCurve 
            objects. In any case, an attribute in the form of a list named
            power_curves will be completed with new power curves.
    """

    if isinstance(power_curves, PowerCurve):
        self.power_curves.append(power_curves)
    else:
        self.power_curves += power_curves

@catch_error
def create_power_curves(
        self: WindTurbine, 
        power_curves: PowerCurve | list[PowerCurve] | None = None,
        list_metadata: list[dict] | None = None,
        filter_points_kwargs: dict = {},
        algorithm_kwargs: dict = {}
):
    """
    Create Power Curves from data points.

    This function requires one (and only one) of the keyword arguments to be 
    passed, either power_curves or list_metadata.

    Args:
        power_curves (PowerCurve | list[PowerCurve] | None, optional): Reference
            power curves to use. If None is passed, we calculate the power curve
            without reference. Defaults to None.
        list_metadata (list[dict] | None, optional): List of metadata 
            dictionaries with the metadata of each power curve. 
            Defaults to None.
        filter_points_kwargs (dict, optional): Keyword arguments for the 
                filtering of data points. Check the method function
                filter_points at wod/power_curve/_filter.py.                
                Defaults to {}
        algorithm_kwargs (dict, optional): Keyword arguments for the 
            algorithm that calculates the power curve. Check the method
            function calculate_power_curve at wod/power_curve/_calculate.py.
            Defaults to {}
            
    """
    
    if power_curves is None and list_metadata is None:
        raise ValueError(
            "power_curves or list_metadata must be passed")
    if power_curves is not None and list_metadata is not None:
        raise ValueError(
            "power_curves and list_metadata are mutually exclusive"
        )

    if power_curves is not None:
        ## Calculating power curves from reference

        if isinstance(power_curves, PowerCurve):

            ## Add turbine name to metadata
            metadata = power_curves.metadata.copy()
            metadata['turbine'] = copy(self.name)
            metadata['wind_farm'] = self.wind_farm_name

            self.power_curves.append(
                PowerCurve.from_data_points(
                    self.data,
                    reference_power_curve=power_curves,
                    metadata=metadata,
                    filter_points_kwargs=filter_points_kwargs,
                    algorithm_kwargs=algorithm_kwargs
                )
            )
        else:
            for pc in power_curves:

                ## Add turbine name to metadata
                metadata = pc.metadata.copy()
                metadata['turbine'] = copy(self.name)
                metadata['wind_farm'] = self.wind_farm_name

                self.power_curves.append(
                    PowerCurve.from_data_points(
                        self.filter_data_for_temperature_segment(
                            pc.metadata
                        ),
                        reference_power_curve=pc,
                        metadata=metadata,
                        filter_points_kwargs=filter_points_kwargs,
                        algorithm_kwargs=algorithm_kwargs
                    )
                )
    else:

        for metadata in list_metadata:

            metadata['turbine'] = copy(self.name)
            metadata['wind_farm'] = self.wind_farm_name

            assert self.data is not None, "No data available"

            data_aux = None
            if metadata['type'] == 'temperature':
                data_aux = self.filter_data_for_temperature_segment(
                            metadata
                        )
            elif metadata['type'] == 'global':
                data_aux = self.data            

            self.power_curves.append(
                PowerCurve.from_data_points(
                    data_aux,
                    metadata=metadata,
                    filter_points_kwargs=filter_points_kwargs,
                    algorithm_kwargs=algorithm_kwargs
                )
            )

@catch_error
def add_alarms(self: WindTurbine, alarms: Alarms):
        """
        Add Alarms object to turbine. It assigns the alarms to an attribute and 
        also calculate alarm status to each 10-min data point

        Args:
            alarms (Alarms): Alarms object
        """

        self.alarms = alarms

        self.data = load.merge_alarms(self.data, self.alarms.data)

@catch_error
def add_mainwind_output_losses(self: WindTurbine, df: pd.DataFrame):
    """Add mainwind output losses

    Args:
        df (pd.DataFrame): Dataframe with output losses
    """

    ## Keep only datetimes in self.data
    df_aux = df[(df["timestamp"] >= self.start_time) & (df["timestamp"] <= self.end_time)]
    
    self.mainwind_output_losses = df_aux
