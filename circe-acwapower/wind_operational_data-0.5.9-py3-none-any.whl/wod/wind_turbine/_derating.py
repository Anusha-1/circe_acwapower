"""
src/wod/wind_turbine/_derating.py

Properties related to derating
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@property
def cold_power_curve(self: WindTurbine):
    """Locate the power curve with the lowest temperature.
        This is the reference to measure derating
    """

    if self._cold_power_curve is None:

        assert len(self.power_curves) > 0, "Add your power curves first"

        min_temperature = np.inf
        for pc in self.temperature_power_curves():
            
            new_temp = pc.metadata['temperature'] ## This forces 'temperature' to exist as a key
            if new_temp < min_temperature:
                self._cold_power_curve = pc
                min_temperature = new_temp

    return self._cold_power_curve

@property
def derating_temperature(self: WindTurbine):
    """Derating temperature, i.e. the temperature from which the derating
        starts to take place
    """

    if self._derating_temperature is None:

        self._derating_temperature = self.cold_power_curve.metadata\
            .get('max_temperature', self.cold_power_curve.metadata["temperature"])

    return self._derating_temperature
