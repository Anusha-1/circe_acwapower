"""
src/wod/wind_turbine/_output.py

Method functions to format output
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def emulate_mainwind_output(
        self: WindTurbine, 
        wind_farm_name: str, 
        derating: bool = False,
        anomalous_power_label: str = 'Potencia anomala') -> pd.DataFrame:
    """
    Creates a dataframe with the necessary columns for PowerBI

    Args:
        wind_farm_name (str): Name of the wind farm
        derating (bool, optional): Activates derating rows. Defaults to False
        anomalous_power_label (str, optional): Label we have implemented for
            anomalous power points. Defaults to 'Potencia anomala'.

    Returns:
        (pd.DataFrame): Resulting dataframe
    """

    df_aux = pd.DataFrame()

    # 1st column: <wind farm name>
    df_aux["windfarm"] = [wind_farm_name] * len(self.data)

    # 2nd column: timestamp
    df_aux['timestamp'] = list(
        self.data["datetime"].dt.strftime("%d/%m/%Y %H:%M:%S"))

    # 3rd column: wtg
    df_aux['wtg'] = self.name

    # 4th column: w
    df_aux['w'] = list(self.data["speed"])

    # 5th column: p
    df_aux['p'] = list(self.data["power"])

    # 6th column: perd
    df_aux['perd'] = list(self.data["loss"])   

    # 7th column: rechazo
    df_aux['rechazo'] = list(
        self.relabel_rejection_codes(
            list(self.mainwind_output_losses['rechazo']),
            list(self.data["alarm"]),
            anomalous_power_label=anomalous_power_label
        )        
    )

    # 8th column: month
    df_aux['month'] = list(self.data["datetime"].dt.strftime("%m/%Y"))

    # 9th column: id_alarm
    df_aux['id_alarm'] = list(self.mainwind_output_losses['id_alarm'])

    # 10th column: alarm
    df_aux['alarm'] = list(self.data["alarm"])
    df_aux['id_alarm'] = df_aux.apply(
        lambda row: 0 if row["alarm"] == 'Running' else row["id_alarm"],
        axis=1
    )

    # 11th column: Tperd
    df_aux['Tperd'] = list(self.mainwind_output_losses['Tperd'])
    df_aux['Tperd'] = df_aux.apply(
        lambda row: 0 if row["alarm"] == 'Running' else row["Tperd"],
        axis=1
    )

    # Extra column 1: perd_old
    df_aux['perd_old'] = list(self.mainwind_output_losses['perd'])

    # Extra columns 2 and 3: Temperature and Temperature segments
    if 'temperature' in self.data.columns:
        df_aux['temp'] = list(self.data.temperature)
        df_aux['temp_segment'] = self.assign_temperature_group(df_aux['temp'])
    else:
        df_aux['temp_segment'] = 1

    # Extra derating rows: Data points with derating loss appeared 'duplicated' 
    # at the end of the dataframe, replacing the loss values with the derating 
    # loss
    if derating:
        df_aux = pd.concat(
            [df_aux, self.format_derating_appendix(df_aux)], axis=0)
        
        ## Change rechazo for derating
        df_aux.loc[df_aux['alarm']=='Derating', 'rechazo'] = 150000
    
    # Final formatting to 3 decimals
    df_aux = df_aux.round({'w': 3, 'p': 3, 'perd': 3, 'perd_old': 3})
    if 'perd_derating' in df_aux.columns:
        df_aux = df_aux.round({'perd_derating': 3})

    return df_aux

@catch_error
def assign_temperature_group(
        self: WindTurbine, temp_series: pd.Series) -> pd.Series:
    """
    Method to assign a temperature segment, based on the existent Power Curves

    Args:
        temp_series (pd.Series): Pandas series with temperatures

    Returns:
        (pd.Series): Pandas series with temperature segments
    """

    def __assign_temperature(temp):
        for i, pc in enumerate(self.temperature_power_curves()):
            if pc.metadata['min_temperature'] < temp <= pc.metadata['max_temperature']:
                return i+1
        return "Missing temp segment"

    return temp_series.apply(__assign_temperature)

@catch_error
def format_derating_appendix(
        self: WindTurbine, data: pd.DataFrame) -> pd.DataFrame:
    """
    Takes an initial dataframe in PowerBI format, and extracts a selection for
    derating losses. It replaces the loss for the derating loss (in the 
    same column), and establishes a derating alarm in its correspondent column

    Args:
        data (pd.DataFrame): Complete dataframe in PowerBI format

    Returns:
        (pd.DataFrame): Auxiliar dataframe with only the derating losses
    """

    data_aux = data.copy()

    ## Add auxiliar temporary columns
    data_aux['derating_loss'] = list(self.data['derating_loss'])
    data_aux['derating_status'] = list(self.data['derating_status'])

    ## Filter the relevant rows
    data_aux = data_aux[data_aux['derating_status'] & (data_aux['derating_loss'] > 0)].copy()
    ## Notice that we can have points with derating_status == True, but derating
    ## loss = 0. This is because we calculated the derating loss as the 
    ## difference between the lower limit of the cold power curve and the mean
    ## power of the temperature-specific power curve. For lower wind speeds,
    ## they will be inverted.
    
    ## Replace values
    data_aux['perd'] = data_aux['derating_loss']
    data_aux['alarm'] = 'Derating'

    ## Remove temporary columns
    data_aux = data_aux.drop(columns=['derating_loss', 'derating_status'])

    return data_aux

@catch_error
def format_power_anomalies(self: WindTurbine) -> pd.DataFrame:
    """Formats power annomalies in a way that can be introduced as input for
    MainWind. It substracts 30000 to power if is a power annomaly


    Returns:
        (pd.DataFrame): Auxiliar dataframe with only the derating losses
    """

    df_aux = pd.DataFrame()

    # 1st column: Datetime
    df_aux['Datetime'] = list(self.data['datetime'].dt.strftime("%d/%m/%Y %H:%M:%S"))

    # 2nd column: Speed
    df_aux[f'W{self.name}'] = list(self.data['speed'])

    # 3rd column: Power
    ## Substract -30000 to anomalous power
    power_series = self.data.apply(
        lambda row: row['power'] if row['alarm'] == 'Running' else row['power'] - 30000,
        axis=1
    )
    df_aux[f'P{self.name}'] = list(power_series)

    # Final formatting to 3 decimals
    df_aux = df_aux.round({f'W{self.name}': 3, f'P{self.name}': 3})

    return df_aux

@catch_error
def relabel_rejection_codes(
        self: WindTurbine, 
        rejection_codes: list[int], 
        alarms: list[str],
        anomalous_power_label: str = 'Potencia anomala') -> pd.Series:
    """
    Relabel rejection codes to be 'coherent'. The incoherences between MainWind
    output and our results come from the treatment of Power Anomalies. If they
    have been calculated with different power curves as reference (which is 
    usally the case, as we consider temperature-specific curves), they might 
    differ in some data points close to the boundary of being consider anomalous.

    Every anomalous power point should have a rejection code of 30000, and all
    Running should have a zero.

    NOTE: This is a temporary patch, alarms should be treated without MainWind
    intervention in the future.

    Args:
        rejection_codes (list[int]): Series with the rejection codes as obtained
            from MainWind output
        alarms (list[str]): Series with the alarms considered
        anomalous_power_label (str, optional): Label we have implemented for
            anomalous power points. Defaults to 'Potencia anomala'.

    Returns:
        pd.Series: Corrected rejection codes
    """

    # Build aux dataframe
    df_aux = pd.DataFrame(
        {
            "rejection": rejection_codes,
            "alarms": alarms
        }
    )
    
    # Rejection code assignment function 
    def __assign_rejection_code(row):
        if row['rejection'] == 0 and row['alarms'] == anomalous_power_label:
            return 30000
        if row['rejection'] == 30000 and row['alarms'] == 'Running':
            return 0        

        return row['rejection']
    
    # Apply rejection re-assignment
    return df_aux.apply(__assign_rejection_code, axis=1)
