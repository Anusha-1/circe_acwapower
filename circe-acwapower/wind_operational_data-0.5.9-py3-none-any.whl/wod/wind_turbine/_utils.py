"""
src/wod/wind_turbine/_utils.py

Method functions with additional utilities
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

import wod.visualization as vis

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def extract_temp_segments_from_power_curves(self: WindTurbine) -> list[dict]:
    """
    Extract temperature segments based on existing PowerCurves

    Returns:
        (list[dict]): Lists of temperature segments. This can be use as plot
            argument
    """

    color_list = vis.obtain_discrete_colors(
        list(range(len(self.power_curves))))

    lst_temp_segments = []
    for i, pc in enumerate(self.temperature_power_curves()):

        ## Check metadata
        ref_temp = pc.metadata['temperature']
        temp_max = pc.metadata.get('max_temperature', None)
        temp_min = pc.metadata.get('min_temperature', None)

        if temp_max is None or temp_min is None:

            name = f"Temperature {ref_temp}ºC"

            if i==0:
                temp_min = -np.inf
                temp_max = 0.5*(ref_temp + self.power_curves[i+1].metadata['temperature'])
            elif i==len(self.power_curves) -1:
                temp_min = 0.5*(ref_temp + self.power_curves[i-1].metadata['temperature'])
                temp_max = np.inf
            else:
                temp_min = 0.5*(ref_temp + self.power_curves[i-1].metadata['temperature'])
                temp_max = 0.5*(ref_temp + self.power_curves[i+1].metadata['temperature'])

        else:

            if ref_temp == temp_max:
                name = f"Temperature <{ref_temp}ºC"
            elif ref_temp == temp_min:
                name = f"Temperature >{ref_temp}ºC"
            else:
                name = f"Temperature {ref_temp}ºC"

        lst_temp_segments.append(
            {"name": name,
                "temperature": ref_temp,
                "min": temp_min,
                "max": temp_max,
                "color": color_list[i], 
            }
        )

    return lst_temp_segments
