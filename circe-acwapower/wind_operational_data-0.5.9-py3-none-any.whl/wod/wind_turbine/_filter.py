"""
wod/wind_turbine/_filter.py

Methods to filter data points
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

import wod.errors as errors

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def filter_data_for_temperature_segment(
        self: WindTurbine,
        temp_segment: dict
) -> pd.DataFrame:
    """Filter data by a temperature segment

    Args:
        temp_segment (dict): Metadata info about a temperature segment.
            Needs to have the keys: 'min_temperature' and 'max_temperature'

    Returns:
        (pd.DataFrame): DataFrame with exclusively the data points belonging
            to the temperature segment
    """

    if 'temperature' not in self.data.columns:
        raise errors.TemperatureException(self.wind_farm_name)

    return self.data[(self.data['temperature'] >= temp_segment['min_temperature']) \
                    & (self.data['temperature'] < temp_segment['max_temperature'])]
