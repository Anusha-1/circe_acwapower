"""
src/wod/wind_turbine/_annomalies.py

Method functions to label annomalies, non-registered events, ...
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import wod.data_wrangling as dw
from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def add_anomalous_power(self: WindTurbine, reference: str = "one", **kwargs):
    """
    It labels the data points with anomalous power

    Args:
        reference (str, optional): Label to indicate which reference to consider.

            - "one": It considers a unique power curve
            - "temp": It considers different power curves, based on temperature

            Defaults to "one"
        **kwargs: Keyword arguments to auxiliary function dw.add_anomalous_power
    """

    ## Add reference min
    if "power_reference_min" not in self.data.columns:
        self.add_reference_min(reference=reference)

    ## Add anomalous power in alarm status
    self.data = dw.add_anomalous_power(self.data, **kwargs)

@catch_error
def add_derating_label(self: WindTurbine):
    """
    Label the points with derating. It creates an additional boolean column
    called "derating_status"
    """

    ## Add reference cold min
    if "interpolated_power_cold_min" not in self.data.columns:
        self.add_reference_cold_min()

    ## Add derating status
    self.data["derating_status"] = (
        self.data["temperature"] > self.derating_temperature
    ) & (self.data["power"] < self.data["interpolated_power_cold_min"])

@catch_error
def add_non_registered_events(self: WindTurbine, **kwargs):
    """
    It labels the data points with non registered events. They correspond to 
    10-min with speed but no power.

    Args:
        **kwargs: Keyword arguments to auxiliary function dw.add_non_registered_events
    """

    ## Add anomalous power in alarm status
    self.data = dw.add_non_registered_events(self.data, **kwargs)