"""
src/wod/wind_turbine/_reference.py

Method functions to interpolate the power curve reference at each point
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import wod.data_wrangling as dw

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def add_reference(self: WindTurbine, reference: str = "one"):
    """
    Adds the power reference for each data point for the calculation of losses, 
    i.e. the power that should correspond to that speed in the power curve

    Args:
        reference (str, optional): "one" for one reference curve, "temp" for
            temperature-specific curves. Defaults to "one".

    Raises:
        Exception: If an unknown reference is passed
    """
    if reference == "one":
        dw.interpolate_from_one_reference(self.power_curves[0].data, self.data)
    elif reference == "temp":
        dw.interpolate_from_temp_power_curves(
            self.data,
            self.power_curves,
        )
    else:
        raise Exception(f"Unrecognized reference {reference}")

def add_reference_min(self: WindTurbine, reference: str = "one"):
    """
    Adds the power lower limit  reference for each data point, i.e. the min 
    power that should correspond to that speed in the power curve

    Args:
        reference (str, optional): "one" for one reference curve, "temp" for
            temperature-specific curves. Defaults to "one".

    Raises:
        Exception: If an unknown reference is passed
    """
    
    if reference == "one":
        dw.interpolate_from_one_reference(
            self.power_curves[0].data,
            self.data,
            power_col="power_min",
            interpolated_power_col="power_reference_min",
        )
    elif reference == "temp":
        dw.interpolate_from_temp_power_curves(
            self.data,
            self.power_curves,
            power_col="power_min",
            interpolated_power_col="power_reference_min",
        )
    else:
        raise Exception(f"Unrecognized reference {reference}")

def add_reference_cold(self: WindTurbine):
    """
    Adds the cold power curve reference for each data point, i.e.
    power that should correspond to that speed in the coldest power curve
    """
    dw.interpolate_from_one_reference(
        self.cold_power_curve.data,
        self.data,        
        power_col="power",
        interpolated_power_col="interpolated_power_cold",
    )

def add_reference_cold_min(self: WindTurbine):
    """
    Adds the cold power curve min reference for each data point, i.e. the min
    power that should correspond to that speed in the coldest power curve
    """
    dw.interpolate_from_one_reference(
        self.cold_power_curve.data,
        self.data,        
        power_col="power_min",
        interpolated_power_col="interpolated_power_cold_min",
    )