"""
wod/wind_turbine/_catch_error.py

Decorator to catch or raise an error
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

def catch_error(function: Callable):
    """
    Decorator that catches a possible error commited in a turbine, if 
    self.catch_turbine_error is set as True
    """

    def wrapper(self: WindTurbine, *args, **kwargs):

        try:
            if self.status == 'Error':
                raise self.error

            result = function(self, *args, **kwargs)
            return result
        except Exception as error:
            self.status = 'Error'
            self.error = error

            if not self.catch_turbine_error:
                raise error
            
            return None
            
    return wrapper
