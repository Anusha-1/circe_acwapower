"""
src/wod/wind_turbine/_losses.py

Method functions to get losses
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def get_losses(self: WindTurbine, reference: str = "one") -> pd.DataFrame:
    """
    Get losses

    Args:
        reference (str, optional): Method to calculate reference power.

            - 'one': Use a unique power curve
            - 'temp': Use temperature power curves

            Defaults to 'one'.

    Returns:
        (pd.DataFrame): Dataframe with losses
    """

    ## Assert necessary columns exist

    ## Adds power reference
    if "power_reference" not in self.data.columns:
        self.add_reference(reference=reference)

    ## Calculate loss
    self.data["loss"] = self.data.apply(
        lambda row: 0
        if row["alarm"] == "Running"
        else max(row["power_reference"] - row["power"], 0),
        axis=1,
    )
    self.data["loss"] = self.data["loss"].fillna(0)

    return self.data

@catch_error
def get_derating_losses(self: WindTurbine) -> pd.DataFrame:
    """
    Calculate derating losses as the difference between the lower limit of the
    cold power curve and the value of its temperature power curve for the
    corresponding speed.

    Returns:
        (pd.DataFrame): Data of the turbine object with additional column
            "derating_loss". Notice that we also change the data attribute
            inplace
    """

    ## Assert necessary columns exist

    ## Adds power reference
    if "power_reference" not in self.data.columns:
        self.add_reference(reference="temp")

    ## Add reference cold
    if "interpolated_power_cold" not in self.data.columns:
        self.add_reference_cold()

    ## Calculate loss
    self.data["derating_loss"] = self.data.apply(
        lambda row: 0
        if not row["derating_status"]
        else max(row["interpolated_power_cold"] - row["power_reference"], 0),
        axis=1,
    )

    return self.data
