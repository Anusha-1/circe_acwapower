"""
src/wod/wind_turbine/_power_curves.py

Method functions to manage power curves inside a WindTurbine object
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Generator

from wod.wind_turbine import catch_error
import wod.wind_turbine.temperature_correction as corr

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine
    from wod.power_curve import PowerCurve

@catch_error
def correct_temperatures(self: WindTurbine):
    """
    Correct power values to make them always decreasing with temperature
    """

    corr.correct_temperature_v1(self)
    
@catch_error
def temperature_power_curves(
        self: WindTurbine) -> Generator[PowerCurve, None, None]:
    """
    Generator function to obtain the PowerCurves that belong to a specific
    temperature. We identify them through the metadata, as 
    "type" = "temperature"  

    Yields:
        (Generator[PowerCurve, None, None]): Generator object that yields the 
            PowerCurve objects that are of the type temperature
    """

    for pc in self.power_curves:
        if pc.metadata['type'] == 'temperature':
            yield pc   

@property
def global_power_curve(
    self: WindTurbine
) -> PowerCurve | None:
    """
    Property to return the global PowerCurve (if any)

    Returns:
        (PowerCurve): Global PowerCurve
    """
    
    if self._global_power_curve is None:

        for pc in self.power_curves:
            if pc.metadata["type"] == "global":
                self._global_power_curve = pc
                break

    return self._global_power_curve
