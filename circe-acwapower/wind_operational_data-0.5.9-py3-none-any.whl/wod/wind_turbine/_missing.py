"""
src/wod/wind_turbine/_missing.py

Method functions to imputate missing data
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def imputate_missing_data(
        self: WindTurbine, column: str, **kwargs):
    """
    Inputate missing data in a column

    Args:
        column (str): Name of the column
        **kwargs: Keyword arguments for pandas.DataFrame.fillna
            (https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.fillna.html)
    """
    
    self.data[column] = self.data[column].fillna(**kwargs)

@catch_error
def replace_speed_with_mainwind(self: WindTurbine):
    """
    Replace data speed by mainwind speed
    """

    self.data["speed"] = self.mainwind_output_losses["w"]

@catch_error
def replace_power_with_mainwind(self: WindTurbine):
    """
    Replace data power by mainwind power
    """

    self.data["power"] = self.mainwind_output_losses["p"]
