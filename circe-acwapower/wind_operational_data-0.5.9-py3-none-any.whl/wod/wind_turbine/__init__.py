"""
src/wod/wind_turbine/__init__.py

Definition of WindTurbine class
"""

from datetime import datetime

import pandas as pd

import wod.check as check

from wod.alarms import Alarms
from wod.power_curve import PowerCurve
from wod.warnings import warn_high_proportion_of_invalid_data
from ._catch_error import catch_error

class WindTurbine:
    """
    class WindTurbine: Organizes the operational data of a specific turbine

    Attributes:
        name (str): Name of the turbine
        data (pd.DataFrame): Dataframe with data. 
            The minimum set of columns are: datetime, speed, power.
            They might be increased with additional information as different
            methods of the class are called.
        power_curves (list[PowerCurve]): List of PowerCurve objects, associated
            to this wind turbine
        alarms (Alarms): Alarms object associared to this wind turbine
        mainwind_output_losses (pd.DataFrame): Data with original MainWind
            output associated to this turbine
        start_time (datetime): Datetime where the current loaded data begins
        end_time (datetime): Datetime where the current loaded data ends
        status (str): Status of the turbine. Possible values are 'Ok' and 
            'Error'. Only relevant if catch_error is True at initialization.
        error (None | Exception): Error for the turbine. If status is 'Ok' it is
            None. Only relevant if catch_error is True at initialization.
        catch_turbine_error (bool): Whether the turbine will catch the errors (True) or
            raise them (False)
    """

    # Import methods
    from ._add_extra import (
        add_alarms,
        add_mainwind_output_losses,
        add_power_curves,
        create_power_curves,
        add_temperature_data,
    )
    from ._anomalies import (
        add_anomalous_power, 
        add_derating_label,
        add_non_registered_events
    )
    from ._derating import cold_power_curve, derating_temperature
    from ._filter import filter_data_for_temperature_segment
    from ._losses import (
        get_losses,
        get_derating_losses
    )
    from ._missing import (
        imputate_missing_data, 
        replace_power_with_mainwind, 
        replace_speed_with_mainwind
    )
    from ._output import (
        emulate_mainwind_output, 
        assign_temperature_group,
        format_derating_appendix,
        format_power_anomalies,
        relabel_rejection_codes
    )
    from ._plot import plot
    from ._power_curves import (
        correct_temperatures,
        temperature_power_curves,
        global_power_curve
    )
    from ._reference import (
        add_reference, 
        add_reference_min,
        add_reference_cold,
        add_reference_cold_min
    )
    from ._stats import (
        get_losses_stats,
        get_derating_losses_stats
    )
    from ._utils import extract_temp_segments_from_power_curves

    def __init__(
            self, 
            name: str, 
            data: pd.DataFrame, 
            wind_farm_name: str | None = None, 
            catch_error: bool = False,
            **kwargs):
        """
        Initialization metod

        Args:
            name (str): Name of the turbine
            data (pd.DataFrame): Dataframe with data.
                Required columns: datetime, speed, power
            wind_farm_name (str | None): Name of the wind farm this turbine 
                belongs to. Defaults to None.
            catch_error (bool): If True, errors regarding a turbine are caught.
                Defaults to False
            **kwargs: Keyword arguments for __data_validation method
        """

        self.status: str = 'Ok'    
        self.error: None | Exception = None
        self.catch_turbine_error = catch_error

        self.name: str = name
        self.wind_farm_name = wind_farm_name
        self.data: pd.DataFrame  = self.__data_validation(data, **kwargs)        

        self.power_curves: list[PowerCurve] = []
        self.alarms: Alarms = None
        self.mainwind_output_losses: pd.DataFrame = None

        self.start_time: datetime | None = None
        self.end_time: datetime | None = None
        if 'datetime' in data.columns:
            self.start_time = data.datetime.min()
            self.end_time = data.datetime.max()        
        
        ## Properties
        self._cold_power_curve: PowerCurve | None = None
        self._derating_temperature: float | None = None
        self._global_power_curve: PowerCurve | None = None

    def __str__(self) -> str:
        return f"WindTurbine(name={self.name})"

    def __repr__(self) -> str:

        len_data = len(self.data) if self.data is not None else 0

        repr_str = f"WindTurbine(name={self.name}) \n"
        repr_str += f"N Data: {len_data} ({self.status}) \n"

        if len_data > 0:
            repr_str += f"Has temperatures? {'Yes' if 'temperature' in self.data.columns else 'No'} \n"
            repr_str += f"Number of Power Curves: {len(self.power_curves)} \n"
            repr_str += f"Has alarms? {'Yes' if 'alarm' in self.data.columns else 'No'} \n"
            repr_str += f"Has MainWind output loaded? {'Yes' if self.mainwind_output_losses is not None else 'No'} \n"
            repr_str += f"Has losses? {'Yes' if 'loss' in self.data.columns else 'No'} \n"

        return repr_str

    @catch_error
    def __data_validation(
            self, df: pd.DataFrame,
            warn_threshold: float = 10.0, 
            error_threshold: float = 99.9,
            **kwargs) -> pd.DataFrame:
        """
        Validate data. It creates an additional bool column 'validation status'

        Args:
            df (pd.DataFrame): Dataframe with data.
                Required columns: datetime, speed, power
            warn_threshold (float, optional): Minimum threshold to raise a warning. 
                Defaults to 10.0.
            error_threshold (float, optional): Minimum threshold to raise an error. 
                Defaults to 99.9.
            **kwargs: Keyword arguments for check.validate_data

        Returns:
            pd.DataFrame: Dataframe with additional column
        """

        df = check.validate_data(df, **kwargs)

        # Send possible warning or error
        warn_high_proportion_of_invalid_data(
                self,
                df, 
                warn_threshold = warn_threshold, 
                error_threshold = error_threshold)

        return df
