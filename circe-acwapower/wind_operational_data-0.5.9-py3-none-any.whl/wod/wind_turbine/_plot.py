"""
src/wod/wind_turbine/_plot.py

Method functions to create plots
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

import wod.visualization as vis
from wod.wind_turbine import catch_error

if TYPE_CHECKING:
    from wod.wind_turbine import WindTurbine

@catch_error
def plot(
        self: WindTurbine, 
        plot_type: str = 'basic', 
        power_curve_index: list[int] = None,
        temp_segments: list[dict] | None = None, 
        **kwargs) -> go.Figure:
    """
    Produces a basic power vs speed scatter plot

    Args:
        plot_type (str, optional): Indicates the type of plot to make. 
            Options are:

            - 'basic': Simple Scatter plot Power vs Speed
            - 'temp': Scatterplot color coded by temperature
            - 'temp_segments': Scatterplot in temperature segments
            - 'alarms': Scatterplot with alarms
            - 'derating': Scatterplot with alarms
            - 'temp_power_curves': Scatterplot + Lines for temperature power
                curves
            - 'temp_power_curves+global': Scatterplot + Lines for temperature 
                power curves and an additional global power curve

            Defaults to 'basic'.
        power_curve_index (list[int]): List of indexes of power curve to add. 
            If None, it won't add a power curve to the plot. Defaults to None
        temp_segments (list[dict]): List of dict with temp segments. Each dict 
            has:

            - name
            - metadata (to link with PowerCurve)
            - max
            - min
            - color
            Only for plot_type = 'temp_segments'. Defaults to None
        **kwargs: Keyword arguments for the different plot functions

    Returns:
        (go.Figure): Plotly figure
    """        

    if plot_type == 'basic':
        fig = vis.plot_power_vs_speed(self.data, **kwargs)
    elif plot_type == 'temp':
        fig = vis.plot_power_vs_speed_with_temp(self.data, **kwargs)
    elif plot_type == 'temp_segments':
        assert temp_segments is not None, "If plot_type='temp_segments', we need temp_segments"
        fig = vis.plot_power_vs_speed_with_temp_segments(
            self.data, temp_segments, **kwargs)
    elif plot_type == 'alarms':
        fig = vis.plot_power_vs_speed_with_alarms(self.data, **kwargs)
    elif plot_type == 'derating':
        fig = vis.plot_power_vs_speed_with_derating(self.data, **kwargs)
    elif plot_type == 'temp_power_curves':
        fig = vis.plot_temperature_power_curves_in_turbine(self.power_curves)
    elif plot_type == 'temp_power_curves+global':
        fig = vis.plot_temperature_power_curves_in_turbine(self.power_curves)
        fig = vis.add_power_curve_trace(
                fig, 
                self.global_power_curve.data, 
                legendgroup="Global Power Curve",
                color="black",
                **kwargs)
    elif plot_type == 'basic+global':
        fig = vis.plot_power_vs_speed(self.data, color='grey', **kwargs)
        fig = vis.add_power_curve_trace(
                fig, 
                self.global_power_curve.data, 
                legendgroup="Global Power Curve",
                color="black",
                **kwargs)


    if power_curve_index is not None:

        if len(power_curve_index) > 1:
            color_list = vis.obtain_discrete_colors(power_curve_index)
        else:
            color_list = ['black']
        
        for index in power_curve_index:

            if plot_type == 'temp_segments':
                legendgroup=temp_segments[index]['name']
                if 'color' in temp_segments[index].keys():
                    color = temp_segments[index]['color']
                else:
                    color=color_list[index]
            else:
                legendgroup = "Power Curves"
                color='green'

            fig = vis.add_power_curve_trace(
                fig, 
                self.power_curves[index].data, 
                legendgroup=legendgroup,
                color=color,
                **kwargs)
        
    return fig
