SELECT *
FROM [raw].[static_pitch_Khalladi] sa 
WHERE sa.PCTimeStamp <= :end