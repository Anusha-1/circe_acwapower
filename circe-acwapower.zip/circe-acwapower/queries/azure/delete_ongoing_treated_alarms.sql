DELETE
FROM [vis].[treated_events]
WHERE ongoing = 'True'