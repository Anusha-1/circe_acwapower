SELECT *
FROM [raw].[realtime_tower_acceleration_Khalladi] t
WHERE t.PCTimeStamp > :start