SELECT *
FROM vis.fn_get_pitch_with_lambda('1-2','2023-01-01','2023-01-14',2)