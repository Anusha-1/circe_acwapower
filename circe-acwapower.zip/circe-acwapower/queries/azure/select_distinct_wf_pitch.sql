SELECT DISTINCT id_wf
FROM intermediate.pitch im 