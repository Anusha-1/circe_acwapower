SELECT MAX([datetime])
FROM [raw].[realtime_met_mast_Az-M1]
