SELECT 
	MAX([PCTimeStamp]) AS max_time
FROM [raw].[realtime_tower_acceleration_Azerbaijan]