SELECT *
FROM intermediate.pitch
WHERE id_wf = :id_wf and timestamp > :timestamp