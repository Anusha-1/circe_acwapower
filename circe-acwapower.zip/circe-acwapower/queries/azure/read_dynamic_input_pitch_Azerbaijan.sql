SELECT *
FROM [raw].[realtime_pitch_Azerbaijan] t
WHERE t.PCTimeStamp > :start