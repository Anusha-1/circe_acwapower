DELETE FROM [raw].[realtime_input_1min_Azerbaijan]
WHERE [datetime] < :start
