DELETE
FROM [raw].[realtime_alarms_Khalladi]
WHERE Duration = 'Ongoing'