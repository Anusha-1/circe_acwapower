SELECT DISTINCT id_wf
FROM [intermediate].[tower_acceleration] im
