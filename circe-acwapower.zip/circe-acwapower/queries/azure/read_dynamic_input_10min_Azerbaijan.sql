SELECT *
FROM [raw].[realtime_input_10min_Azerbaijan] t
WHERE t.datetime > :start