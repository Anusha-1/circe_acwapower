SELECT *
FROM intermediate.reliability_ts
WHERE timestamp > :min_timestamp