SELECT *
FROM [raw].[realtime_tower_acceleration_Azerbaijan] t
WHERE t.PCTimeStamp > :start