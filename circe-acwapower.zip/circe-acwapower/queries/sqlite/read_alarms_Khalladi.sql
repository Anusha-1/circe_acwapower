SELECT *
FROM "raw.static_alarms_Khalladi" sa 
WHERE sa.Detected <= :end