SELECT *
FROM "raw.realtime_pitch_Khalladi" t
WHERE t.PCTimeStamp > :start