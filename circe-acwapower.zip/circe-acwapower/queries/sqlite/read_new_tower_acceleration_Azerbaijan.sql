SELECT *
FROM "raw.static_tower_acceleration_Azerbaijan" sa 
WHERE sa.PCTimeStamp <= :end AND sa.PCTimeStamp > :max  