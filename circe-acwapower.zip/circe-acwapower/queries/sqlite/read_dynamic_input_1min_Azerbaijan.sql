SELECT *
FROM "raw.realtime_input_1min_Azerbaijan" t
WHERE t.datetime > :start