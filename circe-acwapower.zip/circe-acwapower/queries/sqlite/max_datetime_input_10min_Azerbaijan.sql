SELECT MAX(datetime)
FROM "raw.realtime_input_10min_Azerbaijan"
