SELECT DISTINCT id_wf
FROM "intermediate.input_10min" im 