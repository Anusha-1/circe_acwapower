SELECT *
FROM "vis.power_curves"
WHERE pc_id = :power_curve_id