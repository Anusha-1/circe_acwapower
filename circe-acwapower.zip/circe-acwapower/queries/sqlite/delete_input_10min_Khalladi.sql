DELETE FROM "raw.realtime_input_10min_Khalladi"
WHERE datetime < :start
