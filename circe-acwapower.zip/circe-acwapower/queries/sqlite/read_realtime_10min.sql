SELECT *
FROM "raw.realtime_input10min"