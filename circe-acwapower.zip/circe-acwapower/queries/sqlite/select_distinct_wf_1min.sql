SELECT DISTINCT id_wf
FROM "intermediate.input_1min" im 