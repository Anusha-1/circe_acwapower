DELETE
FROM "raw.realtime_alarms"
WHERE Duration = 'Ongoing'