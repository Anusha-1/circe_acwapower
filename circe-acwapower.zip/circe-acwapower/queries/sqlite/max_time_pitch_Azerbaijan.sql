SELECT 
	MAX([PCTimeStamp]) AS max_time
FROM "raw.realtime_pitch_Azerbaijan"