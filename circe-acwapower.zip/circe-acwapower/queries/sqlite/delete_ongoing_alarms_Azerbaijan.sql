DELETE
FROM "raw.realtime_alarms_Azerbaijan"
WHERE Duration = 'Ongoing'