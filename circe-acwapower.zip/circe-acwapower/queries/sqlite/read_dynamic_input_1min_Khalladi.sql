SELECT *
FROM "raw.realtime_input_1min_Khalladi" t
WHERE t.datetime > :start