DELETE FROM "raw.realtime_met_mast_Kh-M1"
WHERE [datetime] < :start
