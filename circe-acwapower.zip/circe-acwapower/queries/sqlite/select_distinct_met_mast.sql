SELECT DISTINCT met_mast_id
FROM "vis.oper_met_mast" 