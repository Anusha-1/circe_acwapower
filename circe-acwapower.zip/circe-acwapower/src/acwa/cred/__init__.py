"""
acwa.cred

Module to identify 
"""

from .secrets import get_key_vault_secrets

__all__ = [get_key_vault_secrets]